import * as ros from '@alicloud/ros-cdk-core';
/**
 * Properties for defining a `RosAccount`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-account
 */
export interface RosAccountProps {
    /**
     * @Property accountName: The name of the privileged account.
     * The name can contain lowercase letters, digits, and underscores (_).
     * The name must start with a lowercase letter and end with a lowercase letter or a digit.
     * The name cannot start with gp.
     * The name must be 2 to 16 characters in length.
     */
    readonly accountName: string | ros.IResolvable;
    /**
     * @Property accountPassword: The password of the privileged account.
     * The password must contain at least three of the following character types: uppercase
     * letters, lowercase letters, digits, and special characters.
     * Special characters include ! @ # $ % ^ & * ( ) _ + - =
     * The password must be 8 to 32 characters in length.
     */
    readonly accountPassword: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: The ID of the instance.
     * Note You can call the DescribeDBInstances operation to query details of all AnalyticDB for PostgreSQL instances in a specific
     * region, including instance IDs.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property accountDescription: The description of the privileged account.
     */
    readonly accountDescription?: string | ros.IResolvable;
    /**
     * @Property accountType: Default value is Super, which creates a privileged account. When the parameter is Normal, it creates a normal account.
     */
    readonly accountType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::Account`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Account` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-account
 */
export declare class RosAccount extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::Account";
    /**
     * @Attribute AccountName: The name of the account.
     */
    readonly attrAccountName: ros.IResolvable;
    /**
     * @Attribute DBInstanceId: The ID of the instance.
     */
    readonly attrDbInstanceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property accountName: The name of the privileged account.
     * The name can contain lowercase letters, digits, and underscores (_).
     * The name must start with a lowercase letter and end with a lowercase letter or a digit.
     * The name cannot start with gp.
     * The name must be 2 to 16 characters in length.
     */
    accountName: string | ros.IResolvable;
    /**
     * @Property accountPassword: The password of the privileged account.
     * The password must contain at least three of the following character types: uppercase
     * letters, lowercase letters, digits, and special characters.
     * Special characters include ! @ # $ % ^ & * ( ) _ + - =
     * The password must be 8 to 32 characters in length.
     */
    accountPassword: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: The ID of the instance.
     * Note You can call the DescribeDBInstances operation to query details of all AnalyticDB for PostgreSQL instances in a specific
     * region, including instance IDs.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property accountDescription: The description of the privileged account.
     */
    accountDescription: string | ros.IResolvable | undefined;
    /**
     * @Property accountType: Default value is Super, which creates a privileged account. When the parameter is Normal, it creates a normal account.
     */
    accountType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosAccountProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosDBInstance`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbinstance
 */
export interface RosDBInstanceProps {
    /**
     * @Property engineVersion: The version of the database engine. For example: 6.0、7.0
     */
    readonly engineVersion: string | ros.IResolvable;
    /**
     * @Property vSwitchId: The vSwitch ID of the instance.
     */
    readonly vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: The zone ID of the instance, such as cn-hangzhou-d. You can call the DescribeRegions
     * operation to query the most recent zone list.
     */
    readonly zoneId: string | ros.IResolvable;
    /**
     * @Property aiNodeSpecInfos: AI node spec infos.
     */
    readonly aiNodeSpecInfos?: Array<RosDBInstance.AINodeSpecInfosProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property backupId: Backup set ID. You can call DescribeDataBackups to view the backup set IDs of all backup sets under the target instance.
     */
    readonly backupId?: string | ros.IResolvable;
    /**
     * @Property cacheStorageSize: Cache storage size.
     */
    readonly cacheStorageSize?: string | ros.IResolvable;
    /**
     * @Property createSampleData: Whether to load the sample data set after the instance is created. The value can be:
     * true: load the sample dataset.
     * false: not to load the sample dataset
     */
    readonly createSampleData?: boolean | ros.IResolvable;
    /**
     * @Property dbInstanceCategory: DB instance category, valid values: Basic, HighAvailability.
     * This parameter must be passed in to create a storage reservation mode instance.
     */
    readonly dbInstanceCategory?: string | ros.IResolvable;
    /**
     * @Property dbInstanceClass: The instance type.
     */
    readonly dbInstanceClass?: string | ros.IResolvable;
    /**
     * @Property dbInstanceDescription: The description of the instance. The description cannot exceed 256 characters in length.
     */
    readonly dbInstanceDescription?: string | ros.IResolvable;
    /**
     * @Property dbInstanceGroupCount: The number of compute nodes in the instance.
     * The value can be 2, 4, 8, 12, 16, 24, 32, 64, 96, or 128.
     */
    readonly dbInstanceGroupCount?: number | ros.IResolvable;
    /**
     * @Property dbInstanceMode: The db instance mode. Valid values: StorageElastic, Serverless, Classic.
     */
    readonly dbInstanceMode?: string | ros.IResolvable;
    /**
     * @Property deployMode: The deployment mode of the instance.
     */
    readonly deployMode?: string | ros.IResolvable;
    /**
     * @Property enableSsl: Whether to enable SSL encryption. Valid values: true: Enable SSL encryption. false (default): Do not enable SSL encryption.
     */
    readonly enableSsl?: boolean | ros.IResolvable;
    /**
     * @Property encryptionKey: If the EncryptionType parameter is set to CloudDisk, you must specify this parameter to the encryption key that is in the same region with the disks that is specified by the EncryptionType parameter. Otherwise, leave this parameter empty.
     */
    readonly encryptionKey?: string | ros.IResolvable;
    /**
     * @Property encryptionType: The type of the encryption. Default value: NULL. Valid values:
     * NULL: Encryption is disabled.
     * CloudDisk: Encryption is enabled on disks and the encryption key is specified by using the EncryptionKey parameter.
     * Note: Disk encryption cannot be disabled after it is enabled.
     */
    readonly encryptionType?: string | ros.IResolvable;
    /**
     * @Property idleTime: Idle release wait time. That is, when the period of no service traffic reaches the specified period, the instance becomes idle. The unit is second. The minimum value is 60. The default value is 600.
     */
    readonly idleTime?: number | ros.IResolvable;
    /**
     * @Property instanceSpec: The specification of segment nodes.
     * - When DBInstanceCategory is HighAvailability, Valid values: 2C16G, 4C32G, 8C64G, 16C128G.
     * - When DBInstanceCategory is Basic, Valid values: 2C8G, 4C16G, 8C32G, 16C64G.
     * - When DBInstanceCategory is Serverless, Valid values: 4C16G, 8C32G.
     * This parameter must be passed to create a storage elastic mode instance and a serverless version instance.
     */
    readonly instanceSpec?: string | ros.IResolvable;
    /**
     * @Property masterAiSpec: If you need to change the Master node to MasterAI node, specify this parameter. This parameter cannot be specified at the same time as MasterCU. Only some regions and availability zones support changing the Master node to MasterAI node. Only Basic edition instances of AnalyticDB PostgreSQL 7.0 support MasterAI nodes. You can query all possible values of this parameter on the Master node reconfiguration sales page.
     */
    readonly masterAiSpec?: string | ros.IResolvable;
    /**
     * @Property masterCu: Master resources. Default is 8.
     */
    readonly masterCu?: number | ros.IResolvable;
    /**
     * @Property masterNodeNum: The number of master nodes. Minimum is 1, max is 2.
     */
    readonly masterNodeNum?: number | ros.IResolvable;
    /**
     * @Property payType: The billing method of the instance. Default value: Postpaid. Valid values:
     * Postpaid: pay-as-you-go
     * Prepaid: subscription
     */
    readonly payType?: string | ros.IResolvable;
    /**
     * @Property period: The subscription period. While choose by pay by month, it could be from 1 to 11. While choose pay by year, it could be from 1 to 3.
     */
    readonly period?: number | ros.IResolvable;
    /**
     * @Property periodUnit: Unit of subscription period, it could be Month\/Year. Default value is Month.
     */
    readonly periodUnit?: string | ros.IResolvable;
    /**
     * @Property privateIpAddress: Private IP address.
     */
    readonly privateIpAddress?: string | ros.IResolvable;
    /**
     * @Property prodType: Prod type. The value can be: standard, cost-effective. The default value is standard.
     */
    readonly prodType?: string | ros.IResolvable;
    /**
     * @Property resourceGroupId: The ID of the resource group.
     */
    readonly resourceGroupId?: string | ros.IResolvable;
    /**
     * @Property securityIpList: The whitelist of IP addresses that are allowed to access the instance. Default value:
     * 127.0.0.1.
     */
    readonly securityIpList?: string | ros.IResolvable;
    /**
     * @Property segDiskPerformanceLevel: Seg disk performance level. The value can be:
     * pl0、pl1 and pl2
     */
    readonly segDiskPerformanceLevel?: string | ros.IResolvable;
    /**
     * @Property segNodeNum: Calculate the number of nodes. The value can be:
     * - When DBInstanceMode is StorageElastic and DBInstanceCategory is HighAvailability, the value ranges from 4 to 512. The value must be a multiple of 4.
     * - When DBInstanceMode is StorageElastic and DBInstanceCategory is Basic, the value ranges from 2 to 512. The value must be a multiple of 2.
     * - When DBInstanceMode is Serverless, The value ranges from 2 to 512. The value must be a multiple of 2.
     */
    readonly segNodeNum?: number | ros.IResolvable;
    /**
     * @Property segStorageType: The disk type of segment nodes. For example: cloud_essd, cloud_efficiency.
     * This parameter must be passed in to create a storage elastic mode instance.
     * Storage Elastic Mode Basic Edition instances only support ESSD cloud disks.
     */
    readonly segStorageType?: string | ros.IResolvable;
    /**
     * @Property serverlessMode: Mode of the Serverless instance. The value can be:
     * Manual: manual scheduling is the default value.
     * Auto: indicates automatic scheduling.
     */
    readonly serverlessMode?: string | ros.IResolvable;
    /**
     * @Property serverlessResource: Computing resource threshold. The value ranges from 8 to 32. The step length is 8.
     * The unit is ACU. The default value is 32.
     */
    readonly serverlessResource?: number | ros.IResolvable;
    /**
     * @Property srcDbInstanceName: Clone source instance ID. You can call the DescribeDBInstances interface to view the details of all AnalyticDB PostgreSQL instances in the target region, including the instance ID.
     */
    readonly srcDbInstanceName?: string | ros.IResolvable;
    /**
     * @Property standbyVSwitchId: The standby VSwitch ID of the instance.
     */
    readonly standbyVSwitchId?: string | ros.IResolvable;
    /**
     * @Property standbyZoneId: The standby zone ID of the instance.
     */
    readonly standbyZoneId?: string | ros.IResolvable;
    /**
     * @Property storageSize: The storage capacity of per segment node. Unit: GB. Minimum is 50, max is 4000, step is 50.
     */
    readonly storageSize?: number | ros.IResolvable;
    /**
     * @Property tags: The list of instance tags in the form of key\/value pairs.
     * You can define a maximum of 20 tags for instance.
     */
    readonly tags?: RosDBInstance.TagsProperty[];
    /**
     * @Property vectorConfigurationStatus: the status of vector configuration. The value can be:Y: Turn on vector engine optimization.N: Turn off vector engine optimization (default value).
     */
    readonly vectorConfigurationStatus?: string | ros.IResolvable;
    /**
     * @Property vpcId: The VPC ID of the instance. If you set the InstanceNetworkType parameter to VPC, you
     * must also specify the VPCId parameter. The specified region of the VPC must be the
     * same as the RegionId value.
     */
    readonly vpcId?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::DBInstance`Use the , which resource to create an AnalyticDB for PostgreSQL instance in reserved storage mode.
 * @Note This class does not contain additional functions, so it is recommended to use the `DBInstance` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbinstance
 */
export declare class RosDBInstance extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::DBInstance";
    /**
     * @Attribute Arn: The Alibaba Cloud Resource Name (ARN).
     */
    readonly attrArn: ros.IResolvable;
    /**
     * @Attribute ConnectionString: The endpoint of the instance.
     */
    readonly attrConnectionString: ros.IResolvable;
    /**
     * @Attribute DBInstanceId: The ID of the instance.
     */
    readonly attrDbInstanceId: ros.IResolvable;
    /**
     * @Attribute OrderId: The order ID of the instance.
     */
    readonly attrOrderId: ros.IResolvable;
    /**
     * @Attribute Port: The port used to connect to the instance.
     */
    readonly attrPort: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property engineVersion: The version of the database engine. For example: 6.0、7.0
     */
    engineVersion: string | ros.IResolvable;
    /**
     * @Property vSwitchId: The vSwitch ID of the instance.
     */
    vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: The zone ID of the instance, such as cn-hangzhou-d. You can call the DescribeRegions
     * operation to query the most recent zone list.
     */
    zoneId: string | ros.IResolvable;
    /**
     * @Property aiNodeSpecInfos: AI node spec infos.
     */
    aiNodeSpecInfos: Array<RosDBInstance.AINodeSpecInfosProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property backupId: Backup set ID. You can call DescribeDataBackups to view the backup set IDs of all backup sets under the target instance.
     */
    backupId: string | ros.IResolvable | undefined;
    /**
     * @Property cacheStorageSize: Cache storage size.
     */
    cacheStorageSize: string | ros.IResolvable | undefined;
    /**
     * @Property createSampleData: Whether to load the sample data set after the instance is created. The value can be:
     * true: load the sample dataset.
     * false: not to load the sample dataset
     */
    createSampleData: boolean | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceCategory: DB instance category, valid values: Basic, HighAvailability.
     * This parameter must be passed in to create a storage reservation mode instance.
     */
    dbInstanceCategory: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceClass: The instance type.
     */
    dbInstanceClass: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceDescription: The description of the instance. The description cannot exceed 256 characters in length.
     */
    dbInstanceDescription: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceGroupCount: The number of compute nodes in the instance.
     * The value can be 2, 4, 8, 12, 16, 24, 32, 64, 96, or 128.
     */
    dbInstanceGroupCount: number | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceMode: The db instance mode. Valid values: StorageElastic, Serverless, Classic.
     */
    dbInstanceMode: string | ros.IResolvable | undefined;
    /**
     * @Property deployMode: The deployment mode of the instance.
     */
    deployMode: string | ros.IResolvable | undefined;
    /**
     * @Property enableSsl: Whether to enable SSL encryption. Valid values: true: Enable SSL encryption. false (default): Do not enable SSL encryption.
     */
    enableSsl: boolean | ros.IResolvable | undefined;
    /**
     * @Property encryptionKey: If the EncryptionType parameter is set to CloudDisk, you must specify this parameter to the encryption key that is in the same region with the disks that is specified by the EncryptionType parameter. Otherwise, leave this parameter empty.
     */
    encryptionKey: string | ros.IResolvable | undefined;
    /**
     * @Property encryptionType: The type of the encryption. Default value: NULL. Valid values:
     * NULL: Encryption is disabled.
     * CloudDisk: Encryption is enabled on disks and the encryption key is specified by using the EncryptionKey parameter.
     * Note: Disk encryption cannot be disabled after it is enabled.
     */
    encryptionType: string | ros.IResolvable | undefined;
    /**
     * @Property idleTime: Idle release wait time. That is, when the period of no service traffic reaches the specified period, the instance becomes idle. The unit is second. The minimum value is 60. The default value is 600.
     */
    idleTime: number | ros.IResolvable | undefined;
    /**
     * @Property instanceSpec: The specification of segment nodes.
     * - When DBInstanceCategory is HighAvailability, Valid values: 2C16G, 4C32G, 8C64G, 16C128G.
     * - When DBInstanceCategory is Basic, Valid values: 2C8G, 4C16G, 8C32G, 16C64G.
     * - When DBInstanceCategory is Serverless, Valid values: 4C16G, 8C32G.
     * This parameter must be passed to create a storage elastic mode instance and a serverless version instance.
     */
    instanceSpec: string | ros.IResolvable | undefined;
    /**
     * @Property masterAiSpec: If you need to change the Master node to MasterAI node, specify this parameter. This parameter cannot be specified at the same time as MasterCU. Only some regions and availability zones support changing the Master node to MasterAI node. Only Basic edition instances of AnalyticDB PostgreSQL 7.0 support MasterAI nodes. You can query all possible values of this parameter on the Master node reconfiguration sales page.
     */
    masterAiSpec: string | ros.IResolvable | undefined;
    /**
     * @Property masterCu: Master resources. Default is 8.
     */
    masterCu: number | ros.IResolvable | undefined;
    /**
     * @Property masterNodeNum: The number of master nodes. Minimum is 1, max is 2.
     */
    masterNodeNum: number | ros.IResolvable | undefined;
    /**
     * @Property payType: The billing method of the instance. Default value: Postpaid. Valid values:
     * Postpaid: pay-as-you-go
     * Prepaid: subscription
     */
    payType: string | ros.IResolvable | undefined;
    /**
     * @Property period: The subscription period. While choose by pay by month, it could be from 1 to 11. While choose pay by year, it could be from 1 to 3.
     */
    period: number | ros.IResolvable | undefined;
    /**
     * @Property periodUnit: Unit of subscription period, it could be Month\/Year. Default value is Month.
     */
    periodUnit: string | ros.IResolvable | undefined;
    /**
     * @Property privateIpAddress: Private IP address.
     */
    privateIpAddress: string | ros.IResolvable | undefined;
    /**
     * @Property prodType: Prod type. The value can be: standard, cost-effective. The default value is standard.
     */
    prodType: string | ros.IResolvable | undefined;
    /**
     * @Property resourceGroupId: The ID of the resource group.
     */
    resourceGroupId: string | ros.IResolvable | undefined;
    /**
     * @Property securityIpList: The whitelist of IP addresses that are allowed to access the instance. Default value:
     * 127.0.0.1.
     */
    securityIpList: string | ros.IResolvable | undefined;
    /**
     * @Property segDiskPerformanceLevel: Seg disk performance level. The value can be:
     * pl0、pl1 and pl2
     */
    segDiskPerformanceLevel: string | ros.IResolvable | undefined;
    /**
     * @Property segNodeNum: Calculate the number of nodes. The value can be:
     * - When DBInstanceMode is StorageElastic and DBInstanceCategory is HighAvailability, the value ranges from 4 to 512. The value must be a multiple of 4.
     * - When DBInstanceMode is StorageElastic and DBInstanceCategory is Basic, the value ranges from 2 to 512. The value must be a multiple of 2.
     * - When DBInstanceMode is Serverless, The value ranges from 2 to 512. The value must be a multiple of 2.
     */
    segNodeNum: number | ros.IResolvable | undefined;
    /**
     * @Property segStorageType: The disk type of segment nodes. For example: cloud_essd, cloud_efficiency.
     * This parameter must be passed in to create a storage elastic mode instance.
     * Storage Elastic Mode Basic Edition instances only support ESSD cloud disks.
     */
    segStorageType: string | ros.IResolvable | undefined;
    /**
     * @Property serverlessMode: Mode of the Serverless instance. The value can be:
     * Manual: manual scheduling is the default value.
     * Auto: indicates automatic scheduling.
     */
    serverlessMode: string | ros.IResolvable | undefined;
    /**
     * @Property serverlessResource: Computing resource threshold. The value ranges from 8 to 32. The step length is 8.
     * The unit is ACU. The default value is 32.
     */
    serverlessResource: number | ros.IResolvable | undefined;
    /**
     * @Property srcDbInstanceName: Clone source instance ID. You can call the DescribeDBInstances interface to view the details of all AnalyticDB PostgreSQL instances in the target region, including the instance ID.
     */
    srcDbInstanceName: string | ros.IResolvable | undefined;
    /**
     * @Property standbyVSwitchId: The standby VSwitch ID of the instance.
     */
    standbyVSwitchId: string | ros.IResolvable | undefined;
    /**
     * @Property standbyZoneId: The standby zone ID of the instance.
     */
    standbyZoneId: string | ros.IResolvable | undefined;
    /**
     * @Property storageSize: The storage capacity of per segment node. Unit: GB. Minimum is 50, max is 4000, step is 50.
     */
    storageSize: number | ros.IResolvable | undefined;
    /**
     * @Property tags: The list of instance tags in the form of key\/value pairs.
     * You can define a maximum of 20 tags for instance.
     */
    tags: RosDBInstance.TagsProperty[] | undefined;
    /**
     * @Property vectorConfigurationStatus: the status of vector configuration. The value can be:Y: Turn on vector engine optimization.N: Turn off vector engine optimization (default value).
     */
    vectorConfigurationStatus: string | ros.IResolvable | undefined;
    /**
     * @Property vpcId: The VPC ID of the instance. If you set the InstanceNetworkType parameter to VPC, you
     * must also specify the VPCId parameter. The specified region of the VPC must be the
     * same as the RegionId value.
     */
    vpcId: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDBInstanceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosDBInstance {
    /**
     * @stability external
     */
    interface AINodeSpecInfosProperty {
        /**
         * @Property aiNodeSpec: The spec of ai node.
         */
        readonly aiNodeSpec: string | ros.IResolvable;
        /**
         * @Property aiNodeNum: The number of ai node.
         */
        readonly aiNodeNum: number | ros.IResolvable;
    }
}
export declare namespace RosDBInstance {
    /**
     * @stability external
     */
    interface TagsProperty {
        /**
         * @Property value: The value of the tag.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: The keyword of the tag.
         */
        readonly key: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosDBInstanceIPArray`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbinstanceiparray
 */
export interface RosDBInstanceIPArrayProps {
    /**
     * @Property dbInstanceId: The instance ID.
     *
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property dbInstanceIpArrayName: The name of the IP address whitelist. If you do not specify this parameter, the default whitelist is queried.
     * >  Each instance supports up to 50 IP address whitelists.
     */
    readonly dbInstanceIpArrayName: string | ros.IResolvable;
    /**
     * @Property securityIpList: The IP address whitelist contains a maximum of 1000 IP addresses separated by commas in the following three formats:
     * - 0.0.0.0\/0
     * - 10.23.12.24(IP)
     * - 10.23.12.24\/24(CIDR mode, Classless Inter-Domain Routing, '\/24' indicates the length of the prefix in the address, and the range is '[1,32]').
     */
    readonly securityIpList: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property dbInstanceIpArrayAttribute: The default is empty. To distinguish between different attribute values, the console does not display groups with the 'hidden' attribute.
     */
    readonly dbInstanceIpArrayAttribute?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::DBInstanceIPArray`.
 * @Note This class does not contain additional functions, so it is recommended to use the `DBInstanceIPArray` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbinstanceiparray
 */
export declare class RosDBInstanceIPArray extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::DBInstanceIPArray";
    /**
     * @Attribute DBInstanceIPArrayAttribute: The default is empty. To distinguish between different attribute values, the console does not display groups with the 'hidden' attribute.
     */
    readonly attrDbInstanceIpArrayAttribute: ros.IResolvable;
    /**
     * @Attribute DBInstanceIPArrayName: The name of the IP address whitelist. If you do not specify this parameter, the default whitelist is queried.
     */
    readonly attrDbInstanceIpArrayName: ros.IResolvable;
    /**
     * @Attribute SecurityIpList: The IP address whitelist contains a maximum of 1000 IP addresses separated by commas in the following three formats:.
     */
    readonly attrSecurityIpList: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property dbInstanceId: The instance ID.
     *
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property dbInstanceIpArrayName: The name of the IP address whitelist. If you do not specify this parameter, the default whitelist is queried.
     * >  Each instance supports up to 50 IP address whitelists.
     */
    dbInstanceIpArrayName: string | ros.IResolvable;
    /**
     * @Property securityIpList: The IP address whitelist contains a maximum of 1000 IP addresses separated by commas in the following three formats:
     * - 0.0.0.0\/0
     * - 10.23.12.24(IP)
     * - 10.23.12.24\/24(CIDR mode, Classless Inter-Domain Routing, '\/24' indicates the length of the prefix in the address, and the range is '[1,32]').
     */
    securityIpList: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property dbInstanceIpArrayAttribute: The default is empty. To distinguish between different attribute values, the console does not display groups with the 'hidden' attribute.
     */
    dbInstanceIpArrayAttribute: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDBInstanceIPArrayProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosDBResourceGroup`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbresourcegroup
 */
export interface RosDBResourceGroupProps {
    /**
     * @Property dbInstanceId: The instance ID.> You can call the [DescribeDBInstances](~~ 86911 ~~) operation to view the instance IDs of all AnalyticDB PostgreSQL instances in the target region.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property resourceGroupConfig: Resource group configuration.
     */
    readonly resourceGroupConfig: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property resourceGroupName: Resource group name.
     */
    readonly resourceGroupName: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::DBResourceGroup`.
 * @Note This class does not contain additional functions, so it is recommended to use the `DBResourceGroup` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-dbresourcegroup
 */
export declare class RosDBResourceGroup extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::DBResourceGroup";
    /**
     * @Attribute ResourceGroupConfig: Resource group configuration.
     */
    readonly attrResourceGroupConfig: ros.IResolvable;
    /**
     * @Attribute ResourceGroupName: Resource group name.
     */
    readonly attrResourceGroupName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property dbInstanceId: The instance ID.> You can call the [DescribeDBInstances](~~ 86911 ~~) operation to view the instance IDs of all AnalyticDB PostgreSQL instances in the target region.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property resourceGroupConfig: Resource group configuration.
     */
    resourceGroupConfig: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property resourceGroupName: Resource group name.
     */
    resourceGroupName: string | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDBResourceGroupProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosDatabase`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-database
 */
export interface RosDatabaseProps {
    /**
     * @Property databaseName: Database Name.
     */
    readonly databaseName: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: Instance ID.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property owner: Data Sheet owner.
     */
    readonly owner: string | ros.IResolvable;
    /**
     * @Property characterSetName: Character set, default value is UTF8.
     */
    readonly characterSetName?: string | ros.IResolvable;
    /**
     * @Property collate: Database locale parameters, specifying string comparison\/collation.
     */
    readonly collate?: string | ros.IResolvable;
    /**
     * @Property ctype: Database locale parameters, specifying character classification\/case conversion rules.
     */
    readonly ctype?: string | ros.IResolvable;
    /**
     * @Property description: Database Description.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::Database`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Database` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-database
 */
export declare class RosDatabase extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::Database";
    /**
     * @Attribute AccessPrivilege: Permission Control Information.
     */
    readonly attrAccessPrivilege: ros.IResolvable;
    /**
     * @Attribute CharacterSetName: Character set, default value is UTF8.
     */
    readonly attrCharacterSetName: ros.IResolvable;
    /**
     * @Attribute Collate: Database locale parameters, specifying string comparison/collation.
     */
    readonly attrCollate: ros.IResolvable;
    /**
     * @Attribute ConnLimit: Maximum connection limit,-1 means unrestricted.
     */
    readonly attrConnLimit: ros.IResolvable;
    /**
     * @Attribute Ctype: Database locale parameters, specifying character classification/case conversion rules.
     */
    readonly attrCtype: ros.IResolvable;
    /**
     * @Attribute DBInstanceId: Instance ID.
     */
    readonly attrDbInstanceId: ros.IResolvable;
    /**
     * @Attribute DatabaseName: Database Name.
     */
    readonly attrDatabaseName: ros.IResolvable;
    /**
     * @Attribute Description: Database Description.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute Owner: Data Sheet owner.
     */
    readonly attrOwner: ros.IResolvable;
    /**
     * @Attribute Size: Database size.
     */
    readonly attrSize: ros.IResolvable;
    /**
     * @Attribute TableSpace: Database table space.
     */
    readonly attrTableSpace: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property databaseName: Database Name.
     */
    databaseName: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: Instance ID.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property owner: Data Sheet owner.
     */
    owner: string | ros.IResolvable;
    /**
     * @Property characterSetName: Character set, default value is UTF8.
     */
    characterSetName: string | ros.IResolvable | undefined;
    /**
     * @Property collate: Database locale parameters, specifying string comparison\/collation.
     */
    collate: string | ros.IResolvable | undefined;
    /**
     * @Property ctype: Database locale parameters, specifying character classification\/case conversion rules.
     */
    ctype: string | ros.IResolvable | undefined;
    /**
     * @Property description: Database Description.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDatabaseProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosElasticDBInstance`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-elasticdbinstance
 */
export interface RosElasticDBInstanceProps {
    /**
     * @Property engineVersion: The version of the database engine. For example: 6.0、7.0
     */
    readonly engineVersion: string | ros.IResolvable;
    /**
     * @Property instanceSpec: The specification of segment nodes. For example: 2C16G, 4C32G, 16C128G.
     */
    readonly instanceSpec: string | ros.IResolvable;
    /**
     * @Property segNodeNum: The number of segment nodes.
     * For the high availability version, the value ranges from 4 to 512.
     * The basic version ranges from 2 to 512.
     */
    readonly segNodeNum: number | ros.IResolvable;
    /**
     * @Property segStorageType: The disk type of segment nodes. For example: cloud_essd, cloud_efficiency.
     */
    readonly segStorageType: string | ros.IResolvable;
    /**
     * @Property storageSize: The storage capacity of per segment node. Unit: GB. Minimum is 50, max is 4000, step is 50.
     */
    readonly storageSize: number | ros.IResolvable;
    /**
     * @Property vSwitchId: The vSwitch ID of the instance.
     */
    readonly vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: The zone ID of the instance, such as cn-hangzhou-d. You can call the DescribeRegions
     * operation to query the most recent zone list.
     */
    readonly zoneId: string | ros.IResolvable;
    /**
     * @Property backupId: Backup set ID. You can call DescribeDataBackups to view the backup set IDs of all backup sets under the target instance.
     */
    readonly backupId?: string | ros.IResolvable;
    /**
     * @Property dbInstanceCategory: DB instance category, valid values: Basic, HighAvailability.
     * This parameter must be passed in to create a storage reservation mode instance.
     */
    readonly dbInstanceCategory?: string | ros.IResolvable;
    /**
     * @Property dbInstanceDescription: The description of the instance. The description cannot exceed 256 characters in length.
     */
    readonly dbInstanceDescription?: string | ros.IResolvable;
    /**
     * @Property dbInstanceMode: The db instance mode. Valid values: StorageElastic, Serverless, Classic.
     */
    readonly dbInstanceMode?: string | ros.IResolvable;
    /**
     * @Property encryptionKey: If the EncryptionType parameter is set to CloudDisk, you must specify this parameter to the encryption key that is in the same region with the disks that is specified by the EncryptionType parameter. Otherwise, leave this parameter empty.
     */
    readonly encryptionKey?: string | ros.IResolvable;
    /**
     * @Property encryptionType: The type of the encryption. Default value: NULL. Valid values:
     * NULL: Encryption is disabled.
     * CloudDisk: Encryption is enabled on disks and the encryption key is specified by using the EncryptionKey parameter.
     * Note: Disk encryption cannot be disabled after it is enabled.
     */
    readonly encryptionType?: string | ros.IResolvable;
    /**
     * @Property masterNodeNum: The number of master nodes. Minimum is 1, max is 2.
     */
    readonly masterNodeNum?: number | ros.IResolvable;
    /**
     * @Property payType: The billing method of the instance. Default value: Postpaid. Valid values:
     * Postpaid: pay-as-you-go
     * Prepaid: subscription
     */
    readonly payType?: string | ros.IResolvable;
    /**
     * @Property period: The subscription period. While choose by pay by month, it could be from 1 to 11. While choose pay by year, it could be from 1 to 3.
     */
    readonly period?: number | ros.IResolvable;
    /**
     * @Property periodUnit: Unit of subscription period, it could be Month\/Year. Default value is Month.
     */
    readonly periodUnit?: string | ros.IResolvable;
    /**
     * @Property privateIpAddress: Private IP address.
     */
    readonly privateIpAddress?: string | ros.IResolvable;
    /**
     * @Property securityIpList: The whitelist of IP addresses that are allowed to access the instance. Default value:
     * 127.0.0.1.
     */
    readonly securityIpList?: string | ros.IResolvable;
    /**
     * @Property srcDbInstanceName: Clone source instance ID. You can call the DescribeDBInstances interface to view the details of all AnalyticDB PostgreSQL instances in the target region, including the instance ID.
     */
    readonly srcDbInstanceName?: string | ros.IResolvable;
    /**
     * @Property tags: The list of instance tags in the form of key\/value pairs.
     * You can define a maximum of 20 tags for instance.
     */
    readonly tags?: RosElasticDBInstance.TagsProperty[];
    /**
     * @Property vpcId: The VPC ID of the instance. If you set the InstanceNetworkType parameter to VPC, you
     * must also specify the VPCId parameter. The specified region of the VPC must be the
     * same as the RegionId value.
     */
    readonly vpcId?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::ElasticDBInstance`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ElasticDBInstance` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-elasticdbinstance
 */
export declare class RosElasticDBInstance extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::ElasticDBInstance";
    /**
     * @Attribute Arn: The Alibaba Cloud Resource Name (ARN).
     */
    readonly attrArn: ros.IResolvable;
    /**
     * @Attribute ConnectionString: The endpoint of the instance.
     */
    readonly attrConnectionString: ros.IResolvable;
    /**
     * @Attribute DBInstanceId: The ID of the instance.
     */
    readonly attrDbInstanceId: ros.IResolvable;
    /**
     * @Attribute OrderId: The order ID of the instance.
     */
    readonly attrOrderId: ros.IResolvable;
    /**
     * @Attribute Port: The port used to connect to the instance.
     */
    readonly attrPort: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property engineVersion: The version of the database engine. For example: 6.0、7.0
     */
    engineVersion: string | ros.IResolvable;
    /**
     * @Property instanceSpec: The specification of segment nodes. For example: 2C16G, 4C32G, 16C128G.
     */
    instanceSpec: string | ros.IResolvable;
    /**
     * @Property segNodeNum: The number of segment nodes.
     * For the high availability version, the value ranges from 4 to 512.
     * The basic version ranges from 2 to 512.
     */
    segNodeNum: number | ros.IResolvable;
    /**
     * @Property segStorageType: The disk type of segment nodes. For example: cloud_essd, cloud_efficiency.
     */
    segStorageType: string | ros.IResolvable;
    /**
     * @Property storageSize: The storage capacity of per segment node. Unit: GB. Minimum is 50, max is 4000, step is 50.
     */
    storageSize: number | ros.IResolvable;
    /**
     * @Property vSwitchId: The vSwitch ID of the instance.
     */
    vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: The zone ID of the instance, such as cn-hangzhou-d. You can call the DescribeRegions
     * operation to query the most recent zone list.
     */
    zoneId: string | ros.IResolvable;
    /**
     * @Property backupId: Backup set ID. You can call DescribeDataBackups to view the backup set IDs of all backup sets under the target instance.
     */
    backupId: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceCategory: DB instance category, valid values: Basic, HighAvailability.
     * This parameter must be passed in to create a storage reservation mode instance.
     */
    dbInstanceCategory: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceDescription: The description of the instance. The description cannot exceed 256 characters in length.
     */
    dbInstanceDescription: string | ros.IResolvable | undefined;
    /**
     * @Property dbInstanceMode: The db instance mode. Valid values: StorageElastic, Serverless, Classic.
     */
    dbInstanceMode: string | ros.IResolvable | undefined;
    /**
     * @Property encryptionKey: If the EncryptionType parameter is set to CloudDisk, you must specify this parameter to the encryption key that is in the same region with the disks that is specified by the EncryptionType parameter. Otherwise, leave this parameter empty.
     */
    encryptionKey: string | ros.IResolvable | undefined;
    /**
     * @Property encryptionType: The type of the encryption. Default value: NULL. Valid values:
     * NULL: Encryption is disabled.
     * CloudDisk: Encryption is enabled on disks and the encryption key is specified by using the EncryptionKey parameter.
     * Note: Disk encryption cannot be disabled after it is enabled.
     */
    encryptionType: string | ros.IResolvable | undefined;
    /**
     * @Property masterNodeNum: The number of master nodes. Minimum is 1, max is 2.
     */
    masterNodeNum: number | ros.IResolvable | undefined;
    /**
     * @Property payType: The billing method of the instance. Default value: Postpaid. Valid values:
     * Postpaid: pay-as-you-go
     * Prepaid: subscription
     */
    payType: string | ros.IResolvable | undefined;
    /**
     * @Property period: The subscription period. While choose by pay by month, it could be from 1 to 11. While choose pay by year, it could be from 1 to 3.
     */
    period: number | ros.IResolvable | undefined;
    /**
     * @Property periodUnit: Unit of subscription period, it could be Month\/Year. Default value is Month.
     */
    periodUnit: string | ros.IResolvable | undefined;
    /**
     * @Property privateIpAddress: Private IP address.
     */
    privateIpAddress: string | ros.IResolvable | undefined;
    /**
     * @Property securityIpList: The whitelist of IP addresses that are allowed to access the instance. Default value:
     * 127.0.0.1.
     */
    securityIpList: string | ros.IResolvable | undefined;
    /**
     * @Property srcDbInstanceName: Clone source instance ID. You can call the DescribeDBInstances interface to view the details of all AnalyticDB PostgreSQL instances in the target region, including the instance ID.
     */
    srcDbInstanceName: string | ros.IResolvable | undefined;
    /**
     * @Property tags: The list of instance tags in the form of key\/value pairs.
     * You can define a maximum of 20 tags for instance.
     */
    tags: RosElasticDBInstance.TagsProperty[] | undefined;
    /**
     * @Property vpcId: The VPC ID of the instance. If you set the InstanceNetworkType parameter to VPC, you
     * must also specify the VPCId parameter. The specified region of the VPC must be the
     * same as the RegionId value.
     */
    vpcId: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosElasticDBInstanceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosElasticDBInstance {
    /**
     * @stability external
     */
    interface TagsProperty {
        /**
         * @Property value: The value of the tag.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: The keyword of the tag.
         */
        readonly key: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosExternalDataService`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-externaldataservice
 */
export interface RosExternalDataServiceProps {
    /**
     * @Property dbInstanceId: Instance ID.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property serviceName: Service Name.
     */
    readonly serviceName: string | ros.IResolvable;
    /**
     * @Property serviceSpec: Service Specifications.
     */
    readonly serviceSpec: number | ros.IResolvable;
    /**
     * @Property serviceDescription: Service Description.
     */
    readonly serviceDescription?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::ExternalDataService`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ExternalDataService` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-externaldataservice
 */
export declare class RosExternalDataService extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::ExternalDataService";
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute ModifyTime: Last modification time.
     */
    readonly attrModifyTime: ros.IResolvable;
    /**
     * @Attribute ServiceDescription: Service Description.
     */
    readonly attrServiceDescription: ros.IResolvable;
    /**
     * @Attribute ServiceId: Service ID.
     */
    readonly attrServiceId: ros.IResolvable;
    /**
     * @Attribute ServiceName: Service Name.
     */
    readonly attrServiceName: ros.IResolvable;
    /**
     * @Attribute ServiceSpec: Service Specifications.
     */
    readonly attrServiceSpec: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property dbInstanceId: Instance ID.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property serviceName: Service Name.
     */
    serviceName: string | ros.IResolvable;
    /**
     * @Property serviceSpec: Service Specifications.
     */
    serviceSpec: number | ros.IResolvable;
    /**
     * @Property serviceDescription: Service Description.
     */
    serviceDescription: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosExternalDataServiceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosInstancePublicConnection`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-instancepublicconnection
 */
export interface RosInstancePublicConnectionProps {
    /**
     * @Property connectionStringPrefix: The endpoint that is used to connect to the specified database.
     */
    readonly connectionStringPrefix: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: The ID of the instance.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property port: The port number of the instance.
     */
    readonly port: number | ros.IResolvable;
    /**
     * @Property addressType: Network type. Valid values:
     *
     * - **primary**: Primary address.
     * - **cluster**: Cluster address, only multi-coordination node instances support creating cluster addresses.
     *
     * > Default is primary address.
     */
    readonly addressType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::InstancePublicConnection`.
 * @Note This class does not contain additional functions, so it is recommended to use the `InstancePublicConnection` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-instancepublicconnection
 */
export declare class RosInstancePublicConnection extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::InstancePublicConnection";
    /**
     * @Attribute ConnectionString: The connection string of the instance.
     */
    readonly attrConnectionString: ros.IResolvable;
    /**
     * @Attribute DBInstanceId: The ID of the instance.
     */
    readonly attrDbInstanceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property connectionStringPrefix: The endpoint that is used to connect to the specified database.
     */
    connectionStringPrefix: string | ros.IResolvable;
    /**
     * @Property dbInstanceId: The ID of the instance.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property port: The port number of the instance.
     */
    port: number | ros.IResolvable;
    /**
     * @Property addressType: Network type. Valid values:
     *
     * - **primary**: Primary address.
     * - **cluster**: Cluster address, only multi-coordination node instances support creating cluster addresses.
     *
     * > Default is primary address.
     */
    addressType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosInstancePublicConnectionProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosJdbcDataSource`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-jdbcdatasource
 */
export interface RosJdbcDataSourceProps {
    /**
     * @Property dbInstanceId: The instance ID.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property jdbcUserName: The name of the database account.
     */
    readonly jdbcUserName: string | ros.IResolvable;
    /**
     * @Property dataSourceDescription: Data Source Description.
     */
    readonly dataSourceDescription?: string | ros.IResolvable;
    /**
     * @Property dataSourceName: Data Source Name.
     */
    readonly dataSourceName?: string | ros.IResolvable;
    /**
     * @Property dataSourceType: Data Source Type.
     */
    readonly dataSourceType?: string | ros.IResolvable;
    /**
     * @Property jdbcConnectionString: The JDBC connection string.
     */
    readonly jdbcConnectionString?: string | ros.IResolvable;
    /**
     * @Property jdbcPassword: The password of the database account.
     */
    readonly jdbcPassword?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::JdbcDataSource`.
 * @Note This class does not contain additional functions, so it is recommended to use the `JdbcDataSource` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-jdbcdatasource
 */
export declare class RosJdbcDataSource extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::JdbcDataSource";
    /**
     * @Attribute ConnectionMessage: Return Information: If the connection fails, an error message is returned. Otherwise, "" is returned "".
     */
    readonly attrConnectionMessage: ros.IResolvable;
    /**
     * @Attribute ConnectionStatus: Service Status:.
     */
    readonly attrConnectionStatus: ros.IResolvable;
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute DataSourceDescription: Data Source Description.
     */
    readonly attrDataSourceDescription: ros.IResolvable;
    /**
     * @Attribute DataSourceId: The data source ID.
     */
    readonly attrDataSourceId: ros.IResolvable;
    /**
     * @Attribute DataSourceName: Data Source Name.
     */
    readonly attrDataSourceName: ros.IResolvable;
    /**
     * @Attribute DataSourceType: Data Source Type.
     */
    readonly attrDataSourceType: ros.IResolvable;
    /**
     * @Attribute ExternalDataServiceId: External Data Service id.
     */
    readonly attrExternalDataServiceId: ros.IResolvable;
    /**
     * @Attribute JdbcConnectionString: The JDBC connection string.
     */
    readonly attrJdbcConnectionString: ros.IResolvable;
    /**
     * @Attribute JdbcPassword: The password of the database account.
     */
    readonly attrJdbcPassword: ros.IResolvable;
    /**
     * @Attribute JdbcUserName: The name of the database account.
     */
    readonly attrJdbcUserName: ros.IResolvable;
    /**
     * @Attribute ModifyTime: Last modification time.
     */
    readonly attrModifyTime: ros.IResolvable;
    /**
     * @Attribute StatusMessage: Service status information, such as exceptions, displays the reason for the exception. A null value in the normal Running state.
     */
    readonly attrStatusMessage: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property dbInstanceId: The instance ID.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property jdbcUserName: The name of the database account.
     */
    jdbcUserName: string | ros.IResolvable;
    /**
     * @Property dataSourceDescription: Data Source Description.
     */
    dataSourceDescription: string | ros.IResolvable | undefined;
    /**
     * @Property dataSourceName: Data Source Name.
     */
    dataSourceName: string | ros.IResolvable | undefined;
    /**
     * @Property dataSourceType: Data Source Type.
     */
    dataSourceType: string | ros.IResolvable | undefined;
    /**
     * @Property jdbcConnectionString: The JDBC connection string.
     */
    jdbcConnectionString: string | ros.IResolvable | undefined;
    /**
     * @Property jdbcPassword: The password of the database account.
     */
    jdbcPassword: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosJdbcDataSourceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosStreamingDataService`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-streamingdataservice
 */
export interface RosStreamingDataServiceProps {
    /**
     * @Property dbInstanceId: The ID of the associated instance.
     */
    readonly dbInstanceId: string | ros.IResolvable;
    /**
     * @Property serviceName: Service Name.
     */
    readonly serviceName: string | ros.IResolvable;
    /**
     * @Property serviceSpec: Resource Specifications.
     */
    readonly serviceSpec: number | ros.IResolvable;
    /**
     * @Property serviceDescription: The description of the service.
     */
    readonly serviceDescription?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::StreamingDataService`.
 * @Note This class does not contain additional functions, so it is recommended to use the `StreamingDataService` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-streamingdataservice
 */
export declare class RosStreamingDataService extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::StreamingDataService";
    /**
     * @Attribute CreateTime: Create time.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute ModifyTime: Modify time.
     */
    readonly attrModifyTime: ros.IResolvable;
    /**
     * @Attribute ServiceDescription: The description of the service.
     */
    readonly attrServiceDescription: ros.IResolvable;
    /**
     * @Attribute ServiceId: Service ID.
     */
    readonly attrServiceId: ros.IResolvable;
    /**
     * @Attribute ServiceIp: Service VIP.
     */
    readonly attrServiceIp: ros.IResolvable;
    /**
     * @Attribute ServiceManaged: Service used by Cloud products, ture is used.
     */
    readonly attrServiceManaged: ros.IResolvable;
    /**
     * @Attribute ServiceName: Service Name.
     */
    readonly attrServiceName: ros.IResolvable;
    /**
     * @Attribute ServiceOwnerId: Service id of Cloud products.
     */
    readonly attrServiceOwnerId: ros.IResolvable;
    /**
     * @Attribute ServicePort: Service vPort.
     */
    readonly attrServicePort: ros.IResolvable;
    /**
     * @Attribute ServiceSpec: Resource Specifications.
     */
    readonly attrServiceSpec: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property dbInstanceId: The ID of the associated instance.
     */
    dbInstanceId: string | ros.IResolvable;
    /**
     * @Property serviceName: Service Name.
     */
    serviceName: string | ros.IResolvable;
    /**
     * @Property serviceSpec: Resource Specifications.
     */
    serviceSpec: number | ros.IResolvable;
    /**
     * @Property serviceDescription: The description of the service.
     */
    serviceDescription: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosStreamingDataServiceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosSupabaseProject`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-supabaseproject
 */
export interface RosSupabaseProjectProps {
    /**
     * @Property accountPassword: The password for the initial account.
     * It consists of three or more types of capital letters, lowercase letters, numbers, and special characters.
     * Supported special characters: !@#$%^&*()_+-=
     * The length is 8~32 characters.
     */
    readonly accountPassword: string | ros.IResolvable;
    /**
     * @Property projectName: Project name.The naming rules are as follows:
     * The length is 1~128 characters.
     * Only English letters, numbers, dash (-) and underscore (_).
     * Must start with English letters or underscores (_).
     */
    readonly projectName: string | ros.IResolvable;
    /**
     * @Property projectSpec: Supabase instance specification, default is 1C1G.
     */
    readonly projectSpec: string | ros.IResolvable;
    /**
     * @Property securityIpList: IP whitelist.
     * 127.0.0.1 means that any external IP access is prohibited. You can call the ModifySecurityIps interface to modify the IP whitelist after the instance is created.
     */
    readonly securityIpList: string | ros.IResolvable;
    /**
     * @Property vpcId: VPC ID.
     * illustrate
     * You can call the DescribeRdsVpcs interface to view the available VPC IDs.
     * This parameter must be passed in.
     */
    readonly vpcId: string | ros.IResolvable;
    /**
     * @Property vSwitchId: vSwitch ID.
     * illustrate
     * vSwitchId is required.
     * The Availability Zone where the vSwitch is located must be consistent with the ZoneId.
     */
    readonly vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: Availability Zone ID.
     * Description You can call the DescribeRegions interface to view the available Availability Zone ID.
     */
    readonly zoneId: string | ros.IResolvable;
    /**
     * @Property databaseIpList: Database IP list.
     */
    readonly databaseIpList?: string | ros.IResolvable;
    /**
     * @Property diskPerformanceLevel: Cloud disk PL level, default PL0. Selectable value:
     * PL0
     * PL1
     */
    readonly diskPerformanceLevel?: string | ros.IResolvable;
    /**
     * @Property payType: The payment type.
     */
    readonly payType?: string | ros.IResolvable;
    /**
     * @Property period: The billing period.
     */
    readonly period?: string | ros.IResolvable;
    /**
     * @Property storageSize: Storage space size, unit GB, default 1GB.
     */
    readonly storageSize?: number | ros.IResolvable;
    /**
     * @Property usedTime: The subscription period of the instance. Unit: month or year. Note When period is set to year, the supported values of this parameter are 1, 2 and 3.
     */
    readonly usedTime?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::GPDB::SupabaseProject`.
 * @Note This class does not contain additional functions, so it is recommended to use the `SupabaseProject` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-gpdb-supabaseproject
 */
export declare class RosSupabaseProject extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::GPDB::SupabaseProject";
    /**
     * @Attribute ApiKeys: API keys
     */
    readonly attrApiKeys: ros.IResolvable;
    /**
     * @Attribute Eni: Network interface
     */
    readonly attrEni: ros.IResolvable;
    /**
     * @Attribute PrivateConnectUrl: Private connection URL
     */
    readonly attrPrivateConnectUrl: ros.IResolvable;
    /**
     * @Attribute ProjectId: Supabase instance ID
     */
    readonly attrProjectId: ros.IResolvable;
    /**
     * @Attribute PublicConnectUrl: Public connection URL
     */
    readonly attrPublicConnectUrl: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property accountPassword: The password for the initial account.
     * It consists of three or more types of capital letters, lowercase letters, numbers, and special characters.
     * Supported special characters: !@#$%^&*()_+-=
     * The length is 8~32 characters.
     */
    accountPassword: string | ros.IResolvable;
    /**
     * @Property projectName: Project name.The naming rules are as follows:
     * The length is 1~128 characters.
     * Only English letters, numbers, dash (-) and underscore (_).
     * Must start with English letters or underscores (_).
     */
    projectName: string | ros.IResolvable;
    /**
     * @Property projectSpec: Supabase instance specification, default is 1C1G.
     */
    projectSpec: string | ros.IResolvable;
    /**
     * @Property securityIpList: IP whitelist.
     * 127.0.0.1 means that any external IP access is prohibited. You can call the ModifySecurityIps interface to modify the IP whitelist after the instance is created.
     */
    securityIpList: string | ros.IResolvable;
    /**
     * @Property vpcId: VPC ID.
     * illustrate
     * You can call the DescribeRdsVpcs interface to view the available VPC IDs.
     * This parameter must be passed in.
     */
    vpcId: string | ros.IResolvable;
    /**
     * @Property vSwitchId: vSwitch ID.
     * illustrate
     * vSwitchId is required.
     * The Availability Zone where the vSwitch is located must be consistent with the ZoneId.
     */
    vSwitchId: string | ros.IResolvable;
    /**
     * @Property zoneId: Availability Zone ID.
     * Description You can call the DescribeRegions interface to view the available Availability Zone ID.
     */
    zoneId: string | ros.IResolvable;
    /**
     * @Property databaseIpList: Database IP list.
     */
    databaseIpList: string | ros.IResolvable | undefined;
    /**
     * @Property diskPerformanceLevel: Cloud disk PL level, default PL0. Selectable value:
     * PL0
     * PL1
     */
    diskPerformanceLevel: string | ros.IResolvable | undefined;
    /**
     * @Property payType: The payment type.
     */
    payType: string | ros.IResolvable | undefined;
    /**
     * @Property period: The billing period.
     */
    period: string | ros.IResolvable | undefined;
    /**
     * @Property storageSize: Storage space size, unit GB, default 1GB.
     */
    storageSize: number | ros.IResolvable | undefined;
    /**
     * @Property usedTime: The subscription period of the instance. Unit: month or year. Note When period is set to year, the supported values of this parameter are 1, 2 and 3.
     */
    usedTime: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosSupabaseProjectProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
