import * as ros from '@alicloud/ros-cdk-core';
import { RosDirectory } from './oss.generated';
export { RosDirectory as DirectoryProperty };
/**
 * Properties for defining a `Directory`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-oss-directory
 */
export interface DirectoryProps {
    /**
     * Property bucketName: bucket name.
     */
    readonly bucketName: string | ros.IResolvable;
    /**
     * Property directoryName: Directory name
     */
    readonly directoryName: string | ros.IResolvable;
    /**
     * Property deletionForce: Whether force delete the relative objects in the directory. Default value is false.
     */
    readonly deletionForce?: boolean | ros.IResolvable;
}
/**
 * Represents a `Directory`.
 */
export interface IDirectory extends ros.IResource {
    readonly props: DirectoryProps;
    /**
     * Attribute BucketName: The name of Bucket
     */
    readonly attrBucketName: ros.IResolvable | string;
    /**
     * Attribute DirectoryName: The name of Directory
     */
    readonly attrDirectoryName: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::OSS::Directory`, which is used to create a directory for a specified bucket.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosDirectory`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-oss-directory
 */
export declare class Directory extends ros.Resource implements IDirectory {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: DirectoryProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute BucketName: The name of Bucket
     */
    readonly attrBucketName: ros.IResolvable | string;
    /**
     * Attribute DirectoryName: The name of Directory
     */
    readonly attrDirectoryName: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: DirectoryProps, enableResourcePropertyConstraint?: boolean);
}
