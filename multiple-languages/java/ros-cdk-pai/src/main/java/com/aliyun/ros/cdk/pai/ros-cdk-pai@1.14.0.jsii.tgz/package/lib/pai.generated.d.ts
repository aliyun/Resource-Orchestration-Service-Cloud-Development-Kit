import * as ros from '@alicloud/ros-cdk-core';
/**
 * Properties for defining a `RosCodeSource`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-codesource
 */
export interface RosCodeSourceProps {
    /**
     * @Property accessibility: Visibility of the code configuration, possible values:
     * - PRIVATE: In this workspace, it is only visible to you and the administrator.
     * - PUBLIC: In this workspace, it is visible to everyone.
     */
    readonly accessibility: string | ros.IResolvable;
    /**
     * @Property codeRepo: Code repository address.
     */
    readonly codeRepo: string | ros.IResolvable;
    /**
     * @Property displayName: Code source configuration name.
     */
    readonly displayName: string | ros.IResolvable;
    /**
     * @Property mountPath: The local Mount Directory of the code.
     */
    readonly mountPath: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property codeBranch: Code repository branch.
     */
    readonly codeBranch?: string | ros.IResolvable;
    /**
     * @Property codeCommit: The code CommitId.
     */
    readonly codeCommit?: string | ros.IResolvable;
    /**
     * @Property codeRepoAccessToken: The Token used to access the code repository.
     */
    readonly codeRepoAccessToken?: string | ros.IResolvable;
    /**
     * @Property codeRepoUserName: The user name of the code repository.
     */
    readonly codeRepoUserName?: string | ros.IResolvable;
    /**
     * @Property description: A detailed description of the code configuration.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::CodeSource`.
 * @Note This class does not contain additional functions, so it is recommended to use the `CodeSource` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-codesource
 */
export declare class RosCodeSource extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::CodeSource";
    /**
     * @Attribute Accessibility: Visibility of the code configuration.
     */
    readonly attrAccessibility: ros.IResolvable;
    /**
     * @Attribute CodeBranch: Code repository branch.
     */
    readonly attrCodeBranch: ros.IResolvable;
    /**
     * @Attribute CodeCommit: The code CommitId.
     */
    readonly attrCodeCommit: ros.IResolvable;
    /**
     * @Attribute CodeRepo: Code repository address.
     */
    readonly attrCodeRepo: ros.IResolvable;
    /**
     * @Attribute CodeRepoAccessToken: The Token used to access the code repository.
     */
    readonly attrCodeRepoAccessToken: ros.IResolvable;
    /**
     * @Attribute CodeRepoUserName: The user name of the code repository.
     */
    readonly attrCodeRepoUserName: ros.IResolvable;
    /**
     * @Attribute CodeSourcesId: The ID of the created code configuration.
     */
    readonly attrCodeSourcesId: ros.IResolvable;
    /**
     * @Attribute CreateTime: The creation time of the code.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute Description: A detailed description of the code configuration.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute DisplayName: Code source configuration name.
     */
    readonly attrDisplayName: ros.IResolvable;
    /**
     * @Attribute GmtModifyTime: Code configuration modification time. The time format is iso8601.
     */
    readonly attrGmtModifyTime: ros.IResolvable;
    /**
     * @Attribute MountPath: The local Mount Directory of the code.
     */
    readonly attrMountPath: ros.IResolvable;
    /**
     * @Attribute UserId: The ID of the creator of the code configuration source.
     */
    readonly attrUserId: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: The ID of the workspace.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property accessibility: Visibility of the code configuration, possible values:
     * - PRIVATE: In this workspace, it is only visible to you and the administrator.
     * - PUBLIC: In this workspace, it is visible to everyone.
     */
    accessibility: string | ros.IResolvable;
    /**
     * @Property codeRepo: Code repository address.
     */
    codeRepo: string | ros.IResolvable;
    /**
     * @Property displayName: Code source configuration name.
     */
    displayName: string | ros.IResolvable;
    /**
     * @Property mountPath: The local Mount Directory of the code.
     */
    mountPath: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property codeBranch: Code repository branch.
     */
    codeBranch: string | ros.IResolvable | undefined;
    /**
     * @Property codeCommit: The code CommitId.
     */
    codeCommit: string | ros.IResolvable | undefined;
    /**
     * @Property codeRepoAccessToken: The Token used to access the code repository.
     */
    codeRepoAccessToken: string | ros.IResolvable | undefined;
    /**
     * @Property codeRepoUserName: The user name of the code repository.
     */
    codeRepoUserName: string | ros.IResolvable | undefined;
    /**
     * @Property description: A detailed description of the code configuration.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCodeSourceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosDataset`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-dataset
 */
export interface RosDatasetProps {
    /**
     * @Property datasetName: The name of the dataset. The naming rules are as follows:
     * - Start with a lowercase letter, uppercase letter, number, or Chinese.
     * - Can contain an underscore (_) or a dash (-).
     * - 1~127 characters in length.
     */
    readonly datasetName: string | ros.IResolvable;
    /**
     * @Property dataSourceType: The data source type. The following values are supported:
     * - OSS: Alibaba Cloud Object Storage (OSS).
     * - NAS: Alibaba cloud file storage (NAS).
     */
    readonly dataSourceType: string | ros.IResolvable;
    /**
     * @Property property: The properties of the dataset. The following values are supported:
     * - FILE: FILE.
     * - DIRECTORY: folder.
     */
    readonly property: string | ros.IResolvable;
    /**
     * @Property uri: The Uri configuration sample is as follows:
     * - The data source type is OSS:'oss:\/\/ bucket.endpoint\/object'
     * - The data source type is NAS:
     * The general NAS format is: 'nas:\/\/<nasfisid>.region\/subpath\/to\/dir\/';
     * CPFS1.0:'nas:\/\/<cpfs-fsid>.region\/subpath\/to\/dir \/';
     * CPFS2.0:'nas:\/\/<cpfs-fsid>.region\/<protocolserviceid>\/'.
     * CPFS1.0 and CPFS2.0 are distinguished by the format of fsid: CPFS1.0 is cpfs-<8-bit ascii characters>;CPFS2.0 is cpfs-<16 ascii characters>.
     */
    readonly uri: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace where the dataset is located.
     * If this parameter is not configured, the default workspace is used. If the default workspace does not exist, an error is reported.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property accessibility: Workspace visibility. The following values are supported:
     * - PRIVATE (default): indicates that the workspace is visible to itself and the administrator.
     * - PUBLIC: The workspace is visible to all users.
     */
    readonly accessibility?: string | ros.IResolvable;
    /**
     * @Property dataType: The dataset type. The default value is COMMON. The following values are supported:
     * - COMMON: COMMON.
     * - PIC: picture.
     * - TEXT: TEXT.
     * - VIDEO: VIDEO.
     * - AUDIO: AUDIO.
     */
    readonly dataType?: string | ros.IResolvable;
    /**
     * @Property description: Custom descriptions of datasets to distinguish between different datasets.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property options: The extended field, which is of the JsonString type.
     * When DLC uses a dataset, you can specify the default Mount path for the dataset by configuring the mountPath field.
     */
    readonly options?: string | ros.IResolvable;
    /**
     * @Property sourceId: The data source ID.
     * - When the SourceType is USER, SourceId can be customized.
     * - When SourceType is ITAG, that is, when the iTAG module labels the data set generated by the result, SourceId is the task ID of ITAG.
     * - When SourceType is PAI_PUBLIC_DATASET, that is, a dataset created using PAI public datasets, SourceId is empty by default.
     */
    readonly sourceId?: string | ros.IResolvable;
    /**
     * @Property sourceType: The data source type. The default value is USER. The following values are supported:
     * - PAI-PUBLIC-DATASET:PAI public dataset.
     * - ITAG: The dataset generated by the iTAG module annotation result.
     * - USER: The data set registered by the USER.
     */
    readonly sourceType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Dataset`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Dataset` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-dataset
 */
export declare class RosDataset extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Dataset";
    /**
     * @Attribute Accessibility: Workspace visibility.
     */
    readonly attrAccessibility: ros.IResolvable;
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute DataSourceType: The data source type.
     */
    readonly attrDataSourceType: ros.IResolvable;
    /**
     * @Attribute DataType: The dataset type. The default value is COMMON.
     */
    readonly attrDataType: ros.IResolvable;
    /**
     * @Attribute DatasetId: The first ID of the resource.
     */
    readonly attrDatasetId: ros.IResolvable;
    /**
     * @Attribute DatasetName: The name of the dataset.
     */
    readonly attrDatasetName: ros.IResolvable;
    /**
     * @Attribute Description: Custom descriptions of datasets to distinguish between different datasets.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute GmtModifiedTime: Update time.
     */
    readonly attrGmtModifiedTime: ros.IResolvable;
    /**
     * @Attribute Options: The extended field, which is of the JsonString type.
     */
    readonly attrOptions: ros.IResolvable;
    /**
     * @Attribute OwnerId: The ID of the primary account.
     */
    readonly attrOwnerId: ros.IResolvable;
    /**
     * @Attribute Property: The properties of the dataset.
     */
    readonly attrProperty: ros.IResolvable;
    /**
     * @Attribute SourceId: The data source ID.
     */
    readonly attrSourceId: ros.IResolvable;
    /**
     * @Attribute SourceType: The data source type. The default value is USER.
     */
    readonly attrSourceType: ros.IResolvable;
    /**
     * @Attribute Uri: The Uri configuration sample is as follows:.
     */
    readonly attrUri: ros.IResolvable;
    /**
     * @Attribute UserId: The ID of the user to which the dataset belongs.
     */
    readonly attrUserId: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: The ID of the workspace where the dataset is located.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property datasetName: The name of the dataset. The naming rules are as follows:
     * - Start with a lowercase letter, uppercase letter, number, or Chinese.
     * - Can contain an underscore (_) or a dash (-).
     * - 1~127 characters in length.
     */
    datasetName: string | ros.IResolvable;
    /**
     * @Property dataSourceType: The data source type. The following values are supported:
     * - OSS: Alibaba Cloud Object Storage (OSS).
     * - NAS: Alibaba cloud file storage (NAS).
     */
    dataSourceType: string | ros.IResolvable;
    /**
     * @Property property: The properties of the dataset. The following values are supported:
     * - FILE: FILE.
     * - DIRECTORY: folder.
     */
    property: string | ros.IResolvable;
    /**
     * @Property uri: The Uri configuration sample is as follows:
     * - The data source type is OSS:'oss:\/\/ bucket.endpoint\/object'
     * - The data source type is NAS:
     * The general NAS format is: 'nas:\/\/<nasfisid>.region\/subpath\/to\/dir\/';
     * CPFS1.0:'nas:\/\/<cpfs-fsid>.region\/subpath\/to\/dir \/';
     * CPFS2.0:'nas:\/\/<cpfs-fsid>.region\/<protocolserviceid>\/'.
     * CPFS1.0 and CPFS2.0 are distinguished by the format of fsid: CPFS1.0 is cpfs-<8-bit ascii characters>;CPFS2.0 is cpfs-<16 ascii characters>.
     */
    uri: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace where the dataset is located.
     * If this parameter is not configured, the default workspace is used. If the default workspace does not exist, an error is reported.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property accessibility: Workspace visibility. The following values are supported:
     * - PRIVATE (default): indicates that the workspace is visible to itself and the administrator.
     * - PUBLIC: The workspace is visible to all users.
     */
    accessibility: string | ros.IResolvable | undefined;
    /**
     * @Property dataType: The dataset type. The default value is COMMON. The following values are supported:
     * - COMMON: COMMON.
     * - PIC: picture.
     * - TEXT: TEXT.
     * - VIDEO: VIDEO.
     * - AUDIO: AUDIO.
     */
    dataType: string | ros.IResolvable | undefined;
    /**
     * @Property description: Custom descriptions of datasets to distinguish between different datasets.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property options: The extended field, which is of the JsonString type.
     * When DLC uses a dataset, you can specify the default Mount path for the dataset by configuring the mountPath field.
     */
    options: string | ros.IResolvable | undefined;
    /**
     * @Property sourceId: The data source ID.
     * - When the SourceType is USER, SourceId can be customized.
     * - When SourceType is ITAG, that is, when the iTAG module labels the data set generated by the result, SourceId is the task ID of ITAG.
     * - When SourceType is PAI_PUBLIC_DATASET, that is, a dataset created using PAI public datasets, SourceId is empty by default.
     */
    sourceId: string | ros.IResolvable | undefined;
    /**
     * @Property sourceType: The data source type. The default value is USER. The following values are supported:
     * - PAI-PUBLIC-DATASET:PAI public dataset.
     * - ITAG: The dataset generated by the iTAG module annotation result.
     * - USER: The data set registered by the USER.
     */
    sourceType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDatasetProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosDatasetVersion`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-datasetversion
 */
export interface RosDatasetVersionProps {
    /**
     * @Property datasetId: The ID of the dataset.
     */
    readonly datasetId: string | ros.IResolvable;
    /**
     * @Property dataSourceType: The data source type. The following values are supported:
     * - OSS: Alibaba Cloud Object Storage (OSS).
     * - NAS: Alibaba cloud file storage (NAS).
     * - CPFS
     */
    readonly dataSourceType: string | ros.IResolvable;
    /**
     * @Property property: The properties of the dataset. The following values are supported:
     * - FILE: FILE.
     * - DIRECTORY: folder.
     */
    readonly property: string | ros.IResolvable;
    /**
     * @Property uri: The Uri configuration sample is as follows:
     * - The data source type is OSS:'oss:\/\/bucket.endpoint\/object'
     * - The data source type is NAS:
     * The general NAS format is: 'nas:\/\/<nasfisid>.region\/subpath\/to\/dir\/';
     * CPFS1.0:'nas:\/\/<cpfs-fsid>.region\/subpath\/to\/dir \/';
     * CPFS2.0:'nas:\/\/<cpfs-fsid>.region\/<protocolserviceid>\/'.
     * CPFS1.0 and CPFS2.0 are distinguished by the format of fsid: CPFS1.0 is cpfs-<8-bit ascii characters>;CPFS2.0 is cpfs-<16 ascii characters>.
     */
    readonly uri: string | ros.IResolvable;
    /**
     * @Property dataCount: The number of dataset files, in units of pieces.
     */
    readonly dataCount?: number | ros.IResolvable;
    /**
     * @Property dataSize: The size of the dataset file in bytes.
     */
    readonly dataSize?: number | ros.IResolvable;
    /**
     * @Property description: To create a custom description for dataset versions in order to distinguish between different versions of the dataset.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property labels: Dataset version tag list.
     */
    readonly labels?: Array<RosDatasetVersion.LabelsProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property options: The extended field, which is of the JsonString type.
     * When DLC uses a dataset, you can specify the default Mount path for the dataset by configuring the mountPath field.
     */
    readonly options?: string | ros.IResolvable;
    /**
     * @Property sourceId: The data source ID.
     * - When the SourceType is USER, SourceId can be customized.
     * - When SourceType is ITAG, that is, when the iTAG module labels the data set generated by the result, SourceId is the task ID of ITAG.
     * - When SourceType is PAI_PUBLIC_DATASET, that is, a dataset created using PAI public datasets, SourceId is empty by default.
     */
    readonly sourceId?: string | ros.IResolvable;
    /**
     * @Property sourceType: The data source type. The default value is USER. The following values are supported:
     * - PAI-PUBLIC-DATASET:PAI public dataset.
     * - ITAG: The dataset generated by the iTAG module annotation result.
     * - USER: The data set registered by the USER.
     */
    readonly sourceType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::DatasetVersion`.
 * @Note This class does not contain additional functions, so it is recommended to use the `DatasetVersion` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-datasetversion
 */
export declare class RosDatasetVersion extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::DatasetVersion";
    /**
     * @Attribute VersionName: Dataset version name.
     */
    readonly attrVersionName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property datasetId: The ID of the dataset.
     */
    datasetId: string | ros.IResolvable;
    /**
     * @Property dataSourceType: The data source type. The following values are supported:
     * - OSS: Alibaba Cloud Object Storage (OSS).
     * - NAS: Alibaba cloud file storage (NAS).
     * - CPFS
     */
    dataSourceType: string | ros.IResolvable;
    /**
     * @Property property: The properties of the dataset. The following values are supported:
     * - FILE: FILE.
     * - DIRECTORY: folder.
     */
    property: string | ros.IResolvable;
    /**
     * @Property uri: The Uri configuration sample is as follows:
     * - The data source type is OSS:'oss:\/\/bucket.endpoint\/object'
     * - The data source type is NAS:
     * The general NAS format is: 'nas:\/\/<nasfisid>.region\/subpath\/to\/dir\/';
     * CPFS1.0:'nas:\/\/<cpfs-fsid>.region\/subpath\/to\/dir \/';
     * CPFS2.0:'nas:\/\/<cpfs-fsid>.region\/<protocolserviceid>\/'.
     * CPFS1.0 and CPFS2.0 are distinguished by the format of fsid: CPFS1.0 is cpfs-<8-bit ascii characters>;CPFS2.0 is cpfs-<16 ascii characters>.
     */
    uri: string | ros.IResolvable;
    /**
     * @Property dataCount: The number of dataset files, in units of pieces.
     */
    dataCount: number | ros.IResolvable | undefined;
    /**
     * @Property dataSize: The size of the dataset file in bytes.
     */
    dataSize: number | ros.IResolvable | undefined;
    /**
     * @Property description: To create a custom description for dataset versions in order to distinguish between different versions of the dataset.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property labels: Dataset version tag list.
     */
    labels: Array<RosDatasetVersion.LabelsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property options: The extended field, which is of the JsonString type.
     * When DLC uses a dataset, you can specify the default Mount path for the dataset by configuring the mountPath field.
     */
    options: string | ros.IResolvable | undefined;
    /**
     * @Property sourceId: The data source ID.
     * - When the SourceType is USER, SourceId can be customized.
     * - When SourceType is ITAG, that is, when the iTAG module labels the data set generated by the result, SourceId is the task ID of ITAG.
     * - When SourceType is PAI_PUBLIC_DATASET, that is, a dataset created using PAI public datasets, SourceId is empty by default.
     */
    sourceId: string | ros.IResolvable | undefined;
    /**
     * @Property sourceType: The data source type. The default value is USER. The following values are supported:
     * - PAI-PUBLIC-DATASET:PAI public dataset.
     * - ITAG: The dataset generated by the iTAG module annotation result.
     * - USER: The data set registered by the USER.
     */
    sourceType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosDatasetVersionProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosDatasetVersion {
    /**
     * @stability external
     */
    interface LabelsProperty {
        /**
         * @Property value: The value of the tag. Maximum 128 bytes, does not support equal signs (=) and half-width commas (,).
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: The key of the tag. Maximum 128 bytes, does not support equal signs (=) and half-width commas (,).
         */
        readonly key: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosExperiment`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-experiment
 */
export interface RosExperimentProps {
    /**
     * @Property artifactUri: ArtifactUri is default OSS storage path of the output of trials in the experiment.
     */
    readonly artifactUri: string | ros.IResolvable;
    /**
     * @Property experimentName: Name is the name of the experiment, unique in a namespace.
     */
    readonly experimentName: string | ros.IResolvable;
    /**
     * @Property workspaceId: WorkspaceId is the workspace id which contains the experiment.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property accessibility: Experimental Visibility.
     */
    readonly accessibility?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Experiment`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Experiment` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-experiment
 */
export declare class RosExperiment extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Experiment";
    /**
     * @Attribute Accessibility: Experimental Visibility.
     */
    readonly attrAccessibility: ros.IResolvable;
    /**
     * @Attribute ArtifactUri: ArtifactUri is default OSS storage path of the output of trials in the experiment.
     */
    readonly attrArtifactUri: ros.IResolvable;
    /**
     * @Attribute CreateTime: GmtCreateTime is time when this entity is created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute ExperimentId: ExperimentId is globally unique identifier of the experiment.
     */
    readonly attrExperimentId: ros.IResolvable;
    /**
     * @Attribute ExperimentName: Name is the name of the experiment, unique in a namespace.
     */
    readonly attrExperimentName: ros.IResolvable;
    /**
     * @Attribute GmtModifiedTime: GmtModifiedTime is time when this entity is modified.
     */
    readonly attrGmtModifiedTime: ros.IResolvable;
    /**
     * @Attribute Labels: Labels are tags of the experiment.
     */
    readonly attrLabels: ros.IResolvable;
    /**
     * @Attribute OwnerId: OwnerId is the user account id which this entity belongs to.
     */
    readonly attrOwnerId: ros.IResolvable;
    /**
     * @Attribute TensorboardLogUri: TensorboardLogUri is the default OSS storage path of tensorboard log of trials in the experiment.
     */
    readonly attrTensorboardLogUri: ros.IResolvable;
    /**
     * @Attribute UserId: UserId is the user account id which created this entity.
     */
    readonly attrUserId: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: WorkspaceId is the workspace id which contains the experiment.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property artifactUri: ArtifactUri is default OSS storage path of the output of trials in the experiment.
     */
    artifactUri: string | ros.IResolvable;
    /**
     * @Property experimentName: Name is the name of the experiment, unique in a namespace.
     */
    experimentName: string | ros.IResolvable;
    /**
     * @Property workspaceId: WorkspaceId is the workspace id which contains the experiment.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property accessibility: Experimental Visibility.
     */
    accessibility: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosExperimentProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosImage`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-image
 */
export interface RosImageProps {
    /**
     * @Property imageName: The image name.
     */
    readonly imageName: string | ros.IResolvable;
    /**
     * @Property imageUri: The Image address, which contains the version number.
     */
    readonly imageUri: string | ros.IResolvable;
    /**
     * @Property accessibility: Visibility of the mirror, possible values:
     * - PUBLIC: all members of the current workspace can operate.
     * - PRIVATE: Only the creator can operate.
     */
    readonly accessibility?: string | ros.IResolvable;
    /**
     * @Property labels: Labels.
     */
    readonly labels?: Array<RosImage.LabelsProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the image belongs.
     */
    readonly workspaceId?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Image`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Image` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-image
 */
export declare class RosImage extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Image";
    /**
     * @Attribute Accessibility: Visibility of the mirror.
     */
    readonly attrAccessibility: ros.IResolvable;
    /**
     * @Attribute ImageName: The image name.
     */
    readonly attrImageName: ros.IResolvable;
    /**
     * @Attribute ImageUri: The Image address, which contains the version number.
     */
    readonly attrImageUri: ros.IResolvable;
    /**
     * @Attribute Labels: Labels.
     */
    readonly attrLabels: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: The ID of the workspace to which the image belongs.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property imageName: The image name.
     */
    imageName: string | ros.IResolvable;
    /**
     * @Property imageUri: The Image address, which contains the version number.
     */
    imageUri: string | ros.IResolvable;
    /**
     * @Property accessibility: Visibility of the mirror, possible values:
     * - PUBLIC: all members of the current workspace can operate.
     * - PRIVATE: Only the creator can operate.
     */
    accessibility: string | ros.IResolvable | undefined;
    /**
     * @Property labels: Labels.
     */
    labels: Array<RosImage.LabelsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property workspaceId: The ID of the workspace to which the image belongs.
     */
    workspaceId: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosImageProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosImage {
    /**
     * @stability external
     */
    interface LabelsProperty {
        /**
         * @Property value: value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: Key.
         */
        readonly key: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosMember`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-member
 */
export interface RosMemberProps {
    /**
     * @Property roles: The list of roles.
     */
    readonly roles: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property userId: User ID.
     */
    readonly userId: string | ros.IResolvable;
    /**
     * @Property workspaceId: Workspace ID.
     */
    readonly workspaceId: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Member`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Member` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-member
 */
export declare class RosMember extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Member";
    /**
     * @Attribute CreateTime: Create UTC time in ISO8601 format.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute DisplayName: Member display name.
     */
    readonly attrDisplayName: ros.IResolvable;
    /**
     * @Attribute MemberId: The member ID.
     */
    readonly attrMemberId: ros.IResolvable;
    /**
     * @Attribute MemberName: The name of user.
     */
    readonly attrMemberName: ros.IResolvable;
    /**
     * @Attribute Roles: The list of roles.
     */
    readonly attrRoles: ros.IResolvable;
    /**
     * @Attribute UserId: The first ID of the resource.
     */
    readonly attrUserId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property roles: The list of roles.
     */
    roles: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property userId: User ID.
     */
    userId: string | ros.IResolvable;
    /**
     * @Property workspaceId: Workspace ID.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosMemberProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosModelVersion`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-modelversion
 */
export interface RosModelVersionProps {
    /**
     * @Property modelId: Model ID. For details about how to obtain the model ID.
     */
    readonly modelId: string | ros.IResolvable;
    /**
     * @Property uri: Model version URI, that is, the location where the model is stored. Possible values are:
     * - The HTTP(S) address of the model, for example: 'https:\/\/myweb.com\/mymodel.tar.gz '.
     * - If the model is stored in OSS, the format is 'oss:\/\/<bucket>.<endpoint>\/object '. For the endpoint configuration, see [Access domain name and data center](~~ 31837 ~~). For example, see OSS:\/\/ mybucket\/'.
     */
    readonly uri: string | ros.IResolvable;
    /**
     * @Property approvalStatus: Admission status, with values as follows:
     * - Pending: to be determined.
     * - Approved: Allow to go online.
     * - Rejected: Online is not allowed.
     */
    readonly approvalStatus?: string | ros.IResolvable;
    /**
     * @Property extraInfo: The additional information.
     */
    readonly extraInfo?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property formatType: Model format, possible values:
     * - OfflineModel
     * - SavedModel
     * - Keras H5
     * - Frozen Pb
     * - Caffe Prototxt
     * - TorchScript
     * - XGBoost
     * - PMML
     * - AlinkModel
     * - ONNX.
     */
    readonly formatType?: string | ros.IResolvable;
    /**
     * @Property frameworkType: Model framework, possible values:
     * - Pytorch
     * - XGBoost
     * - Keras
     * - Caffe
     * - Alink
     * - Xflow
     * - TensorFlow.
     */
    readonly frameworkType?: string | ros.IResolvable;
    /**
     * @Property inferenceSpec: Describes how to apply to downstream inference services. For example, describe the processor and container of EAS. Example: { "processor": "tensorflow_gpu_1.12" }
     */
    readonly inferenceSpec?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property labels: List of model version labels.
     */
    readonly labels?: Array<RosModelVersion.LabelsProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property metrics: The metrics for the model. The length after serialization is limited to 8,192. Example:
     * { "Results": [{ "Dataset": { "DatasetId": "d-sdkjanksaklerhfd" }, "Metrics": { "cer": 0.175 } }, { "Dataset": { "Uri": "oss:\/\/xxxx\/" }, "Metrics": { "cer": 0.172 } }] }
     */
    readonly metrics?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property options: The extended field. This is a JSON string.
     */
    readonly options?: string | ros.IResolvable;
    /**
     * @Property sourceId: Source ID.
     * * When the source type is Custom, this field is not restricted.
     * * When the source is PAIFlow or TrainingService, the format is:
     * region=<region_id>,workspaceId=<workspace_id>,kind=<kind>,id=<id>
     * Among them:
     * - region is the Alibaba Cloud region ID.
     * - workspaceId indicates the workspace ID.
     * - kind: is a type. Value: PipelineRun(PAIFlow workflow);ServiceJob (training service).
     * - id: is a unique identifier.
     */
    readonly sourceId?: string | ros.IResolvable;
    /**
     * @Property sourceType: Model source type, possible values:
     * - Custom: Custom.
     * - PAIFlow:PAI workflow.
     * - TrainingService:PAI training service.
     */
    readonly sourceType?: string | ros.IResolvable;
    /**
     * @Property trainingSpec: Training configuration. Configuration for fine-tuning, incremental training.
     */
    readonly trainingSpec?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property versionDescription: Model version description.
     */
    readonly versionDescription?: string | ros.IResolvable;
    /**
     * @Property versionName: The model version, which is unique for each model. If you leave this parameter empty, the first version is 0.1.0 by default. After that, the minor version number is increased by 1 in sequence. For example, the second version number is 0.2.0. A version number consists of a major version number, a minor version number, and a stage version number, separated by periods (.). The major version number and minor version number are numeric. The stage version number begins with a digit and can include numbers, underscores, and letters. For example, the version number is 1.1.0 or 2.3.4_beta.
     */
    readonly versionName?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::ModelVersion`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ModelVersion` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-modelversion
 */
export declare class RosModelVersion extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::ModelVersion";
    /**
     * @Attribute ApprovalStatus: Admission status, with values as follows:.
     */
    readonly attrApprovalStatus: ros.IResolvable;
    /**
     * @Attribute ExtraInfo: Other information.
     */
    readonly attrExtraInfo: ros.IResolvable;
    /**
     * @Attribute FormatType: Model format, possible values:.
     */
    readonly attrFormatType: ros.IResolvable;
    /**
     * @Attribute FrameworkType: Model framework, possible values:.
     */
    readonly attrFrameworkType: ros.IResolvable;
    /**
     * @Attribute GmtCreateTime: Create a model UTC time in the format ISO8601.
     */
    readonly attrGmtCreateTime: ros.IResolvable;
    /**
     * @Attribute GmtModifiedTime: Finally, update the model UTC time in the format iso8601.
     */
    readonly attrGmtModifiedTime: ros.IResolvable;
    /**
     * @Attribute InferenceSpec: Describes how to apply to downstream inference services, such as processors and containers of EAS.
     */
    readonly attrInferenceSpec: ros.IResolvable;
    /**
     * @Attribute Labels: List of model version labels.
     */
    readonly attrLabels: ros.IResolvable;
    /**
     * @Attribute Metrics: Model indicators.
     */
    readonly attrMetrics: ros.IResolvable;
    /**
     * @Attribute Options: Extension field. The JsonString type.
     */
    readonly attrOptions: ros.IResolvable;
    /**
     * @Attribute OwnerId: The Alibaba Cloud account ID.
     */
    readonly attrOwnerId: ros.IResolvable;
    /**
     * @Attribute SourceId: Source ID.
     */
    readonly attrSourceId: ros.IResolvable;
    /**
     * @Attribute SourceType: Model source type, possible values:.
     */
    readonly attrSourceType: ros.IResolvable;
    /**
     * @Attribute TrainingSpec: Training configuration. Configuration for fine-tuning, incremental training.
     */
    readonly attrTrainingSpec: ros.IResolvable;
    /**
     * @Attribute Uri: Model version URI, that is, the location where the model is stored.
     */
    readonly attrUri: ros.IResolvable;
    /**
     * @Attribute UserId: The user ID.
     */
    readonly attrUserId: ros.IResolvable;
    /**
     * @Attribute VersionDescription: Model version description.
     */
    readonly attrVersionDescription: ros.IResolvable;
    /**
     * @Attribute VersionName: Model version.
     */
    readonly attrVersionName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property modelId: Model ID. For details about how to obtain the model ID.
     */
    modelId: string | ros.IResolvable;
    /**
     * @Property uri: Model version URI, that is, the location where the model is stored. Possible values are:
     * - The HTTP(S) address of the model, for example: 'https:\/\/myweb.com\/mymodel.tar.gz '.
     * - If the model is stored in OSS, the format is 'oss:\/\/<bucket>.<endpoint>\/object '. For the endpoint configuration, see [Access domain name and data center](~~ 31837 ~~). For example, see OSS:\/\/ mybucket\/'.
     */
    uri: string | ros.IResolvable;
    /**
     * @Property approvalStatus: Admission status, with values as follows:
     * - Pending: to be determined.
     * - Approved: Allow to go online.
     * - Rejected: Online is not allowed.
     */
    approvalStatus: string | ros.IResolvable | undefined;
    /**
     * @Property extraInfo: The additional information.
     */
    extraInfo: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property formatType: Model format, possible values:
     * - OfflineModel
     * - SavedModel
     * - Keras H5
     * - Frozen Pb
     * - Caffe Prototxt
     * - TorchScript
     * - XGBoost
     * - PMML
     * - AlinkModel
     * - ONNX.
     */
    formatType: string | ros.IResolvable | undefined;
    /**
     * @Property frameworkType: Model framework, possible values:
     * - Pytorch
     * - XGBoost
     * - Keras
     * - Caffe
     * - Alink
     * - Xflow
     * - TensorFlow.
     */
    frameworkType: string | ros.IResolvable | undefined;
    /**
     * @Property inferenceSpec: Describes how to apply to downstream inference services. For example, describe the processor and container of EAS. Example: { "processor": "tensorflow_gpu_1.12" }
     */
    inferenceSpec: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property labels: List of model version labels.
     */
    labels: Array<RosModelVersion.LabelsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property metrics: The metrics for the model. The length after serialization is limited to 8,192. Example:
     * { "Results": [{ "Dataset": { "DatasetId": "d-sdkjanksaklerhfd" }, "Metrics": { "cer": 0.175 } }, { "Dataset": { "Uri": "oss:\/\/xxxx\/" }, "Metrics": { "cer": 0.172 } }] }
     */
    metrics: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property options: The extended field. This is a JSON string.
     */
    options: string | ros.IResolvable | undefined;
    /**
     * @Property sourceId: Source ID.
     * * When the source type is Custom, this field is not restricted.
     * * When the source is PAIFlow or TrainingService, the format is:
     * region=<region_id>,workspaceId=<workspace_id>,kind=<kind>,id=<id>
     * Among them:
     * - region is the Alibaba Cloud region ID.
     * - workspaceId indicates the workspace ID.
     * - kind: is a type. Value: PipelineRun(PAIFlow workflow);ServiceJob (training service).
     * - id: is a unique identifier.
     */
    sourceId: string | ros.IResolvable | undefined;
    /**
     * @Property sourceType: Model source type, possible values:
     * - Custom: Custom.
     * - PAIFlow:PAI workflow.
     * - TrainingService:PAI training service.
     */
    sourceType: string | ros.IResolvable | undefined;
    /**
     * @Property trainingSpec: Training configuration. Configuration for fine-tuning, incremental training.
     */
    trainingSpec: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property versionDescription: Model version description.
     */
    versionDescription: string | ros.IResolvable | undefined;
    /**
     * @Property versionName: The model version, which is unique for each model. If you leave this parameter empty, the first version is 0.1.0 by default. After that, the minor version number is increased by 1 in sequence. For example, the second version number is 0.2.0. A version number consists of a major version number, a minor version number, and a stage version number, separated by periods (.). The major version number and minor version number are numeric. The stage version number begins with a digit and can include numbers, underscores, and letters. For example, the version number is 1.1.0 or 2.3.4_beta.
     */
    versionName: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosModelVersionProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosModelVersion {
    /**
     * @stability external
     */
    interface LabelsProperty {
        /**
         * @Property value: label value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: label key.
         */
        readonly key?: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosQuota`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-quota
 */
export interface RosQuotaProps {
    /**
     * @Property quotaName: The name of the quota.
     */
    readonly quotaName: string | ros.IResolvable;
    /**
     * @Property allocateStrategy: The allocation strategy.
     */
    readonly allocateStrategy?: string | ros.IResolvable;
    /**
     * @Property clusterSpec: The cluster specification.
     */
    readonly clusterSpec?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property description: The description of the quota.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property labels: The labels associated with the quota.
     */
    readonly labels?: Array<RosQuota.LabelsProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property min: The minimum resource allocation configuration.
     */
    readonly min?: RosQuota.MinProperty | ros.IResolvable;
    /**
     * @Property parentQuotaId: The ID of the parent quota.
     */
    readonly parentQuotaId?: string | ros.IResolvable;
    /**
     * @Property queueStrategy: The queue strategy.
     */
    readonly queueStrategy?: string | ros.IResolvable;
    /**
     * @Property quotaConfig: The quota configuration.
     */
    readonly quotaConfig?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property resourceGroupIds: The list of resource group IDs.
     */
    readonly resourceGroupIds?: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property resourceType: The type of the resource.
     */
    readonly resourceType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Quota`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Quota` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-quota
 */
export declare class RosQuota extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Quota";
    /**
     * @Attribute QuotaId: The ID of the quota.
     */
    readonly attrQuotaId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property quotaName: The name of the quota.
     */
    quotaName: string | ros.IResolvable;
    /**
     * @Property allocateStrategy: The allocation strategy.
     */
    allocateStrategy: string | ros.IResolvable | undefined;
    /**
     * @Property clusterSpec: The cluster specification.
     */
    clusterSpec: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property description: The description of the quota.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property labels: The labels associated with the quota.
     */
    labels: Array<RosQuota.LabelsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property min: The minimum resource allocation configuration.
     */
    min: RosQuota.MinProperty | ros.IResolvable | undefined;
    /**
     * @Property parentQuotaId: The ID of the parent quota.
     */
    parentQuotaId: string | ros.IResolvable | undefined;
    /**
     * @Property queueStrategy: The queue strategy.
     */
    queueStrategy: string | ros.IResolvable | undefined;
    /**
     * @Property quotaConfig: The quota configuration.
     */
    quotaConfig: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @Property resourceGroupIds: The list of resource group IDs.
     */
    resourceGroupIds: Array<string | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property resourceType: The type of the resource.
     */
    resourceType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosQuotaProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosQuota {
    /**
     * @stability external
     */
    interface LabelsProperty {
        /**
         * @Property value: undefined
         */
        readonly value: string | ros.IResolvable;
        /**
         * @Property key: undefined
         */
        readonly key: string | ros.IResolvable;
    }
}
export declare namespace RosQuota {
    /**
     * @stability external
     */
    interface MinProperty {
        /**
         * @Property resourceAmount: The resource amount.
         */
        readonly resourceAmount?: {
            [key: string]: (any | ros.IResolvable);
        } | ros.IResolvable;
        /**
         * @Property nodeSpecs: The node specification.
         */
        readonly nodeSpecs?: Array<{
            [key: string]: any;
        }> | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosResourceGroup`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-resourcegroup
 */
export interface RosResourceGroupProps {
    /**
     * @Property computingResourceProvider: The computing resource provider of the resource group.
     */
    readonly computingResourceProvider?: string | ros.IResolvable;
    /**
     * @Property description: The description of the resource group.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property name: The name of the resource group.
     */
    readonly name?: string | ros.IResolvable;
    /**
     * @Property resourceGroupId: Resource group id.
     */
    readonly resourceGroupId?: string | ros.IResolvable;
    /**
     * @Property resourceType: The type of the resource group.
     */
    readonly resourceType?: string | ros.IResolvable;
    /**
     * @Property tag: The tags of the resource group.
     */
    readonly tag?: Array<ros.RosTag | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property userVpc: User VPC configuration containing network settings for the resource group
     */
    readonly userVpc?: RosResourceGroup.UserVpcProperty | ros.IResolvable;
    /**
     * @Property version: The version of the resource group.
     */
    readonly version?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::ResourceGroup`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ResourceGroup` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-resourcegroup
 */
export declare class RosResourceGroup extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::ResourceGroup";
    /**
     * @Attribute ResourceGroupID: The ID of the resource group.
     */
    readonly attrResourceGroupId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property computingResourceProvider: The computing resource provider of the resource group.
     */
    computingResourceProvider: string | ros.IResolvable | undefined;
    /**
     * @Property description: The description of the resource group.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property name: The name of the resource group.
     */
    name: string | ros.IResolvable | undefined;
    /**
     * @Property resourceGroupId: Resource group id.
     */
    resourceGroupId: string | ros.IResolvable | undefined;
    /**
     * @Property resourceType: The type of the resource group.
     */
    resourceType: string | ros.IResolvable | undefined;
    /**
     * @Property tag: The tags of the resource group.
     */
    tag: Array<ros.RosTag | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property userVpc: User VPC configuration containing network settings for the resource group
     */
    userVpc: RosResourceGroup.UserVpcProperty | ros.IResolvable | undefined;
    /**
     * @Property version: The version of the resource group.
     */
    version: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosResourceGroupProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosResourceGroup {
    /**
     * @stability external
     */
    interface DefaultForwardInfoProperty {
        /**
         * @Property eipAllocationId: The allocation ID of the Elastic IP Address (EIP) for public network access
         */
        readonly eipAllocationId?: string | ros.IResolvable;
        /**
         * @Property natGatewayId: The unique identifier of the NAT Gateway for network address translation
         */
        readonly natGatewayId?: string | ros.IResolvable;
    }
}
export declare namespace RosResourceGroup {
    /**
     * @stability external
     */
    interface TagProperty {
        /**
         * @Property value: Value
         */
        readonly value: string | ros.IResolvable;
        /**
         * @Property key: Key
         */
        readonly key: string | ros.IResolvable;
    }
}
export declare namespace RosResourceGroup {
    /**
     * @stability external
     */
    interface UserVpcProperty {
        /**
         * @Property vpcId: The unique identifier of the Virtual Private Cloud (VPC) where the resource group is located
         */
        readonly vpcId: string | ros.IResolvable;
        /**
         * @Property securityGroupId: The unique identifier of the security group that controls network access rules for the resource group
         */
        readonly securityGroupId: string | ros.IResolvable;
        /**
         * @Property defaultRoute: The default route configuration specifying the default forwarding path for network traffic
         */
        readonly defaultRoute?: string | ros.IResolvable;
        /**
         * @Property switchId: The unique identifier of the vSwitch within the VPC for network connectivity
         */
        readonly switchId: string | ros.IResolvable;
        /**
         * @Property defaultForwardInfo: Default forwarding information configuration including NAT gateway and EIP settings for network traffic forwarding
         */
        readonly defaultForwardInfo?: RosResourceGroup.DefaultForwardInfoProperty | ros.IResolvable;
        /**
         * @Property extendedCidRs: List of extended CIDR blocks for additional network address ranges
         */
        readonly extendedCidRs?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property roleArn: The Amazon Resource Name (ARN) of the RAM role for authorizing access to other cloud services
         */
        readonly roleArn?: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosRun`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-run
 */
export interface RosRunProps {
    /**
     * @Property experimentId: Resource attribute field of the experiment ID to which Run belongs.
     */
    readonly experimentId: string | ros.IResolvable;
    /**
     * @Property runName: The name of the Run.
     */
    readonly runName?: string | ros.IResolvable;
    /**
     * @Property sourceId: Attribute Resource field representing the source task ID.
     */
    readonly sourceId?: string | ros.IResolvable;
    /**
     * @Property sourceType: Resource attribute fields representing the source type.
     */
    readonly sourceType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Run`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Run` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-run
 */
export declare class RosRun extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Run";
    /**
     * @Attribute Accessibility: Resource attribute fields representing visibility.
     */
    readonly attrAccessibility: ros.IResolvable;
    /**
     * @Attribute CreateTime: The creation time of the Run.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute ExperimentId: Resource attribute field of the experiment ID to which Run belongs.
     */
    readonly attrExperimentId: ros.IResolvable;
    /**
     * @Attribute GmtModifiedTime: Resource attribute fields representing edit time.
     */
    readonly attrGmtModifiedTime: ros.IResolvable;
    /**
     * @Attribute Labels: Run attribute field representing the run tag.
     */
    readonly attrLabels: ros.IResolvable;
    /**
     * @Attribute Metrics: Resource attribute field representing the run metric.
     */
    readonly attrMetrics: ros.IResolvable;
    /**
     * @Attribute OwnerId: Resource attribute field representing owner.
     */
    readonly attrOwnerId: ros.IResolvable;
    /**
     * @Attribute Params: Resource attribute field representing the run parameter.
     */
    readonly attrParams: ros.IResolvable;
    /**
     * @Attribute RunId: The ID of the Run.
     */
    readonly attrRunId: ros.IResolvable;
    /**
     * @Attribute RunName: The name of the Run.
     */
    readonly attrRunName: ros.IResolvable;
    /**
     * @Attribute SourceId: Attribute Resource field representing the source task ID.
     */
    readonly attrSourceId: ros.IResolvable;
    /**
     * @Attribute SourceType: Run attribute fields representing the source type.
     */
    readonly attrSourceType: ros.IResolvable;
    /**
     * @Attribute UserId: Run attribute field representing creator ID.
     */
    readonly attrUserId: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: Resource attribute field of the workspace ID to which Run belongs.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property experimentId: Resource attribute field of the experiment ID to which Run belongs.
     */
    experimentId: string | ros.IResolvable;
    /**
     * @Property runName: The name of the Run.
     */
    runName: string | ros.IResolvable | undefined;
    /**
     * @Property sourceId: Attribute Resource field representing the source task ID.
     */
    sourceId: string | ros.IResolvable | undefined;
    /**
     * @Property sourceType: Resource attribute fields representing the source type.
     */
    sourceType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosRunProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosService`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-service
 */
export interface RosServiceProps {
    /**
     * @Property serviceConfig: Service configuration information.
     */
    readonly serviceConfig: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property develop: Whether to enter the development mode.
     */
    readonly develop?: string | ros.IResolvable;
    /**
     * @Property labels: Service Tag.
     */
    readonly labels?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Service`, which is used to create an Elastic Algorithm Service (EAS) service in Machine Learning Platform for AI (PAI).
 * @Note This class does not contain additional functions, so it is recommended to use the `Service` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-service
 */
export declare class RosService extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Service";
    /**
     * @Attribute AccessToken: Service Request authentication token.
     */
    readonly attrAccessToken: ros.IResolvable;
    /**
     * @Attribute CallerUid: The ID of the service creator, which can be the ID of the RAM account.
     */
    readonly attrCallerUid: ros.IResolvable;
    /**
     * @Attribute Cpu: Number of service CPU cores.
     */
    readonly attrCpu: ros.IResolvable;
    /**
     * @Attribute CreateTime: Creation time of the service.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute CurrentVersion: Current running version of the service.
     */
    readonly attrCurrentVersion: ros.IResolvable;
    /**
     * @Attribute ExtraData: Service Extra Information.
     */
    readonly attrExtraData: ros.IResolvable;
    /**
     * @Attribute Gpu: Number of service GPU cards.
     */
    readonly attrGpu: ros.IResolvable;
    /**
     * @Attribute Image: Service Deployment Mirroring.
     */
    readonly attrImage: ros.IResolvable;
    /**
     * @Attribute InternetEndpoint: Public network Endpoint of the service.
     */
    readonly attrInternetEndpoint: ros.IResolvable;
    /**
     * @Attribute IntranetEndpoint: The intranet Endpoint of the service.
     */
    readonly attrIntranetEndpoint: ros.IResolvable;
    /**
     * @Attribute Labels: Service Tag.
     */
    readonly attrLabels: ros.IResolvable;
    /**
     * @Attribute LatestVersion: The latest version of the service.
     */
    readonly attrLatestVersion: ros.IResolvable;
    /**
     * @Attribute Memory: Memory of service (MB).
     */
    readonly attrMemory: ros.IResolvable;
    /**
     * @Attribute Message: Latest information on services.
     */
    readonly attrMessage: ros.IResolvable;
    /**
     * @Attribute Namespace: The namespace to which the service belongs.
     */
    readonly attrNamespace: ros.IResolvable;
    /**
     * @Attribute ParentUid: Primary account ID of the creator.
     */
    readonly attrParentUid: ros.IResolvable;
    /**
     * @Attribute PendingInstance: Number of instances where the service is not currently ready.
     */
    readonly attrPendingInstance: ros.IResolvable;
    /**
     * @Attribute Reason: Service deployment failure reason.
     */
    readonly attrReason: ros.IResolvable;
    /**
     * @Attribute Resource: The ID of the resource group to which the service belongs.
     */
    readonly attrResource: ros.IResolvable;
    /**
     * @Attribute ResourceAlias: Name of the resource group where the service resides.
     */
    readonly attrResourceAlias: ros.IResolvable;
    /**
     * @Attribute Role: Grouping Service Role.
     */
    readonly attrRole: ros.IResolvable;
    /**
     * @Attribute RoleAttrs: Grouping Service Role Properties.
     */
    readonly attrRoleAttrs: ros.IResolvable;
    /**
     * @Attribute RunningInstance: Number of instances in service running.
     */
    readonly attrRunningInstance: ros.IResolvable;
    /**
     * @Attribute SafetyLock: Service Security Lock Status.
     */
    readonly attrSafetyLock: ros.IResolvable;
    /**
     * @Attribute ServiceConfig: Service configuration information.
     */
    readonly attrServiceConfig: ros.IResolvable;
    /**
     * @Attribute ServiceGroup: Group to which the service belongs.
     */
    readonly attrServiceGroup: ros.IResolvable;
    /**
     * @Attribute ServiceName: Service Name.
     */
    readonly attrServiceName: ros.IResolvable;
    /**
     * @Attribute ServiceUid: Unique Service ID.
     */
    readonly attrServiceUid: ros.IResolvable;
    /**
     * @Attribute TotalInstance: Total number of instances required by the service.
     */
    readonly attrTotalInstance: ros.IResolvable;
    /**
     * @Attribute UpdateTime: Service Last Updated.
     */
    readonly attrUpdateTime: ros.IResolvable;
    /**
     * @Attribute Weight: Packet Service Traffic Weight.
     */
    readonly attrWeight: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property serviceConfig: Service configuration information.
     */
    serviceConfig: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
    /**
     * @Property develop: Whether to enter the development mode.
     */
    develop: string | ros.IResolvable | undefined;
    /**
     * @Property labels: Service Tag.
     */
    labels: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosServiceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosUserConfig`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-userconfig
 */
export interface RosUserConfigProps {
    /**
     * @Property categoryName: Represents a resource attribute for a configuration category.
     */
    readonly categoryName: string | ros.IResolvable;
    /**
     * @Property configKey: Represents the resource attribute of the configuration Key.
     */
    readonly configKey: string | ros.IResolvable;
    /**
     * @Property configs: Represents a resource property for the configuration list.
     */
    readonly configs?: Array<RosUserConfig.ConfigsProperty | ros.IResolvable> | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::UserConfig`.
 * @Note This class does not contain additional functions, so it is recommended to use the `UserConfig` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-userconfig
 */
export declare class RosUserConfig extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::UserConfig";
    /**
     * @Attribute CategoryName: Represents a resource attribute for a configuration category.
     */
    readonly attrCategoryName: ros.IResolvable;
    /**
     * @Attribute ConfigKey: Represents the resource attribute of the configuration Key.
     */
    readonly attrConfigKey: ros.IResolvable;
    /**
     * @Attribute Configs: Represents a resource property for the configuration list.
     */
    readonly attrConfigs: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property categoryName: Represents a resource attribute for a configuration category.
     */
    categoryName: string | ros.IResolvable;
    /**
     * @Property configKey: Represents the resource attribute of the configuration Key.
     */
    configKey: string | ros.IResolvable;
    /**
     * @Property configs: Represents a resource property for the configuration list.
     */
    configs: Array<RosUserConfig.ConfigsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosUserConfigProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosUserConfig {
    /**
     * @stability external
     */
    interface ConfigsProperty {
        /**
         * @Property configValue: Resource attributes that represent configuration values.
         */
        readonly configValue?: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosWorkspace`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspace
 */
export interface RosWorkspaceProps {
    /**
     * @Property description: Workspace description, no more than 80 characters.
     */
    readonly description: string | ros.IResolvable;
    /**
     * @Property envTypes: Environments contained in the workspace:
     * - Simple mode only production environment (prod).
     * - Standard mode includes development environment (dev) and production environment (prod).
     */
    readonly envTypes: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceName: The workspace name. The format is as follows:
     * - 3 to 23 characters in length and can contain letters, underscores, or numbers.
     * - Must start with a large or small letter.
     * - Unique in the current region.
     */
    readonly workspaceName: string | ros.IResolvable;
    /**
     * @Property displayName: It is recommended that you name the workspace based on the business attribute to identify the purpose of the workspace. If not configured, the default value is the workspace name. The format is as follows:
     * - 3 to 23 characters in length and can contain letters, underscores, or numbers.
     * - Must start with a large or small letter.
     * - Unique in the current region.
     */
    readonly displayName?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::Workspace`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Workspace` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspace
 */
export declare class RosWorkspace extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::Workspace";
    /**
     * @Attribute AdminNames: List of administrator account names.
     */
    readonly attrAdminNames: ros.IResolvable;
    /**
     * @Attribute Creator: The user ID of the creator.
     */
    readonly attrCreator: ros.IResolvable;
    /**
     * @Attribute Description: Workspace description, no more than 80 characters.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute DisplayName: It is recommended that you name the workspace based on the business attribute to identify the purpose of the workspace. If not configured, the default value is the workspace name.
     */
    readonly attrDisplayName: ros.IResolvable;
    /**
     * @Attribute EnvTypes: Environments contained in the workspace:.
     */
    readonly attrEnvTypes: ros.IResolvable;
    /**
     * @Attribute ExtraInfos: Additional information, currently including TenantId (tenant ID).
     */
    readonly attrExtraInfos: ros.IResolvable;
    /**
     * @Attribute Owner: Workspace owner ID, displayed when Verbose is true.
     */
    readonly attrOwner: ros.IResolvable;
    /**
     * @Attribute Users: List of users.
     */
    readonly attrUsers: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: The ID of the workspace.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    /**
     * @Attribute WorkspaceName: The workspace name.
     */
    readonly attrWorkspaceName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property description: Workspace description, no more than 80 characters.
     */
    description: string | ros.IResolvable;
    /**
     * @Property envTypes: Environments contained in the workspace:
     * - Simple mode only production environment (prod).
     * - Standard mode includes development environment (dev) and production environment (prod).
     */
    envTypes: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceName: The workspace name. The format is as follows:
     * - 3 to 23 characters in length and can contain letters, underscores, or numbers.
     * - Must start with a large or small letter.
     * - Unique in the current region.
     */
    workspaceName: string | ros.IResolvable;
    /**
     * @Property displayName: It is recommended that you name the workspace based on the business attribute to identify the purpose of the workspace. If not configured, the default value is the workspace name. The format is as follows:
     * - 3 to 23 characters in length and can contain letters, underscores, or numbers.
     * - Must start with a large or small letter.
     * - Unique in the current region.
     */
    displayName: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWorkspaceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosWorkspaceResource`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresource
 */
export interface RosWorkspaceResourceProps {
    /**
     * @Property envType: Environment type, possible values:
     * - dev: Development environment.
     * - prod: Production environment.
     */
    readonly envType: string | ros.IResolvable;
    /**
     * @Property resourceType: The resource types. Valid values:
     * MaxCompute
     * ECS
     * Lingjun
     * ACS
     * FLINK
     */
    readonly resourceType: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property workspaceResourceName: The resource name.
     */
    readonly workspaceResourceName: string | ros.IResolvable;
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources](~~ 449143 ~~).
     */
    readonly groupName?: string | ros.IResolvable;
    /**
     * @Property isDefault: Whether it is the default resource, each resource type has a default resource. Possible values:
     * - true: is the default resource.
     * - false: Not the default resource.
     */
    readonly isDefault?: boolean | ros.IResolvable;
    /**
     * @Property spec: Resource configuration, required for public resource groups of DLC, enter the content: {"clusterType": "share"}.
     */
    readonly spec?: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::WorkspaceResource`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WorkspaceResource` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresource
 */
export declare class RosWorkspaceResource extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::WorkspaceResource";
    /**
     * @Attribute CreateTime: Create UTC time in ISO8601 format.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute EnvType: Environment type, possible values:.
     */
    readonly attrEnvType: ros.IResolvable;
    /**
     * @Attribute GroupName: Resource group name. If you want to obtain a resource group name, see [ListResources](~~ 449143 ~~).
     */
    readonly attrGroupName: ros.IResolvable;
    /**
     * @Attribute IsDefault: Whether it is the default resource, each resource type has a default resource.
     */
    readonly attrIsDefault: ros.IResolvable;
    /**
     * @Attribute ResourceId: The resource ID.
     */
    readonly attrResourceId: ros.IResolvable;
    /**
     * @Attribute ResourceType: Resource type, possible values:.
     */
    readonly attrResourceType: ros.IResolvable;
    /**
     * @Attribute Spec: Resource configuration, required for public resource groups of DLC, enter the content.
     */
    readonly attrSpec: ros.IResolvable;
    /**
     * @Attribute WorkspaceId: The ID of the workspace to which the workspace belongs.
     */
    readonly attrWorkspaceId: ros.IResolvable;
    /**
     * @Attribute WorkspaceResourceName: The resource name.
     */
    readonly attrWorkspaceResourceName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property envType: Environment type, possible values:
     * - dev: Development environment.
     * - prod: Production environment.
     */
    envType: string | ros.IResolvable;
    /**
     * @Property resourceType: The resource types. Valid values:
     * MaxCompute
     * ECS
     * Lingjun
     * ACS
     * FLINK
     */
    resourceType: string | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property workspaceResourceName: The resource name.
     */
    workspaceResourceName: string | ros.IResolvable;
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources](~~ 449143 ~~).
     */
    groupName: string | ros.IResolvable | undefined;
    /**
     * @Property isDefault: Whether it is the default resource, each resource type has a default resource. Possible values:
     * - true: is the default resource.
     * - false: Not the default resource.
     */
    isDefault: boolean | ros.IResolvable | undefined;
    /**
     * @Property spec: Resource configuration, required for public resource groups of DLC, enter the content: {"clusterType": "share"}.
     */
    spec: {
        [key: string]: (any | ros.IResolvable);
    } | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWorkspaceResourceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosWorkspaceResourceDlc`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourcedlc
 */
export interface RosWorkspaceResourceDlcProps {
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    readonly groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    readonly resources: Array<RosWorkspaceResourceDlc.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly isDefault?: boolean | ros.IResolvable;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    readonly option?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::WorkspaceResourceDlc`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WorkspaceResourceDlc` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourcedlc
 */
export declare class RosWorkspaceResourceDlc extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::WorkspaceResourceDlc";
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute GroupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    readonly attrGroupName: ros.IResolvable;
    /**
     * @Attribute IsDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly attrIsDefault: ros.IResolvable;
    /**
     * @Attribute Resources: Resource List.
     */
    readonly attrResources: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    resources: Array<RosWorkspaceResourceDlc.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    isDefault: boolean | ros.IResolvable | undefined;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    option: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWorkspaceResourceDlcProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosWorkspaceResourceDlc {
    /**
     * @stability external
     */
    interface ResourcesProperty {
        /**
         * @Property workspaceResourceWorkspaceId: ID of the workspace to which the resource information belongs.
         */
        readonly workspaceResourceWorkspaceId: string | ros.IResolvable;
        /**
         * @Property workspaceResourceName: Resource name, 3 to 28 characters in length, unique within each locale. Starts with the required letter and can contain only letters, numbers, and underscores (_).
         */
        readonly workspaceResourceName: string | ros.IResolvable;
        /**
         * @Property spec: Resource Specifications.
         */
        readonly spec?: {
            [key: string]: (any | ros.IResolvable);
        } | ros.IResolvable;
        /**
         * @Property envType: Environment, Support:
     * - dev: Development
     * - prod: Production.
         */
        readonly envType: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosWorkspaceResourceFlink`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourceflink
 */
export interface RosWorkspaceResourceFlinkProps {
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    readonly groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    readonly resources: Array<RosWorkspaceResourceFlink.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly isDefault?: boolean | ros.IResolvable;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    readonly option?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::WorkspaceResourceFlink`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WorkspaceResourceFlink` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourceflink
 */
export declare class RosWorkspaceResourceFlink extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::WorkspaceResourceFlink";
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute GroupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    readonly attrGroupName: ros.IResolvable;
    /**
     * @Attribute IsDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly attrIsDefault: ros.IResolvable;
    /**
     * @Attribute Resources: Resource List.
     */
    readonly attrResources: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name, see [ListResources].
     */
    groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    resources: Array<RosWorkspaceResourceFlink.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    isDefault: boolean | ros.IResolvable | undefined;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    option: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWorkspaceResourceFlinkProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosWorkspaceResourceFlink {
    /**
     * @stability external
     */
    interface ResourcesProperty {
        /**
         * @Property workspaceResourceWorkspaceId: ID of the workspace to which the resource information belongs.
         */
        readonly workspaceResourceWorkspaceId: string | ros.IResolvable;
        /**
         * @Property workspaceResourceName: Resource name, 3 to 28 characters in length, unique within each locale. Starts with the required letter and can contain only letters, numbers, and underscores (_).
         */
        readonly workspaceResourceName: string | ros.IResolvable;
        /**
         * @Property spec: Resource Specifications.
         */
        readonly spec?: {
            [key: string]: (any | ros.IResolvable);
        } | ros.IResolvable;
        /**
         * @Property envType: Environment, Support:
     * - dev: Development
     * - prod: Production.
         */
        readonly envType: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosWorkspaceResourceMaxCompute`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourcemaxcompute
 */
export interface RosWorkspaceResourceMaxComputeProps {
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name.
     */
    readonly groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    readonly resources: Array<RosWorkspaceResourceMaxCompute.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    readonly workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly isDefault?: boolean | ros.IResolvable;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    readonly option?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::PAI::WorkspaceResourceMaxCompute`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WorkspaceResourceMaxCompute` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-pai-workspaceresourcemaxcompute
 */
export declare class RosWorkspaceResourceMaxCompute extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::PAI::WorkspaceResourceMaxCompute";
    /**
     * @Attribute CreateTime: The creation time of the resource.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute GroupName: Resource group name.
     */
    readonly attrGroupName: ros.IResolvable;
    /**
     * @Attribute IsDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    readonly attrIsDefault: ros.IResolvable;
    /**
     * @Attribute Resources: Resource List.
     */
    readonly attrResources: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property groupName: Resource group name. If you want to obtain a resource group name.
     */
    groupName: string | ros.IResolvable;
    /**
     * @Property resources: Resource List.
     */
    resources: Array<RosWorkspaceResourceMaxCompute.ResourcesProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property workspaceId: The ID of the workspace to which the workspace belongs.
     */
    workspaceId: string | ros.IResolvable;
    /**
     * @Property isDefault: Indicates whether it is the default resource. Currently, this parameter only supports the input of true and does not support false.
     */
    isDefault: boolean | ros.IResolvable | undefined;
    /**
     * @Property option: Create behavior that supports the following values:
     * - CreateAndAttach: Create resource and bind to workspace
     * - Attach: bind resource to workspace.
     */
    option: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWorkspaceResourceMaxComputeProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosWorkspaceResourceMaxCompute {
    /**
     * @stability external
     */
    interface QuotasProperty {
        /**
         * @Property quotaId: The resource quota ID.
     * Obtain the ID of the Quota through ListQuotas.
         */
        readonly quotaId: string | ros.IResolvable;
    }
}
export declare namespace RosWorkspaceResourceMaxCompute {
    /**
     * @stability external
     */
    interface ResourcesProperty {
        /**
         * @Property workspaceResourceWorkspaceId: ID of the workspace to which the resource information belongs.
         */
        readonly workspaceResourceWorkspaceId: string | ros.IResolvable;
        /**
         * @Property quotas: The list of resource quotas. Currently, only MaxCompute resources have resource quotas.
         */
        readonly quotas?: Array<RosWorkspaceResourceMaxCompute.QuotasProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property workspaceResourceName: Resource name, 3 to 28 characters in length, unique within each locale. Starts with the required letter and can contain only letters, numbers, and underscores (_).
         */
        readonly workspaceResourceName: string | ros.IResolvable;
        /**
         * @Property spec: Resource Specifications.
         */
        readonly spec?: {
            [key: string]: (any | ros.IResolvable);
        } | ros.IResolvable;
        /**
         * @Property envType: Environment, Support:
     * - dev: Development
     * - prod: Production.
         */
        readonly envType: string | ros.IResolvable;
    }
}
