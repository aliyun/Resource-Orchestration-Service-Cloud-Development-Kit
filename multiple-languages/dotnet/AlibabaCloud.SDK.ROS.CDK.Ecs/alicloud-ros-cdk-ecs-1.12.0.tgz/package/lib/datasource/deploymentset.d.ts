import * as ros from '@alicloud/ros-cdk-core';
import { RosDeploymentSet } from './ecs.generated';
export { RosDeploymentSet as DeploymentSetProperty };
/**
 * Properties for defining a `DeploymentSet`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-ecs-deploymentset
 */
export interface DeploymentSetProps {
    /**
     * Property deploymentSetId: The ID of deployment set.
     */
    readonly deploymentSetId: string | ros.IResolvable;
    /**
     * Property refreshOptions: The refresh strategy for the datasource resource when the stack is updated. Valid values:
     * - Never: Never refresh the datasource resource when the stack is updated.
     * - Always: Always refresh the datasource resource when the stack is updated.
     * Default is Never.
     */
    readonly refreshOptions?: string | ros.IResolvable;
}
/**
 * Represents a `DeploymentSet`.
 */
export interface IDeploymentSet extends ros.IResource {
    readonly props: DeploymentSetProps;
    /**
     * Attribute CreateTime: The time when the deployment set was created.
     */
    readonly attrCreateTime: ros.IResolvable | string;
    /**
     * Attribute DeploymentSetId: The ID of deployment set.
     */
    readonly attrDeploymentSetId: ros.IResolvable | string;
    /**
     * Attribute DeploymentSetName: The name of the deployment set.
     */
    readonly attrDeploymentSetName: ros.IResolvable | string;
    /**
     * Attribute Granularity: The deployment granularity.
     */
    readonly attrGranularity: ros.IResolvable | string;
    /**
     * Attribute GroupCount: The number of deployment set groups in the deployment set.
     */
    readonly attrGroupCount: ros.IResolvable | string;
    /**
     * Attribute InstanceAmount: The number of instances in the deployment set.
     */
    readonly attrInstanceAmount: ros.IResolvable | string;
    /**
     * Attribute InstanceIds: The IDs of the instances in the deployment set.
     */
    readonly attrInstanceIds: ros.IResolvable | string;
    /**
     * Attribute Strategy: The deployment strategy.
     */
    readonly attrStrategy: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `DATASOURCE::ECS::DeploymentSet`, which is used to query the information about a deployment set.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosDeploymentSet`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-ecs-deploymentset
 */
export declare class DeploymentSet extends ros.Resource implements IDeploymentSet {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: DeploymentSetProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute CreateTime: The time when the deployment set was created.
     */
    readonly attrCreateTime: ros.IResolvable | string;
    /**
     * Attribute DeploymentSetId: The ID of deployment set.
     */
    readonly attrDeploymentSetId: ros.IResolvable | string;
    /**
     * Attribute DeploymentSetName: The name of the deployment set.
     */
    readonly attrDeploymentSetName: ros.IResolvable | string;
    /**
     * Attribute Granularity: The deployment granularity.
     */
    readonly attrGranularity: ros.IResolvable | string;
    /**
     * Attribute GroupCount: The number of deployment set groups in the deployment set.
     */
    readonly attrGroupCount: ros.IResolvable | string;
    /**
     * Attribute InstanceAmount: The number of instances in the deployment set.
     */
    readonly attrInstanceAmount: ros.IResolvable | string;
    /**
     * Attribute InstanceIds: The IDs of the instances in the deployment set.
     */
    readonly attrInstanceIds: ros.IResolvable | string;
    /**
     * Attribute Strategy: The deployment strategy.
     */
    readonly attrStrategy: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: DeploymentSetProps, enableResourcePropertyConstraint?: boolean);
}
