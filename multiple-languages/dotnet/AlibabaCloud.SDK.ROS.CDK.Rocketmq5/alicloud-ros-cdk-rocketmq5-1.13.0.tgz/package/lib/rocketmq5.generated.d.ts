import * as ros from '@alicloud/ros-cdk-core';
/**
 * Properties for defining a `RosAccount`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-account
 */
export interface RosAccountProps {
    /**
     * @Property instanceId: The unifed ID of the instance.
     */
    readonly instanceId: string | ros.IResolvable;
    /**
     * @Property password: Account password
     * Length Limit: 3~64 characters.
     */
    readonly password: string | ros.IResolvable;
    /**
     * @Property username: Account Name
     * Length Limit: 3~64 characters
     * Character limit: Supports letters a ~ z or A ~ Z, numbers 0~9, underscore (_) and dash (-).
     */
    readonly username: string | ros.IResolvable;
    /**
     * @Property accountStatus: Account Status
     * DISABLE: DISABLE.
     * ENABLE: Enabled.
     */
    readonly accountStatus?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ROCKETMQ5::Account`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Account` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-account
 */
export declare class RosAccount extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ROCKETMQ5::Account";
    /**
     * @Attribute AccountStatus: Account Status.
     */
    readonly attrAccountStatus: ros.IResolvable;
    /**
     * @Attribute Password: Account password.
     */
    readonly attrPassword: ros.IResolvable;
    /**
     * @Attribute Username: Account Name.
     */
    readonly attrUsername: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property instanceId: The unifed ID of the instance.
     */
    instanceId: string | ros.IResolvable;
    /**
     * @Property password: Account password
     * Length Limit: 3~64 characters.
     */
    password: string | ros.IResolvable;
    /**
     * @Property username: Account Name
     * Length Limit: 3~64 characters
     * Character limit: Supports letters a ~ z or A ~ Z, numbers 0~9, underscore (_) and dash (-).
     */
    username: string | ros.IResolvable;
    /**
     * @Property accountStatus: Account Status
     * DISABLE: DISABLE.
     * ENABLE: Enabled.
     */
    accountStatus: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosAccountProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosAcl`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-acl
 */
export interface RosAclProps {
    /**
     * @Property actions: The type of operation authorized.
     */
    readonly actions: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property decision: The decision result of the authorization. Valid values:
     * * Deny: Access is denied.
     * * Allow: Allow access.
     */
    readonly decision: string | ros.IResolvable;
    /**
     * @Property instanceId: The ID of the RocketMQ instance.
     */
    readonly instanceId: string | ros.IResolvable;
    /**
     * @Property resourceName: The name of the resource on which you want to grant permissions.
     */
    readonly resourceName: string | ros.IResolvable;
    /**
     * @Property resourceType: The type of the resource on which you want to grant permissions. Valid values:
     * * Group: consumer Group.
     * * Topic: Topic.
     */
    readonly resourceType: string | ros.IResolvable;
    /**
     * @Property username: The username of the account.
     */
    readonly username: string | ros.IResolvable;
    /**
     * @Property ipWhitelists: The IP addresses in the whitelist.
     */
    readonly ipWhitelists?: Array<string | ros.IResolvable> | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ROCKETMQ5::Acl`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Acl` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-acl
 */
export declare class RosAcl extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ROCKETMQ5::Acl";
    /**
     * @Attribute Actions: The type of operation authorized.
     */
    readonly attrActions: ros.IResolvable;
    /**
     * @Attribute Decision: The decision result of the authorization.
     */
    readonly attrDecision: ros.IResolvable;
    /**
     * @Attribute InstanceId: The ID of the RocketMQ instance.
     */
    readonly attrInstanceId: ros.IResolvable;
    /**
     * @Attribute IpWhitelists: The IP addresses in the whitelist.
     */
    readonly attrIpWhitelists: ros.IResolvable;
    /**
     * @Attribute ResourceName: The name of the resource on which you want to grant permissions.
     */
    readonly attrResourceName: ros.IResolvable;
    /**
     * @Attribute ResourceType: The type of the resource on which you want to grant permissions.
     */
    readonly attrResourceType: ros.IResolvable;
    /**
     * @Attribute Username: The username of the account.
     */
    readonly attrUsername: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property actions: The type of operation authorized.
     */
    actions: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property decision: The decision result of the authorization. Valid values:
     * * Deny: Access is denied.
     * * Allow: Allow access.
     */
    decision: string | ros.IResolvable;
    /**
     * @Property instanceId: The ID of the RocketMQ instance.
     */
    instanceId: string | ros.IResolvable;
    /**
     * @Property resourceName: The name of the resource on which you want to grant permissions.
     */
    resourceName: string | ros.IResolvable;
    /**
     * @Property resourceType: The type of the resource on which you want to grant permissions. Valid values:
     * * Group: consumer Group.
     * * Topic: Topic.
     */
    resourceType: string | ros.IResolvable;
    /**
     * @Property username: The username of the account.
     */
    username: string | ros.IResolvable;
    /**
     * @Property ipWhitelists: The IP addresses in the whitelist.
     */
    ipWhitelists: Array<string | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosAclProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosConsumerGroup`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-consumergroup
 */
export interface RosConsumerGroupProps {
    /**
     * @Property consumeRetryPolicy: The consumption retry policy of the consumer group to be created.
     */
    readonly consumeRetryPolicy: RosConsumerGroup.ConsumeRetryPolicyProperty | ros.IResolvable;
    /**
     * @Property consumerGroupId: The ID of the consumer group to be created. Used to identify consumer groups, globally unique.
     * The value description is as follows:
     * Character limitation: supports letters a~z or A-Z, numbers 0-9, underscore (_), dash (-) and percent sign (%).
     * Length limit: 1-60 characters.
     */
    readonly consumerGroupId: string | ros.IResolvable;
    /**
     * @Property deliveryOrderType: Delivery sequence of the consumer group to be created.
     */
    readonly deliveryOrderType: string | ros.IResolvable;
    /**
     * @Property instanceId: The ID of the instance.
     */
    readonly instanceId: string | ros.IResolvable;
    /**
     * @Property remark: The remark of the consumer group to be created.
     */
    readonly remark?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ROCKETMQ5::ConsumerGroup`, which is used to create a consumer group in ApsaraMQ for RocketMQ 5.0.
 * @Note This class does not contain additional functions, so it is recommended to use the `ConsumerGroup` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-consumergroup
 */
export declare class RosConsumerGroup extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ROCKETMQ5::ConsumerGroup";
    /**
     * @Attribute ConsumerGroupId: The ID of the consumer group.
     */
    readonly attrConsumerGroupId: ros.IResolvable;
    /**
     * @Attribute DeliveryOrderType: Delivery sequence of consumer group.
     */
    readonly attrDeliveryOrderType: ros.IResolvable;
    /**
     * @Attribute InstanceId: The ID of the instance.
     */
    readonly attrInstanceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property consumeRetryPolicy: The consumption retry policy of the consumer group to be created.
     */
    consumeRetryPolicy: RosConsumerGroup.ConsumeRetryPolicyProperty | ros.IResolvable;
    /**
     * @Property consumerGroupId: The ID of the consumer group to be created. Used to identify consumer groups, globally unique.
     * The value description is as follows:
     * Character limitation: supports letters a~z or A-Z, numbers 0-9, underscore (_), dash (-) and percent sign (%).
     * Length limit: 1-60 characters.
     */
    consumerGroupId: string | ros.IResolvable;
    /**
     * @Property deliveryOrderType: Delivery sequence of the consumer group to be created.
     */
    deliveryOrderType: string | ros.IResolvable;
    /**
     * @Property instanceId: The ID of the instance.
     */
    instanceId: string | ros.IResolvable;
    /**
     * @Property remark: The remark of the consumer group to be created.
     */
    remark: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosConsumerGroupProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosConsumerGroup {
    /**
     * @stability external
     */
    interface ConsumeRetryPolicyProperty {
        /**
         * @Property deadLetterTargetTopic: The dead letter topic of the consumer group.
         */
        readonly deadLetterTargetTopic?: string | ros.IResolvable;
        /**
         * @Property retryPolicy: Retry policy type.
         */
        readonly retryPolicy: string | ros.IResolvable;
        /**
         * @Property maxRetryTimes: Maximum number of retries.
         */
        readonly maxRetryTimes?: number | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosInstance`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-instance
 */
export interface RosInstanceProps {
    /**
     * @Property internetInfo: Public network configuration information.
     */
    readonly internetInfo: RosInstance.InternetInfoProperty | ros.IResolvable;
    /**
     * @Property productInfo: Instance specification information.
     */
    readonly productInfo: RosInstance.ProductInfoProperty | ros.IResolvable;
    /**
     * @Property seriesCode: The primary series code of the instance.
     */
    readonly seriesCode: string | ros.IResolvable;
    /**
     * @Property subSeriesCode: The sub series code of the instance.
     */
    readonly subSeriesCode: string | ros.IResolvable;
    /**
     * @Property vpcInfo: Private network configuration information.
     */
    readonly vpcInfo: RosInstance.VpcInfoProperty | ros.IResolvable;
    /**
     * @Property autoRenew: Whether to auto-renew. This parameter takes effect only when the PaymentType=Subscription.
     */
    readonly autoRenew?: boolean | ros.IResolvable;
    /**
     * @Property autoRenewPeriod: Automatic renewal period. This parameter is valid only when automatic renewal is enabled. Unit: Month.
     */
    readonly autoRenewPeriod?: number | ros.IResolvable;
    /**
     * @Property instanceName: The name of the instance to be created.
     */
    readonly instanceName?: string | ros.IResolvable;
    /**
     * @Property paymentType: The sub series code of the instance.
     */
    readonly paymentType?: string | ros.IResolvable;
    /**
     * @Property period: The subscription duration. Valid values:
     * When Period is Month, it could be from 1 to 6, 12, 24, 36.
     *  When Period is Year, it could be from 1 to 3.
     */
    readonly period?: number | ros.IResolvable;
    /**
     * @Property periodUnit: The period unit for the duration of the instance.
     */
    readonly periodUnit?: string | ros.IResolvable;
    /**
     * @Property remark: The remark of instance.
     */
    readonly remark?: string | ros.IResolvable;
    /**
     * @Property resourceGroupId: Resource group ID.
     */
    readonly resourceGroupId?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ROCKETMQ5::Instance`.
 * @Note This class does not contain additional functions, so it is recommended to use the `Instance` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-instance
 */
export declare class RosInstance extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ROCKETMQ5::Instance";
    /**
     * @Attribute InstanceId: Instance ID created.
     */
    readonly attrInstanceId: ros.IResolvable;
    /**
     * @Attribute InstanceName: Instance name.
     */
    readonly attrInstanceName: ros.IResolvable;
    /**
     * @Attribute InternetEndpoint: Internet endpoint.
     */
    readonly attrInternetEndpoint: ros.IResolvable;
    /**
     * @Attribute VpcEndpoint: VPC endpoint.
     */
    readonly attrVpcEndpoint: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property internetInfo: Public network configuration information.
     */
    internetInfo: RosInstance.InternetInfoProperty | ros.IResolvable;
    /**
     * @Property productInfo: Instance specification information.
     */
    productInfo: RosInstance.ProductInfoProperty | ros.IResolvable;
    /**
     * @Property seriesCode: The primary series code of the instance.
     */
    seriesCode: string | ros.IResolvable;
    /**
     * @Property subSeriesCode: The sub series code of the instance.
     */
    subSeriesCode: string | ros.IResolvable;
    /**
     * @Property vpcInfo: Private network configuration information.
     */
    vpcInfo: RosInstance.VpcInfoProperty | ros.IResolvable;
    /**
     * @Property autoRenew: Whether to auto-renew. This parameter takes effect only when the PaymentType=Subscription.
     */
    autoRenew: boolean | ros.IResolvable | undefined;
    /**
     * @Property autoRenewPeriod: Automatic renewal period. This parameter is valid only when automatic renewal is enabled. Unit: Month.
     */
    autoRenewPeriod: number | ros.IResolvable | undefined;
    /**
     * @Property instanceName: The name of the instance to be created.
     */
    instanceName: string | ros.IResolvable | undefined;
    /**
     * @Property paymentType: The sub series code of the instance.
     */
    paymentType: string | ros.IResolvable | undefined;
    /**
     * @Property period: The subscription duration. Valid values:
     * When Period is Month, it could be from 1 to 6, 12, 24, 36.
     *  When Period is Year, it could be from 1 to 3.
     */
    period: number | ros.IResolvable | undefined;
    /**
     * @Property periodUnit: The period unit for the duration of the instance.
     */
    periodUnit: string | ros.IResolvable | undefined;
    /**
     * @Property remark: The remark of instance.
     */
    remark: string | ros.IResolvable | undefined;
    /**
     * @Property resourceGroupId: Resource group ID.
     */
    resourceGroupId: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosInstanceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosInstance {
    /**
     * @stability external
     */
    interface InternetInfoProperty {
        /**
         * @Property flowOutType: The billing method of Internet usage. Valid values: payByBandwidth: pay-by-bandwidth. If Internet access is enabled for an instance, specify this value for the parameter. payByTraffic: pay-by-traffic. If Internet access is enabled for an instance, specify this value for the parameter. uninvolved: No billing method is involved. If Internet access is disabled for an instance, specify this value for the parameter.
         */
        readonly flowOutType?: string | ros.IResolvable;
        /**
         * @Property internetSpec: Whether to enable public network access.
         */
        readonly internetSpec: string | ros.IResolvable;
        /**
         * @Property ipWhitelist: Public network access whitelist address segment.
         */
        readonly ipWhitelist?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property flowOutBandwidth: Public network bandwidth specification. Unit: Mb\/s.
     * It needs to be filled in only when the billing type of the public network is billed by fixed bandwidth.
         */
        readonly flowOutBandwidth?: number | ros.IResolvable;
    }
}
export declare namespace RosInstance {
    /**
     * @stability external
     */
    interface ProductInfoProperty {
        /**
         * @Property sendReceiveRatio: The ratio of messages sent and received.
         */
        readonly sendReceiveRatio?: number | ros.IResolvable;
        /**
         * @Property messageRetentionTime: The message storage time. Unit: Hour.
         */
        readonly messageRetentionTime?: number | ros.IResolvable;
        /**
         * @Property provisionedCapacity: The provisioned capacity.
         */
        readonly provisionedCapacity?: number | ros.IResolvable;
        /**
         * @Property autoScaling: Whether to enable out-of-spec burst resiliency.
     * After the elastic burst capability is enabled, the message queue RocketMQ allows the instance to exceed the TPS limited by the basic specification within a certain range, and the part exceeding the basic specification requires additional elastic specification fees.
         */
        readonly autoScaling?: boolean | ros.IResolvable;
        /**
         * @Property msgProcessSpec: Message processing specification.
         */
        readonly msgProcessSpec: string | ros.IResolvable;
        /**
         * @Property capacityType: The type of capacity.
         */
        readonly capacityType?: string | ros.IResolvable;
    }
}
export declare namespace RosInstance {
    /**
     * @stability external
     */
    interface VpcInfoProperty {
        /**
         * @Property vpcId: ID of the VPC associated with the instance to be created.
         */
        readonly vpcId: string | ros.IResolvable;
        /**
         * @Property vSwitchIds: IDs of the vSwitchs associated with the instance to be created.
     * **Note**: Only one is required for VSwitchIds and VSwitchId. When both are filled in, VSwitchIds overwrites VSwitchId.
         */
        readonly vSwitchIds?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property vSwitchId: ID of the vSwitch associated with the instance to be created.
         */
        readonly vSwitchId?: string | ros.IResolvable;
        /**
         * @Property securityGroupId: ID of the security group associated with the instance to be created. Required when creating serverless.
         */
        readonly securityGroupId?: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosTopic`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-topic
 */
export interface RosTopicProps {
    /**
     * @Property instanceId: The ID of the instance.
     */
    readonly instanceId: string | ros.IResolvable;
    /**
     * @Property messageType: The message type of the topic to be created. Valid values:
     * NORMAL
     * FIFO
     * DELAY
     * TRANSACTION
     */
    readonly messageType: string | ros.IResolvable;
    /**
     * @Property topicName: The name of the topic to be created is used to identify the topic and is globally unique.
     * Valid values:
     * Character limitation: supports letters a~z or A-Z, numbers 0-9, underscore (_), dash (-) and percent sign (%).
     * Length limit: 1-60 characters.
     */
    readonly topicName: string | ros.IResolvable;
    /**
     * @Property remark: The remark of the topic to be created.
     */
    readonly remark?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ROCKETMQ5::Topic`, which is used to create a topic for a Message Queue for Apache RocketMQ V5.0 instance.
 * @Note This class does not contain additional functions, so it is recommended to use the `Topic` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-rocketmq5-topic
 */
export declare class RosTopic extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ROCKETMQ5::Topic";
    /**
     * @Attribute InstanceId: The ID of the instance.
     */
    readonly attrInstanceId: ros.IResolvable;
    /**
     * @Attribute MessageType: The type of the message.
     */
    readonly attrMessageType: ros.IResolvable;
    /**
     * @Attribute TopicName: The name of the topic.
     */
    readonly attrTopicName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property instanceId: The ID of the instance.
     */
    instanceId: string | ros.IResolvable;
    /**
     * @Property messageType: The message type of the topic to be created. Valid values:
     * NORMAL
     * FIFO
     * DELAY
     * TRANSACTION
     */
    messageType: string | ros.IResolvable;
    /**
     * @Property topicName: The name of the topic to be created is used to identify the topic and is globally unique.
     * Valid values:
     * Character limitation: supports letters a~z or A-Z, numbers 0-9, underscore (_), dash (-) and percent sign (%).
     * Length limit: 1-60 characters.
     */
    topicName: string | ros.IResolvable;
    /**
     * @Property remark: The remark of the topic to be created.
     */
    remark: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosTopicProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
