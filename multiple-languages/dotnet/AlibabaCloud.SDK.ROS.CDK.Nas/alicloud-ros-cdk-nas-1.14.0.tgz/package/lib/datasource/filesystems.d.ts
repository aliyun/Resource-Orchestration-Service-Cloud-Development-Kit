import * as ros from '@alicloud/ros-cdk-core';
import { RosFileSystems } from './nas.generated';
export { RosFileSystems as FileSystemsProperty };
/**
 * Properties for defining a `FileSystems`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-nas-filesystems
 */
export interface FileSystemsProps {
    /**
     * Property fileSystemId: The ID of the file system to be created.
     */
    readonly fileSystemId?: string | ros.IResolvable;
    /**
     * Property fileSystemType: File system type.
     * Value:
     * -standard (default): Universal NAS
     * -extreme: extreme NAS
     * -cpfs: file storage CPFS
     */
    readonly fileSystemType?: string | ros.IResolvable;
    /**
     * Property refreshOptions: The refresh strategy for the datasource resource when the stack is updated. Valid values:
     * - Never: Never refresh the datasource resource when the stack is updated.
     * - Always: Always refresh the datasource resource when the stack is updated.
     * Default is Never.
     */
    readonly refreshOptions?: string | ros.IResolvable;
}
/**
 * Represents a `FileSystems`.
 */
export interface IFileSystems extends ros.IResource {
    readonly props: FileSystemsProps;
    /**
     * Attribute FileSystemIds: The list of file system IDs.
     */
    readonly attrFileSystemIds: ros.IResolvable | string;
    /**
     * Attribute FileSystems: The list of file systems.
     */
    readonly attrFileSystems: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `DATASOURCE::NAS::FileSystems`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosFileSystems`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-nas-filesystems
 */
export declare class FileSystems extends ros.Resource implements IFileSystems {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: FileSystemsProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute FileSystemIds: The list of file system IDs.
     */
    readonly attrFileSystemIds: ros.IResolvable | string;
    /**
     * Attribute FileSystems: The list of file systems.
     */
    readonly attrFileSystems: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props?: FileSystemsProps, enableResourcePropertyConstraint?: boolean);
}
