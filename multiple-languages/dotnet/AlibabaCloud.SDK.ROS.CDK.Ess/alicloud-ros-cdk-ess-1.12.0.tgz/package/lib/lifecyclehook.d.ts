import * as ros from '@alicloud/ros-cdk-core';
import { RosLifecycleHook } from './ess.generated';
export { RosLifecycleHook as LifecycleHookProperty };
/**
 * Properties for defining a `LifecycleHook`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-ess-lifecyclehook
 */
export interface LifecycleHookProps {
    /**
     * Property lifecycleTransition: The scaling activities to which lifecycle hooks apply Value range:
     *  SCALE_OUT: scale-out event
     *  SCALE_IN: scale-in event
     */
    readonly lifecycleTransition: string | ros.IResolvable;
    /**
     * Property scalingGroupId: The ID of the scaling group.
     */
    readonly scalingGroupId: string | ros.IResolvable;
    /**
     * Property defaultResult: The action that the scaling group takes when the lifecycle hook times out. Value range:
     *  CONTINUE: the scaling group continues with the scale-in or scale-out process.
     *  ABANDON: the scaling group stops any remaining action of the scale-in or scale-out event.
     * Default value: CONTINUE
     * If the scaling group has multiple lifecycle hooks and one of them is terminated by the DefaultResult=ABANDON parameter during a scale-in event (SCALE_IN), the remaining lifecycle hooks under the same scaling group will also be terminated. Otherwise, the action following the wait state is the next action, as specified in the parameter DefaultResult, after the last lifecycle event under the same scaling group.
     */
    readonly defaultResult?: string | ros.IResolvable;
    /**
     * Property heartbeatTimeout: The time, in seconds, that can elapse before the lifecycle hook times out. If the lifecycle hook times out, the scaling group performs the default action (DefaultResult). The range is from 30 to 86400 seconds. The default value is 600 seconds.
     * You can prevent the lifecycle hook from timing out by calling the RecordLifecycleActionHeartbeat operation. You can also terminate the lifecycle action by calling the CompleteLifecycleAction operation.
     */
    readonly heartbeatTimeout?: number | ros.IResolvable;
    /**
     * Property lifecycleHookName: The name of the lifecycle hook. Each name must be unique within a scaling group. The name must be 2 to 64 characters in length and can contain letters, numbers, Chinese characters, and special characters including underscores (_), hyphens (-) and periods (.).
     * Default value: Lifecycle Hook ID
     */
    readonly lifecycleHookName?: string | ros.IResolvable;
    /**
     * Property notificationArn: The Alibaba Cloud Resource Name (ARN) of the notification recipient. If you do not specify this parameter, no notification is sent when the lifecycle hook takes effect. If you specify this parameter, the value must be in one of the following formats:
     * - If you specify a Simple Message Queue (SMQ, formerly MNS) as the notification recipient, specify the value in the acs:mns:{region-id}:{account-id}:queue\/{queuename} format.
     * - If you specify an SMQ topic as the notification recipient, specify the value in the acs:mns:{region-id}:{account-id}:topic\/{topicname} format.
     * - If you specify a CloudOps Orchestration Service (OOS) template as the notification recipient, specify the value in the acs:oos:{region-id}:{account-id}:template\/{templatename} format.
     * - If you specify an event bus as the notification recipient, specify the value in the acs:eventbridge:{region-id}:{account-id}:eventbus\/default format.
     *
     * The variables in the preceding value formats have the following meanings:
     * - region-id: the region ID of your scaling group.
     * - account-id: the ID of the Alibaba Cloud account. IDs of Resource Access Management (RAM) users are not supported.
     * - queuename: the name of the SMQ queue.
     * - topicname: the name of the SMQ topic.
     * - templatename: the name of the OOS template.
     */
    readonly notificationArn?: string | ros.IResolvable;
    /**
     * Property notificationMetadata: The fixed string that you want to include when Auto Scaling sends a message about the wait state of the scaling activity to the notification target. The length of the parameter can be up to 4096 characters. Auto Scaling will send the specified NotificationMetadata parameter along with the notification message so that you can easily categorize your notifications. The NotificationMetadata parameter will only take effect after you specify the NotificationArn parameter.
     */
    readonly notificationMetadata?: string | ros.IResolvable;
}
/**
 * Represents a `LifecycleHook`.
 */
export interface ILifecycleHook extends ros.IResource {
    readonly props: LifecycleHookProps;
    /**
     * Attribute LifecycleHookId: The lifecycle hook ID
     */
    readonly attrLifecycleHookId: ros.IResolvable | string;
    /**
     * Attribute ScalingGroupId: The id of the scaling group to which the lifecycle hook belongs.
     */
    readonly attrScalingGroupId: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::ESS::LifecycleHook`, which is used to create a lifecycle hook for a scaling group.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosLifecycleHook`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-ess-lifecyclehook
 */
export declare class LifecycleHook extends ros.Resource implements ILifecycleHook {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: LifecycleHookProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute LifecycleHookId: The lifecycle hook ID
     */
    readonly attrLifecycleHookId: ros.IResolvable | string;
    /**
     * Attribute ScalingGroupId: The id of the scaling group to which the lifecycle hook belongs.
     */
    readonly attrScalingGroupId: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: LifecycleHookProps, enableResourcePropertyConstraint?: boolean);
}
