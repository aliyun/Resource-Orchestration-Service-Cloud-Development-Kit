import * as ros from '@alicloud/ros-cdk-core';
import { RosRedirectRule } from './esa.generated';
export { RosRedirectRule as RedirectRuleProperty };
/**
 * Properties for defining a `RedirectRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-redirectrule
 */
export interface RedirectRuleProps {
    /**
     * Property reserveQueryString: Indicates whether the feature of retaining the query string is enabled. Valid values:
     * on
     * off.
     */
    readonly reserveQueryString: string | ros.IResolvable;
    /**
     * Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * Property statusCode: The response code that you want to use to indicate URL redirection. Valid values:
     * *   301
     * *   302
     * *   303
     * *   307
     * *   308.
     */
    readonly statusCode: number | ros.IResolvable;
    /**
     * Property targetUrl: The destination URL to which requests are redirected.
     */
    readonly targetUrl: string | ros.IResolvable;
    /**
     * Property type: The redirect type. Valid value:
     * *   static.
     */
    readonly type: string | ros.IResolvable;
    /**
     * Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     *  Match all incoming requests: value set to true
     *  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on
     * off.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * Represents a `RedirectRule`.
 */
export interface IRedirectRule extends ros.IResource {
    readonly props: RedirectRuleProps;
    /**
     * Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable | string;
    /**
     * Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable | string;
    /**
     * Attribute ReserveQueryString: Indicates whether the feature of retaining the query string is enabled.
     */
    readonly attrReserveQueryString: ros.IResolvable | string;
    /**
     * Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable | string;
    /**
     * Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable | string;
    /**
     * Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable | string;
    /**
     * Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable | string;
    /**
     * Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable | string;
    /**
     * Attribute StatusCode: The response code that you want to use to indicate URL redirection.
     */
    readonly attrStatusCode: ros.IResolvable | string;
    /**
     * Attribute TargetUrl: The destination URL to which requests are redirected.
     */
    readonly attrTargetUrl: ros.IResolvable | string;
    /**
     * Attribute Type: The redirect type.
     */
    readonly attrType: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::ESA::RedirectRule`The , which type is used to create a redirection configuration.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosRedirectRule`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-redirectrule
 */
export declare class RedirectRule extends ros.Resource implements IRedirectRule {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: RedirectRuleProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable | string;
    /**
     * Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable | string;
    /**
     * Attribute ReserveQueryString: Indicates whether the feature of retaining the query string is enabled.
     */
    readonly attrReserveQueryString: ros.IResolvable | string;
    /**
     * Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable | string;
    /**
     * Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable | string;
    /**
     * Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable | string;
    /**
     * Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable | string;
    /**
     * Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable | string;
    /**
     * Attribute StatusCode: The response code that you want to use to indicate URL redirection.
     */
    readonly attrStatusCode: ros.IResolvable | string;
    /**
     * Attribute TargetUrl: The destination URL to which requests are redirected.
     */
    readonly attrTargetUrl: ros.IResolvable | string;
    /**
     * Attribute Type: The redirect type.
     */
    readonly attrType: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RedirectRuleProps, enableResourcePropertyConstraint?: boolean);
}
