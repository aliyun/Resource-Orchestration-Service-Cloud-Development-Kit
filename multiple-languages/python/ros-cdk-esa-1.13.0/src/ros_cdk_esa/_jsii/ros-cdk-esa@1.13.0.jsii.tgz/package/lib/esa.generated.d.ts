import * as ros from '@alicloud/ros-cdk-core';
/**
 * Properties for defining a `RosCacheRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-cacherule
 */
export interface RosCacheRuleProps {
    /**
     * @Property siteId: The site ID, which can be obtained by calling the [ListSites] API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property additionalCacheablePorts: Enable caching on specified ports. Value range: 8880, 2052, 2082, 2086, 2095, 2053, 2083, 2087, 2096.
     */
    readonly additionalCacheablePorts?: number | ros.IResolvable;
    /**
     * @Property browserCacheMode: Browser cache mode. Possible values:
     * - `no_cache`no_cache: Do not cache.
     * - `follow_origin`: Follow the origin server's cache policy.
     * - `override_origin`: Override the origin server's cache policy.
     */
    readonly browserCacheMode?: string | ros.IResolvable;
    /**
     * @Property browserCacheTtl: Browser cache expiration time in seconds.
     */
    readonly browserCacheTtl?: number | ros.IResolvable;
    /**
     * @Property bypassCache: Set the bypass cache mode. Possible values:
     * - `cache_all`: Cache all requests.
     * - `bypass_all`: Bypass cache for all requests.
     */
    readonly bypassCache?: string | ros.IResolvable;
    /**
     * @Property cacheDeceptionArmor: Cache deception protection. Used to defend against web cache deception attacks, only the cache content that passes the validation will be cached. Value range:
     * - `on`: Enabled.
     * - `off`: Disabled.
     */
    readonly cacheDeceptionArmor?: string | ros.IResolvable;
    /**
     * @Property cacheReserveEligibility: Cache retention eligibility. Used to control whether user requests bypass the cache retention node when returning to the origin. Possible values:
     * - `bypass_cache_reserve`: Requests bypass cache retention.
     * - `eligible_for_cache_reserve`: Eligible for cache retention.
     */
    readonly cacheReserveEligibility?: string | ros.IResolvable;
    /**
     * @Property checkPresenceCookie: When generating the cache key, check if the cookie exists. If it does, add the cookie name (case-insensitive) to the cache key. Multiple cookie names are supported, separated by spaces.
     */
    readonly checkPresenceCookie?: string | ros.IResolvable;
    /**
     * @Property checkPresenceHeader: When generating the cache key, check if the header exists. If it does, add the header name (case-insensitive) to the cache key. Multiple header names are supported, separated by spaces.
     */
    readonly checkPresenceHeader?: string | ros.IResolvable;
    /**
     * @Property edgeCacheMode: Edge cache mode. Possible values:
     * - `follow_origin`: Follow the origin server's cache policy (if it exists), otherwise use the default cache policy.
     * - `no_cache`: Do not cache.
     * - `override_origin`: Override the origin server's cache policy.
     * - `follow_origin_bypass`: Follow the origin server's cache policy (if it exists), otherwise do not cache.
     */
    readonly edgeCacheMode?: string | ros.IResolvable;
    /**
     * @Property edgeCacheTtl: Edge cache expiration time in seconds.
     */
    readonly edgeCacheTtl?: number | ros.IResolvable;
    /**
     * @Property edgeStatusCodeCacheTtl: Status code cache expiration time in seconds. Multiple values are separated by commas, for example: 4xx=999999,5xx=999998
     */
    readonly edgeStatusCodeCacheTtl?: string | ros.IResolvable;
    /**
     * @Property includeCookie: When generating the cache key, add the specified cookie names and their values. Multiple values are supported, separated by spaces.
     */
    readonly includeCookie?: string | ros.IResolvable;
    /**
     * @Property includeHeader: When generating the cache key, add the specified header names and their values. Multiple values are supported, separated by spaces.
     */
    readonly includeHeader?: string | ros.IResolvable;
    /**
     * @Property queryString: Query strings to be reserved or excluded. Multiple values are supported, separated by spaces.
     */
    readonly queryString?: string | ros.IResolvable;
    /**
     * @Property queryStringMode: The processing mode for query strings when generating the cache key. Possible values:
     * - `ignore_all`: Ignore all.
     * - `exclude_query_string`: Exclude specified query strings.
     * - `reserve_all`: Default, reserve all.
     * - `include_query_string`: Include specified query strings.
     */
    readonly queryStringMode?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true.
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property serveStale: Serve stale cache. When enabled, the node can still respond to user requests with expired cached files when the origin server is unavailable. Value range:
     * - `on`: Enabled.
     * - `off`: Disabled.
     */
    readonly serveStale?: string | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
    /**
     * @Property sortQueryStringForCache: Query string sorting, disabled by default. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    readonly sortQueryStringForCache?: string | ros.IResolvable;
    /**
     * @Property userDeviceType: When generating the cache key, add the client device type. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    readonly userDeviceType?: string | ros.IResolvable;
    /**
     * @Property userGeo: When generating the cache key, add the client's geographic location. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    readonly userGeo?: string | ros.IResolvable;
    /**
     * @Property userLanguage: When generating cache keys, include the client's language type. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    readonly userLanguage?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::CacheRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `CacheRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-cacherule
 */
export declare class RosCacheRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::CacheRule";
    /**
     * @Attribute AdditionalCacheablePorts: Enable caching on specified ports.
     */
    readonly attrAdditionalCacheablePorts: ros.IResolvable;
    /**
     * @Attribute BrowserCacheMode: Browser cache mode.
     */
    readonly attrBrowserCacheMode: ros.IResolvable;
    /**
     * @Attribute BrowserCacheTtl: Browser cache expiration time in seconds.
     */
    readonly attrBrowserCacheTtl: ros.IResolvable;
    /**
     * @Attribute BypassCache: Set the bypass cache mode.
     */
    readonly attrBypassCache: ros.IResolvable;
    /**
     * @Attribute CacheDeceptionArmor: Cache deception protection. Used to defend against web cache deception attacks, only the cache content that passes the validation will be cached.
     */
    readonly attrCacheDeceptionArmor: ros.IResolvable;
    /**
     * @Attribute CacheReserveEligibility: Cache retention eligibility. Used to control whether user requests bypass the cache retention node when returning to the origin.
     */
    readonly attrCacheReserveEligibility: ros.IResolvable;
    /**
     * @Attribute CacheRuleId: Cache Rule Id.
     */
    readonly attrCacheRuleId: ros.IResolvable;
    /**
     * @Attribute CheckPresenceCookie: When generating the cache key, check if the cookie exists. If it does, add the cookie name (case-insensitive) to the cache key. Multiple cookie names are supported, separated by spaces.
     */
    readonly attrCheckPresenceCookie: ros.IResolvable;
    /**
     * @Attribute CheckPresenceHeader: When generating the cache key, check if the header exists. If it does, add the header name (case-insensitive) to the cache key. Multiple header names are supported, separated by spaces.
     */
    readonly attrCheckPresenceHeader: ros.IResolvable;
    /**
     * @Attribute ConfigType: Configuration type, which can be used to query global or rule-based configurations.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute EdgeCacheMode: Edge cache mode.
     */
    readonly attrEdgeCacheMode: ros.IResolvable;
    /**
     * @Attribute EdgeCacheTtl: Edge cache expiration time in seconds.
     */
    readonly attrEdgeCacheTtl: ros.IResolvable;
    /**
     * @Attribute EdgeStatusCodeCacheTtl: Status code cache expiration time in seconds.
     */
    readonly attrEdgeStatusCodeCacheTtl: ros.IResolvable;
    /**
     * @Attribute IncludeCookie: When generating the cache key, add the specified cookie names and their values. Multiple values are supported, separated by spaces.
     */
    readonly attrIncludeCookie: ros.IResolvable;
    /**
     * @Attribute IncludeHeader: When generating the cache key, add the specified header names and their values. Multiple values are supported, separated by spaces.
     */
    readonly attrIncludeHeader: ros.IResolvable;
    /**
     * @Attribute QueryString: Query strings to be reserved or excluded. Multiple values are supported, separated by spaces.
     */
    readonly attrQueryString: ros.IResolvable;
    /**
     * @Attribute QueryStringMode: The processing mode for query strings when generating the cache key.
     */
    readonly attrQueryStringMode: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute ServeStale: Serve stale cache. When enabled, the node can still respond to user requests with expired cached files when the origin server is unavailable.
     */
    readonly attrServeStale: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute SortQueryStringForCache: Query string sorting, disabled by default.
     */
    readonly attrSortQueryStringForCache: ros.IResolvable;
    /**
     * @Attribute UserDeviceType: When generating the cache key, add the client device type.
     */
    readonly attrUserDeviceType: ros.IResolvable;
    /**
     * @Attribute UserGeo: When generating the cache key, add the client's geographic location.
     */
    readonly attrUserGeo: ros.IResolvable;
    /**
     * @Attribute UserLanguage: When generating cache keys, include the client's language type.
     */
    readonly attrUserLanguage: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the [ListSites] API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property additionalCacheablePorts: Enable caching on specified ports. Value range: 8880, 2052, 2082, 2086, 2095, 2053, 2083, 2087, 2096.
     */
    additionalCacheablePorts: number | ros.IResolvable | undefined;
    /**
     * @Property browserCacheMode: Browser cache mode. Possible values:
     * - `no_cache`no_cache: Do not cache.
     * - `follow_origin`: Follow the origin server's cache policy.
     * - `override_origin`: Override the origin server's cache policy.
     */
    browserCacheMode: string | ros.IResolvable | undefined;
    /**
     * @Property browserCacheTtl: Browser cache expiration time in seconds.
     */
    browserCacheTtl: number | ros.IResolvable | undefined;
    /**
     * @Property bypassCache: Set the bypass cache mode. Possible values:
     * - `cache_all`: Cache all requests.
     * - `bypass_all`: Bypass cache for all requests.
     */
    bypassCache: string | ros.IResolvable | undefined;
    /**
     * @Property cacheDeceptionArmor: Cache deception protection. Used to defend against web cache deception attacks, only the cache content that passes the validation will be cached. Value range:
     * - `on`: Enabled.
     * - `off`: Disabled.
     */
    cacheDeceptionArmor: string | ros.IResolvable | undefined;
    /**
     * @Property cacheReserveEligibility: Cache retention eligibility. Used to control whether user requests bypass the cache retention node when returning to the origin. Possible values:
     * - `bypass_cache_reserve`: Requests bypass cache retention.
     * - `eligible_for_cache_reserve`: Eligible for cache retention.
     */
    cacheReserveEligibility: string | ros.IResolvable | undefined;
    /**
     * @Property checkPresenceCookie: When generating the cache key, check if the cookie exists. If it does, add the cookie name (case-insensitive) to the cache key. Multiple cookie names are supported, separated by spaces.
     */
    checkPresenceCookie: string | ros.IResolvable | undefined;
    /**
     * @Property checkPresenceHeader: When generating the cache key, check if the header exists. If it does, add the header name (case-insensitive) to the cache key. Multiple header names are supported, separated by spaces.
     */
    checkPresenceHeader: string | ros.IResolvable | undefined;
    /**
     * @Property edgeCacheMode: Edge cache mode. Possible values:
     * - `follow_origin`: Follow the origin server's cache policy (if it exists), otherwise use the default cache policy.
     * - `no_cache`: Do not cache.
     * - `override_origin`: Override the origin server's cache policy.
     * - `follow_origin_bypass`: Follow the origin server's cache policy (if it exists), otherwise do not cache.
     */
    edgeCacheMode: string | ros.IResolvable | undefined;
    /**
     * @Property edgeCacheTtl: Edge cache expiration time in seconds.
     */
    edgeCacheTtl: number | ros.IResolvable | undefined;
    /**
     * @Property edgeStatusCodeCacheTtl: Status code cache expiration time in seconds. Multiple values are separated by commas, for example: 4xx=999999,5xx=999998
     */
    edgeStatusCodeCacheTtl: string | ros.IResolvable | undefined;
    /**
     * @Property includeCookie: When generating the cache key, add the specified cookie names and their values. Multiple values are supported, separated by spaces.
     */
    includeCookie: string | ros.IResolvable | undefined;
    /**
     * @Property includeHeader: When generating the cache key, add the specified header names and their values. Multiple values are supported, separated by spaces.
     */
    includeHeader: string | ros.IResolvable | undefined;
    /**
     * @Property queryString: Query strings to be reserved or excluded. Multiple values are supported, separated by spaces.
     */
    queryString: string | ros.IResolvable | undefined;
    /**
     * @Property queryStringMode: The processing mode for query strings when generating the cache key. Possible values:
     * - `ignore_all`: Ignore all.
     * - `exclude_query_string`: Exclude specified query strings.
     * - `reserve_all`: Default, reserve all.
     * - `include_query_string`: Include specified query strings.
     */
    queryStringMode: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true.
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property serveStale: Serve stale cache. When enabled, the node can still respond to user requests with expired cached files when the origin server is unavailable. Value range:
     * - `on`: Enabled.
     * - `off`: Disabled.
     */
    serveStale: string | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @Property sortQueryStringForCache: Query string sorting, disabled by default. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    sortQueryStringForCache: string | ros.IResolvable | undefined;
    /**
     * @Property userDeviceType: When generating the cache key, add the client device type. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    userDeviceType: string | ros.IResolvable | undefined;
    /**
     * @Property userGeo: When generating the cache key, add the client's geographic location. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    userGeo: string | ros.IResolvable | undefined;
    /**
     * @Property userLanguage: When generating cache keys, include the client's language type. Possible values:
     * - `on`: Enable.
     * - `off`: Disable.
     */
    userLanguage: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCacheRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-certificate
 */
export interface RosCertificateProps {
    /**
     * @Property createdType: The certificate type.
     * - cas (Certificate Center Certificate)
     * - upload (custom upload certificate)
     * - free( Free certificate).
     */
    readonly createdType: string | ros.IResolvable;
    /**
     * @Property domains: A list of domain names. Multiple domain names are separated by commas.
     */
    readonly domains: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites interface.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property casId: Cloud certificate ID.
     */
    readonly casId?: string | ros.IResolvable;
    /**
     * @Property certId: The certificate Id.
     */
    readonly certId?: string | ros.IResolvable;
    /**
     * @Property certificate: Certificate content.
     */
    readonly certificate?: string | ros.IResolvable;
    /**
     * @Property certName: The certificate name.
     */
    readonly certName?: string | ros.IResolvable;
    /**
     * @Property privateKey: The certificate private key.
     */
    readonly privateKey?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::Certificate`The , which type configures a website certificate.
 * @Note This class does not contain additional functions, so it is recommended to use the `Certificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-certificate
 */
export declare class RosCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::Certificate";
    /**
     * @Attribute ApplyCode: Certificate application error code.
     */
    readonly attrApplyCode: ros.IResolvable;
    /**
     * @Attribute ApplyMessage: Certificate application error message.
     */
    readonly attrApplyMessage: ros.IResolvable;
    /**
     * @Attribute CasId: Cloud certificate ID.
     */
    readonly attrCasId: ros.IResolvable;
    /**
     * @Attribute CertId: The certificate Id.
     */
    readonly attrCertId: ros.IResolvable;
    /**
     * @Attribute CertName: The certificate name.
     */
    readonly attrCertName: ros.IResolvable;
    /**
     * @Attribute Certificate: Certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute CommonName: Common Name (CN) field of the certificate.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: Creation time.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute DCV: DCV information.
     */
    readonly attrDcv: ros.IResolvable;
    /**
     * @Attribute Domains: A list of domain names. Multiple domain names are separated by commas.
     */
    readonly attrDomains: ros.IResolvable;
    /**
     * @Attribute FingerprintSha256: SHA256 fingerprint of the certificate.
     */
    readonly attrFingerprintSha256: ros.IResolvable;
    /**
     * @Attribute Issuer: Certificate issuer.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute IssuerCN: Common name of the certificate issuer.
     */
    readonly attrIssuerCn: ros.IResolvable;
    /**
     * @Attribute NotAfter: End time of the certificate validity period.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: Start time of the certificate validity period.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute PubAlg: Certificate public key algorithm.
     */
    readonly attrPubAlg: ros.IResolvable;
    /**
     * @Attribute SerialNumber: Serial number of the certificate.
     */
    readonly attrSerialNumber: ros.IResolvable;
    /**
     * @Attribute SigAlg: Certificate signature algorithm.
     */
    readonly attrSigAlg: ros.IResolvable;
    /**
     * @Attribute SiteId: The site ID, which can be obtained by calling the ListSites interface.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: Site name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute UpdateTime: Update time.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property createdType: The certificate type.
     * - cas (Certificate Center Certificate)
     * - upload (custom upload certificate)
     * - free( Free certificate).
     */
    createdType: string | ros.IResolvable;
    /**
     * @Property domains: A list of domain names. Multiple domain names are separated by commas.
     */
    domains: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites interface.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property casId: Cloud certificate ID.
     */
    casId: string | ros.IResolvable | undefined;
    /**
     * @Property certId: The certificate Id.
     */
    certId: string | ros.IResolvable | undefined;
    /**
     * @Property certificate: Certificate content.
     */
    certificate: string | ros.IResolvable | undefined;
    /**
     * @Property certName: The certificate name.
     */
    certName: string | ros.IResolvable | undefined;
    /**
     * @Property privateKey: The certificate private key.
     */
    privateKey: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosClientCaCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-clientcacertificate
 */
export interface RosClientCaCertificateProps {
    /**
     * @Property certificate: Certificate content.
     */
    readonly certificate: string | ros.IResolvable;
    /**
     * @Property siteId: Site Id.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property clientCaCertName: The certificate name.
     */
    readonly clientCaCertName?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::ClientCaCertificate`The , which type uploads a client CA certificate.
 * @Note This class does not contain additional functions, so it is recommended to use the `ClientCaCertificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-clientcacertificate
 */
export declare class RosClientCaCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::ClientCaCertificate";
    /**
     * @Attribute Certificate: Certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute ClientCaCertId: ClientCaCertificate Id.
     */
    readonly attrClientCaCertId: ros.IResolvable;
    /**
     * @Attribute ClientCaCertName: The certificate name.
     */
    readonly attrClientCaCertName: ros.IResolvable;
    /**
     * @Attribute CommonName: The certificate common name.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: Creation time.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute Issuer: Certificate Authority.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute NotAfter: The expiration date of the certificate validity period.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: The start time of the certificate validity period.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute PubkeyAlgorithm: Certificate public key algorithm.
     */
    readonly attrPubkeyAlgorithm: ros.IResolvable;
    /**
     * @Attribute SAN: Alternate certificate subject name.
     */
    readonly attrSan: ros.IResolvable;
    /**
     * @Attribute SignatureAlgorithm: Certificate signature algorithm.
     */
    readonly attrSignatureAlgorithm: ros.IResolvable;
    /**
     * @Attribute SiteId: Site Id.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute Type: The certificate type.
     */
    readonly attrType: ros.IResolvable;
    /**
     * @Attribute UpdateTime: Update time.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property certificate: Certificate content.
     */
    certificate: string | ros.IResolvable;
    /**
     * @Property siteId: Site Id.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property clientCaCertName: The certificate name.
     */
    clientCaCertName: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosClientCaCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosClientCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-clientcertificate
 */
export interface RosClientCertificateProps {
    /**
     * @Property siteId: Site Id.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property validityDays: Certificate validity period.
     */
    readonly validityDays: number | ros.IResolvable;
    /**
     * @Property csr: Certificate signing request content.
     */
    readonly csr?: string | ros.IResolvable;
    /**
     * @Property pkeyType: The private key algorithm type.
     */
    readonly pkeyType?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::ClientCertificate`The , which type is used to create a client certificate.
 * @Note This class does not contain additional functions, so it is recommended to use the `ClientCertificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-clientcertificate
 */
export declare class RosClientCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::ClientCertificate";
    /**
     * @Attribute CACertificateId: The ID of the CA certificate.
     */
    readonly attrCaCertificateId: ros.IResolvable;
    /**
     * @Attribute Certificate: Certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute ClientCertId: ClientCertificate Id.
     */
    readonly attrClientCertId: ros.IResolvable;
    /**
     * @Attribute ClientCertificateName: The certificate name.
     */
    readonly attrClientCertificateName: ros.IResolvable;
    /**
     * @Attribute CommonName: The Common Name of the certificate.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the certificate was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute Issuer: The certificate authority (CA) that issued the certificate.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute NotAfter: The time when the certificate expires.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: The time when the certificate takes effect.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute PubkeyAlgorithm: The public-key algorithm of the certificate.
     */
    readonly attrPubkeyAlgorithm: ros.IResolvable;
    /**
     * @Attribute SAN: The Subject Alternative Name (SAN) of the certificate.
     */
    readonly attrSan: ros.IResolvable;
    /**
     * @Attribute SignatureAlgorithm: The signature algorithm of the certificate.
     */
    readonly attrSignatureAlgorithm: ros.IResolvable;
    /**
     * @Attribute SiteId: Site Id.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute Type: The certificate type.
     */
    readonly attrType: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the certificate was updated.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: Site Id.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property validityDays: Certificate validity period.
     */
    validityDays: number | ros.IResolvable;
    /**
     * @Property csr: Certificate signing request content.
     */
    csr: string | ros.IResolvable | undefined;
    /**
     * @Property pkeyType: The private key algorithm type.
     */
    pkeyType: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosClientCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosCompressionRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-compressionrule
 */
export interface RosCompressionRuleProps {
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property brotli: Brotli compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    readonly brotli?: string | ros.IResolvable;
    /**
     * @Property gzip: Gzip compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    readonly gzip?: string | ros.IResolvable;
    /**
     * @Property paymentType: Payment Type.
     */
    readonly paymentType?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enable.
     * off: Disable.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
    /**
     * @Property zstd: Zstd compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    readonly zstd?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::CompressionRule`The , which resource type creates a compression rule.
 * @Note This class does not contain additional functions, so it is recommended to use the `CompressionRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-compressionrule
 */
export declare class RosCompressionRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::CompressionRule";
    /**
     * @Attribute Brotli: Brotli compression.
     */
    readonly attrBrotli: ros.IResolvable;
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Gzip: Gzip compression.
     */
    readonly attrGzip: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute Zstd: Zstd compression.
     */
    readonly attrZstd: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property brotli: Brotli compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    brotli: string | ros.IResolvable | undefined;
    /**
     * @Property gzip: Gzip compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    gzip: string | ros.IResolvable | undefined;
    /**
     * @Property paymentType: Payment Type.
     */
    paymentType: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enable.
     * off: Disable.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @Property zstd: Zstd compression. Value range:
     * on: Enable.
     * off: Disable.
     */
    zstd: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCompressionRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosCustomList`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customlist
 */
export interface RosCustomListProps {
    /**
     * @Property items: The items in the custom list, which are displayed as an array.
     */
    readonly items: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property kind: The type of the custom list.
     */
    readonly kind: string | ros.IResolvable;
    /**
     * @Property listName: The name of the custom list.
     */
    readonly listName: string | ros.IResolvable;
    /**
     * @Property description: The description of the custom list.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::CustomList`Use , which to create a custom list.
 * @Note This class does not contain additional functions, so it is recommended to use the `CustomList` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customlist
 */
export declare class RosCustomList extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::CustomList";
    /**
     * @Attribute Description: The description of the custom list.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute Items: The items in the custom list, which are displayed as an array.
     */
    readonly attrItems: ros.IResolvable;
    /**
     * @Attribute Kind: The type of the custom list.
     */
    readonly attrKind: ros.IResolvable;
    /**
     * @Attribute ListId: The id of the custom list .
     */
    readonly attrListId: ros.IResolvable;
    /**
     * @Attribute ListName: The name of the custom list.
     */
    readonly attrListName: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the custom list was last modified.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property items: The items in the custom list, which are displayed as an array.
     */
    items: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property kind: The type of the custom list.
     */
    kind: string | ros.IResolvable;
    /**
     * @Property listName: The name of the custom list.
     */
    listName: string | ros.IResolvable;
    /**
     * @Property description: The description of the custom list.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCustomListProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosCustomResponseCodeRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customresponsecoderule
 */
export interface RosCustomResponseCodeRuleProps {
    /**
     * @Property pageId: The custom response page.
     */
    readonly pageId: string | ros.IResolvable;
    /**
     * @Property returnCode: The custom response code.
     */
    readonly returnCode: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::CustomResponseCodeRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `CustomResponseCodeRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customresponsecoderule
 */
export declare class RosCustomResponseCodeRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::CustomResponseCodeRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type. You can use this parameter to check the global configuration or rule configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute PageId: The custom response page.
     */
    readonly attrPageId: ros.IResolvable;
    /**
     * @Attribute ReturnCode: The custom response code.
     */
    readonly attrReturnCode: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property pageId: The custom response page.
     */
    pageId: string | ros.IResolvable;
    /**
     * @Property returnCode: The custom response code.
     */
    returnCode: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCustomResponseCodeRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosCustomScenePolicy`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customscenepolicy
 */
export interface RosCustomScenePolicyProps {
    /**
     * @Property createTime: The time when the policy takes effect.
     * The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    readonly createTime: string | ros.IResolvable;
    /**
     * @Property customScenePolicyName: The policy name.
     */
    readonly customScenePolicyName: string | ros.IResolvable;
    /**
     * @Property endTime: The time when the policy expires.
     * The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    readonly endTime: string | ros.IResolvable;
    /**
     * @Property objects: The IDs of the websites that you want to associate with the policy. Separate multiple IDs with commas (,).
     */
    readonly objects: string | ros.IResolvable;
    /**
     * @Property template: The name of the policy template. Valid value:
     * promotion: major events.
     */
    readonly template: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::CustomScenePolicy`The , which resource type is used to create scenario-specific policies.
 * @Note This class does not contain additional functions, so it is recommended to use the `CustomScenePolicy` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-customscenepolicy
 */
export declare class RosCustomScenePolicy extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::CustomScenePolicy";
    /**
     * @Attribute CreateTime: The time when the policy takes effect.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute CustomScenePolicyName: The name of the policy.
     */
    readonly attrCustomScenePolicyName: ros.IResolvable;
    /**
     * @Attribute EndTime: The time when the policy expires.
     */
    readonly attrEndTime: ros.IResolvable;
    /**
     * @Attribute Objects: The IDs of websites associated.
     */
    readonly attrObjects: ros.IResolvable;
    /**
     * @Attribute PolicyId: The Id of the Policy.
     */
    readonly attrPolicyId: ros.IResolvable;
    /**
     * @Attribute Template: The name of the policy template.
     */
    readonly attrTemplate: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property createTime: The time when the policy takes effect.
     * The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    createTime: string | ros.IResolvable;
    /**
     * @Property customScenePolicyName: The policy name.
     */
    customScenePolicyName: string | ros.IResolvable;
    /**
     * @Property endTime: The time when the policy expires.
     * The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    endTime: string | ros.IResolvable;
    /**
     * @Property objects: The IDs of the websites that you want to associate with the policy. Separate multiple IDs with commas (,).
     */
    objects: string | ros.IResolvable;
    /**
     * @Property template: The name of the policy template. Valid value:
     * promotion: major events.
     */
    template: string | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosCustomScenePolicyProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosEdgeContainerApp`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-edgecontainerapp
 */
export interface RosEdgeContainerAppProps {
    /**
     * @Property edgeContainerAppName: The name of the application. The name must start with a lowercase letter and can contain lowercase letters, digits, and hyphens (-). The name must be 6 to 128 characters in length.
     */
    readonly edgeContainerAppName: string | ros.IResolvable;
    /**
     * @Property servicePort: The server port. Valid values: 1 to 65535.
     */
    readonly servicePort: number | ros.IResolvable;
    /**
     * @Property targetPort: The backend port, which is also the service port of the application. Valid values: 1 to 65535.
     */
    readonly targetPort: number | ros.IResolvable;
    /**
     * @Property healthCheckFailTimes: The number of consecutive failed health checks required for an application to be considered as unhealthy. Valid values: 1 to 10. Default value: 5.
     */
    readonly healthCheckFailTimes?: number | ros.IResolvable;
    /**
     * @Property healthCheckHost: The domain name that is used for health checks. This parameter is empty by default.
     */
    readonly healthCheckHost?: string | ros.IResolvable;
    /**
     * @Property healthCheckHttpCode: The HTTP status code returned for a successful health check. Valid values:
     * http_2xx (default)http_3xx
     */
    readonly healthCheckHttpCode?: string | ros.IResolvable;
    /**
     * @Property healthCheckInterval: The interval between two consecutive health checks. Unit: seconds. Valid values: 1 to 50. Default value: 5.
     */
    readonly healthCheckInterval?: number | ros.IResolvable;
    /**
     * @Property healthCheckMethod: The HTTP request method for health checks. Valid values:
     * HEAD (default): requests the headers of the resource.
     * GET: requests the specified resource and returns both the headers and entity body.
     */
    readonly healthCheckMethod?: string | ros.IResolvable;
    /**
     * @Property healthCheckPort: The port used for health checks. Valid values: 1 to 65535. Default value: 80.
     */
    readonly healthCheckPort?: number | ros.IResolvable;
    /**
     * @Property healthCheckSuccTimes: The number of consecutive successful health checks required for an application to be considered as healthy. Valid values: 1 to 10. Default value: 2.
     */
    readonly healthCheckSuccTimes?: number | ros.IResolvable;
    /**
     * @Property healthCheckTimeout: The timeout period of a health check response. If a backend ECS instance does not respond within the specified timeout period, the ECS instance fails the health check. Unit: seconds. Valid values: 1 to 100. Default value: 3.
     */
    readonly healthCheckTimeout?: number | ros.IResolvable;
    /**
     * @Property healthCheckType: The health check type. By default, this parameter is left empty. Valid values:
     * l4: Layer 4 health check.
     * l7: Layer 7 health check.
     *
     */
    readonly healthCheckType?: string | ros.IResolvable;
    /**
     * @Property healthCheckUri: The URI used for health checks. The URI must be 1 to 80 characters in length. Default value: "\/".
     */
    readonly healthCheckUri?: string | ros.IResolvable;
    /**
     * @Property remarks: The remarks. This parameter is empty by default.
     */
    readonly remarks?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::EdgeContainerApp`Use the , which resource type to create an edge container application.
 * @Note This class does not contain additional functions, so it is recommended to use the `EdgeContainerApp` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-edgecontainerapp
 */
export declare class RosEdgeContainerApp extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::EdgeContainerApp";
    /**
     * @Attribute AppStatus: The status of the application.
     */
    readonly attrAppStatus: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the application was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute DomainName: The domain name that is associated with the application. If no domain name is associated with the application, the value is an empty string.
     */
    readonly attrDomainName: ros.IResolvable;
    /**
     * @Attribute EdgeContainerAppName: The name of the application.
     */
    readonly attrEdgeContainerAppName: ros.IResolvable;
    /**
     * @Attribute GatewayType: The type of the gateway.
     */
    readonly attrGatewayType: ros.IResolvable;
    /**
     * @Attribute HealthCheckFailTimes: TThe number of consecutive failed health checks required for an application to be considered as unhealthy.
     */
    readonly attrHealthCheckFailTimes: ros.IResolvable;
    /**
     * @Attribute HealthCheckHost: The domain name that is used for health checks.
     */
    readonly attrHealthCheckHost: ros.IResolvable;
    /**
     * @Attribute HealthCheckHttpCode: The HTTP status code returned for a successful health check.
     */
    readonly attrHealthCheckHttpCode: ros.IResolvable;
    /**
     * @Attribute HealthCheckInterval: The interval between two consecutive health checks. Unit: seconds.
     */
    readonly attrHealthCheckInterval: ros.IResolvable;
    /**
     * @Attribute HealthCheckMethod: The HTTP request method for health checks.
     */
    readonly attrHealthCheckMethod: ros.IResolvable;
    /**
     * @Attribute HealthCheckPort: The port used for health checks. Valid values: 1 to 65535. Default value: 80.
     */
    readonly attrHealthCheckPort: ros.IResolvable;
    /**
     * @Attribute HealthCheckSuccTimes: The number of consecutive successful health checks required for an application to be considered as healthy.
     */
    readonly attrHealthCheckSuccTimes: ros.IResolvable;
    /**
     * @Attribute HealthCheckTimeout: The timeout period of a health check response.
     */
    readonly attrHealthCheckTimeout: ros.IResolvable;
    /**
     * @Attribute HealthCheckType: The health check type.
     */
    readonly attrHealthCheckType: ros.IResolvable;
    /**
     * @Attribute HealthCheckUri: The URI used for health checks.
     */
    readonly attrHealthCheckUri: ros.IResolvable;
    /**
     * @Attribute QuicCid: Indicates whether QUIC is enabled.
     */
    readonly attrQuicCid: ros.IResolvable;
    /**
     * @Attribute Remarks: The remarks. This parameter is empty by default.
     */
    readonly attrRemarks: ros.IResolvable;
    /**
     * @Attribute ServicePort: The server port.
     */
    readonly attrServicePort: ros.IResolvable;
    /**
     * @Attribute TargetPort: The backend port, which is also the service port of the application.
     */
    readonly attrTargetPort: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the application was last modified. The time follows the ISO 8601 standard in the YYYY-MM-DDThh:mm:ss format. The time is displayed in UTC.
     */
    readonly attrUpdateTime: ros.IResolvable;
    /**
     * @Attribute VersionCount: The number of versions of the application.
     */
    readonly attrVersionCount: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property edgeContainerAppName: The name of the application. The name must start with a lowercase letter and can contain lowercase letters, digits, and hyphens (-). The name must be 6 to 128 characters in length.
     */
    edgeContainerAppName: string | ros.IResolvable;
    /**
     * @Property servicePort: The server port. Valid values: 1 to 65535.
     */
    servicePort: number | ros.IResolvable;
    /**
     * @Property targetPort: The backend port, which is also the service port of the application. Valid values: 1 to 65535.
     */
    targetPort: number | ros.IResolvable;
    /**
     * @Property healthCheckFailTimes: The number of consecutive failed health checks required for an application to be considered as unhealthy. Valid values: 1 to 10. Default value: 5.
     */
    healthCheckFailTimes: number | ros.IResolvable | undefined;
    /**
     * @Property healthCheckHost: The domain name that is used for health checks. This parameter is empty by default.
     */
    healthCheckHost: string | ros.IResolvable | undefined;
    /**
     * @Property healthCheckHttpCode: The HTTP status code returned for a successful health check. Valid values:
     * http_2xx (default)http_3xx
     */
    healthCheckHttpCode: string | ros.IResolvable | undefined;
    /**
     * @Property healthCheckInterval: The interval between two consecutive health checks. Unit: seconds. Valid values: 1 to 50. Default value: 5.
     */
    healthCheckInterval: number | ros.IResolvable | undefined;
    /**
     * @Property healthCheckMethod: The HTTP request method for health checks. Valid values:
     * HEAD (default): requests the headers of the resource.
     * GET: requests the specified resource and returns both the headers and entity body.
     */
    healthCheckMethod: string | ros.IResolvable | undefined;
    /**
     * @Property healthCheckPort: The port used for health checks. Valid values: 1 to 65535. Default value: 80.
     */
    healthCheckPort: number | ros.IResolvable | undefined;
    /**
     * @Property healthCheckSuccTimes: The number of consecutive successful health checks required for an application to be considered as healthy. Valid values: 1 to 10. Default value: 2.
     */
    healthCheckSuccTimes: number | ros.IResolvable | undefined;
    /**
     * @Property healthCheckTimeout: The timeout period of a health check response. If a backend ECS instance does not respond within the specified timeout period, the ECS instance fails the health check. Unit: seconds. Valid values: 1 to 100. Default value: 3.
     */
    healthCheckTimeout: number | ros.IResolvable | undefined;
    /**
     * @Property healthCheckType: The health check type. By default, this parameter is left empty. Valid values:
     * l4: Layer 4 health check.
     * l7: Layer 7 health check.
     *
     */
    healthCheckType: string | ros.IResolvable | undefined;
    /**
     * @Property healthCheckUri: The URI used for health checks. The URI must be 1 to 80 characters in length. Default value: "\/".
     */
    healthCheckUri: string | ros.IResolvable | undefined;
    /**
     * @Property remarks: The remarks. This parameter is empty by default.
     */
    remarks: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosEdgeContainerAppProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosEdgeContainerAppRecord`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-edgecontainerapprecord
 */
export interface RosEdgeContainerAppRecordProps {
    /**
     * @Property appId: The application ID.
     */
    readonly appId: string | ros.IResolvable;
    /**
     * @Property recordName: The associated domain name.
     */
    readonly recordName: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::EdgeContainerAppRecord`The , which type creates an associated domain name for an edge container application.
 * @Note This class does not contain additional functions, so it is recommended to use the `EdgeContainerAppRecord` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-edgecontainerapprecord
 */
export declare class RosEdgeContainerAppRecord extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::EdgeContainerAppRecord";
    /**
     * @Attribute AppId: The application ID.
     */
    readonly attrAppId: ros.IResolvable;
    /**
     * @Attribute Cname: The CNAME of the associated domain name.
     */
    readonly attrCname: ros.IResolvable;
    /**
     * @Attribute ConfigId: The configuration ID of the associated domain name.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the domain name was added. The time follows the ISO 8601 standard in the YYYY-MM-DDThh:mm:ss format. The time is displayed in UTC.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute RecordId: The record ID of the associated domain name.
     */
    readonly attrRecordId: ros.IResolvable;
    /**
     * @Attribute RecordName: The associated domain name.
     */
    readonly attrRecordName: ros.IResolvable;
    /**
     * @Attribute SchemdId: The scheduling domain ID of the associated domain name.
     */
    readonly attrSchemdId: ros.IResolvable;
    /**
     * @Attribute SiteId: The website ID.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the scheduling domain ID or CNAME was last modified. The time follows the ISO 8601 standard in the YYYY-MM-DDThh:mm:ss format. The time is displayed in UTC.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property appId: The application ID.
     */
    appId: string | ros.IResolvable;
    /**
     * @Property recordName: The associated domain name.
     */
    recordName: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosEdgeContainerAppRecordProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosHttpIncomingRequestHeaderModificationRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpincomingrequestheadermodificationrule
 */
export interface RosHttpIncomingRequestHeaderModificationRuleProps {
    /**
     * @Property requestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    readonly requestHeaderModification: Array<RosHttpIncomingRequestHeaderModificationRule.RequestHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpIncomingRequestHeaderModificationRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpIncomingRequestHeaderModificationRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpincomingrequestheadermodificationrule
 */
export declare class RosHttpIncomingRequestHeaderModificationRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpIncomingRequestHeaderModificationRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type. You can use this parameter to check the global configuration or rule configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute RequestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    readonly attrRequestHeaderModification: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property requestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    requestHeaderModification: Array<RosHttpIncomingRequestHeaderModificationRule.RequestHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpIncomingRequestHeaderModificationRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosHttpIncomingRequestHeaderModificationRule {
    /**
     * @stability external
     */
    interface RequestHeaderModificationProperty {
        /**
         * @Property type: Value type. Value range:
     * - `static`:static mode.
     * - `dynamic`:dynamic mode.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property value: Request header value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property operation: Mode of operation. Value range:
     * - `add`: add.
     * - `del`: delete
     * - `modify`: change.
         */
        readonly operation: string | ros.IResolvable;
        /**
         * @Property name: Request Header Name.
         */
        readonly name: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosHttpIncomingResponseHeaderModificationRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpincomingresponseheadermodificationrule
 */
export interface RosHttpIncomingResponseHeaderModificationRuleProps {
    /**
     * @Property responseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    readonly responseHeaderModification: Array<RosHttpIncomingResponseHeaderModificationRule.ResponseHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpIncomingResponseHeaderModificationRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpIncomingResponseHeaderModificationRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpincomingresponseheadermodificationrule
 */
export declare class RosHttpIncomingResponseHeaderModificationRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpIncomingResponseHeaderModificationRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute ResponseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    readonly attrResponseHeaderModification: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property responseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    responseHeaderModification: Array<RosHttpIncomingResponseHeaderModificationRule.ResponseHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpIncomingResponseHeaderModificationRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosHttpIncomingResponseHeaderModificationRule {
    /**
     * @stability external
     */
    interface ResponseHeaderModificationProperty {
        /**
         * @Property type: The value type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property value: The response header value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property operation: Operation method. Possible values:
     * - `add`: Add
     * - `del`: Delete
     * - `modify`: Modify.
         */
        readonly operation: string | ros.IResolvable;
        /**
         * @Property name: The response header name.
         */
        readonly name: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosHttpRequestHeaderModificationRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httprequestheadermodificationrule
 */
export interface RosHttpRequestHeaderModificationRuleProps {
    /**
     * @Property requestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    readonly requestHeaderModification: Array<RosHttpRequestHeaderModificationRule.RequestHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpRequestHeaderModificationRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpRequestHeaderModificationRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httprequestheadermodificationrule
 */
export declare class RosHttpRequestHeaderModificationRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpRequestHeaderModificationRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type. You can use this parameter to check the global configuration or rule configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute RequestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    readonly attrRequestHeaderModification: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property requestHeaderModification: The configurations of modifying request headers. You can add, delete, or modify a request header.
     */
    requestHeaderModification: Array<RosHttpRequestHeaderModificationRule.RequestHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpRequestHeaderModificationRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosHttpRequestHeaderModificationRule {
    /**
     * @stability external
     */
    interface RequestHeaderModificationProperty {
        /**
         * @Property type: Value type. Value range:
     * - `static`:static mode.
     * - `dynamic`:dynamic mode.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property value: Request header value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property operation: Mode of operation. Value range:
     * - `add`: add.
     * - `del`: delete
     * - `modify`: change.
         */
        readonly operation: string | ros.IResolvable;
        /**
         * @Property name: Request Header Name.
         */
        readonly name: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosHttpResponseHeaderModificationRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpresponseheadermodificationrule
 */
export interface RosHttpResponseHeaderModificationRuleProps {
    /**
     * @Property responseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    readonly responseHeaderModification: Array<RosHttpResponseHeaderModificationRule.ResponseHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpResponseHeaderModificationRule`The , which resource type is used to create a configuration for modifying HTTP response headers.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpResponseHeaderModificationRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpresponseheadermodificationrule
 */
export declare class RosHttpResponseHeaderModificationRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpResponseHeaderModificationRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute ResponseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    readonly attrResponseHeaderModification: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property responseHeaderModification: Modify response headers, supporting add, delete, and modify operations.
     */
    responseHeaderModification: Array<RosHttpResponseHeaderModificationRule.ResponseHeaderModificationProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpResponseHeaderModificationRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosHttpResponseHeaderModificationRule {
    /**
     * @stability external
     */
    interface ResponseHeaderModificationProperty {
        /**
         * @Property type: The value type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property value: The response header value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property operation: Operation method. Possible values:
     * - `add`: Add
     * - `del`: Delete
     * - `modify`: Modify.
         */
        readonly operation: string | ros.IResolvable;
        /**
         * @Property name: The response header name.
         */
        readonly name: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosHttpsApplicationConfiguration`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpsapplicationconfiguration
 */
export interface RosHttpsApplicationConfigurationProps {
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property altSvc: Function switch, default off. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly altSvc?: string | ros.IResolvable;
    /**
     * @Property altSvcClear: Alt-Svc whether The header contains the clear parameter. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly altSvcClear?: string | ros.IResolvable;
    /**
     * @Property altSvcMa: The effective time of the Alt-Svc, in seconds. The default value is 86400 seconds.
     */
    readonly altSvcMa?: string | ros.IResolvable;
    /**
     * @Property altSvcPersist: Alt-Svc whether The header contains the persist parameter. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly altSvcPersist?: string | ros.IResolvable;
    /**
     * @Property hsts: Whether to enable HSTS. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly hsts?: string | ros.IResolvable;
    /**
     * @Property hstsIncludeSubdomains: Whether to include subdomains in HSTS is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly hstsIncludeSubdomains?: string | ros.IResolvable;
    /**
     * @Property hstsMaxAge: The expiration time of HSTS, in seconds.
     */
    readonly hstsMaxAge?: string | ros.IResolvable;
    /**
     * @Property hstsPreload: Whether to enable HSTS preloading. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly hstsPreload?: string | ros.IResolvable;
    /**
     * @Property httpsForce: Whether to enable forced HTTPS. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly httpsForce?: string | ros.IResolvable;
    /**
     * @Property httpsForceCode: Forced HTTPS jump status code, value range:
     * 301
     * 302
     * 307
     * 308
     */
    readonly httpsForceCode?: string | ros.IResolvable;
    /**
     * @Property httpsNoSniDeny: Whether to enable to reject TLS handshake requests without SNI. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly httpsNoSniDeny?: string | ros.IResolvable;
    /**
     * @Property httpsSniVerify: Whether to enable SNI verification. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly httpsSniVerify?: string | ros.IResolvable;
    /**
     * @Property httpsSniWhitelist: Specifies the list of allowed SNI whitelists, separated by spaces.
     */
    readonly httpsSniWhitelist?: string | ros.IResolvable;
    /**
     * @Property paymentType: Payment Type.
     */
    readonly paymentType?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * Match all incoming requests: value set to true
     * Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpsApplicationConfiguration`The , which resource is used to add an HTTPS application configuration for a website.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpsApplicationConfiguration` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpsapplicationconfiguration
 */
export declare class RosHttpsApplicationConfiguration extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpsApplicationConfiguration";
    /**
     * @Attribute AltSvc: Function switch, default off.
     */
    readonly attrAltSvc: ros.IResolvable;
    /**
     * @Attribute AltSvcClear: Alt-Svc whether The header contains the clear parameter. This parameter is disabled by default.
     */
    readonly attrAltSvcClear: ros.IResolvable;
    /**
     * @Attribute AltSvcMa: The effective time of the Alt-Svc, in seconds. The default value is 86400 seconds.
     */
    readonly attrAltSvcMa: ros.IResolvable;
    /**
     * @Attribute AltSvcPersist: Alt-Svc whether The header contains the persist parameter. This parameter is disabled by default.
     */
    readonly attrAltSvcPersist: ros.IResolvable;
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Hsts: Whether to enable HSTS. It is disabled by default.
     */
    readonly attrHsts: ros.IResolvable;
    /**
     * @Attribute HstsIncludeSubdomains: Whether to include subdomains in HSTS is disabled by default.
     */
    readonly attrHstsIncludeSubdomains: ros.IResolvable;
    /**
     * @Attribute HstsMaxAge: The expiration time of HSTS, in seconds.
     */
    readonly attrHstsMaxAge: ros.IResolvable;
    /**
     * @Attribute HstsPreload: Whether to enable HSTS preloading. It is disabled by default.
     */
    readonly attrHstsPreload: ros.IResolvable;
    /**
     * @Attribute HttpsForce: Whether to enable forced HTTPS. It is disabled by default.
     */
    readonly attrHttpsForce: ros.IResolvable;
    /**
     * @Attribute HttpsForceCode: Forced HTTPS jump status code, value range:.
     */
    readonly attrHttpsForceCode: ros.IResolvable;
    /**
     * @Attribute HttpsNoSniDeny: Whether to enable to reject TLS handshake requests without SNI. This parameter is disabled by default.
     */
    readonly attrHttpsNoSniDeny: ros.IResolvable;
    /**
     * @Attribute HttpsSniVerify: Whether to enable SNI verification. It is disabled by default.
     */
    readonly attrHttpsSniVerify: ros.IResolvable;
    /**
     * @Attribute HttpsSniWhitelist: Specifies the list of allowed SNI whitelists, separated by spaces.
     */
    readonly attrHttpsSniWhitelist: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property altSvc: Function switch, default off. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    altSvc: string | ros.IResolvable | undefined;
    /**
     * @Property altSvcClear: Alt-Svc whether The header contains the clear parameter. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    altSvcClear: string | ros.IResolvable | undefined;
    /**
     * @Property altSvcMa: The effective time of the Alt-Svc, in seconds. The default value is 86400 seconds.
     */
    altSvcMa: string | ros.IResolvable | undefined;
    /**
     * @Property altSvcPersist: Alt-Svc whether The header contains the persist parameter. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    altSvcPersist: string | ros.IResolvable | undefined;
    /**
     * @Property hsts: Whether to enable HSTS. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    hsts: string | ros.IResolvable | undefined;
    /**
     * @Property hstsIncludeSubdomains: Whether to include subdomains in HSTS is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    hstsIncludeSubdomains: string | ros.IResolvable | undefined;
    /**
     * @Property hstsMaxAge: The expiration time of HSTS, in seconds.
     */
    hstsMaxAge: string | ros.IResolvable | undefined;
    /**
     * @Property hstsPreload: Whether to enable HSTS preloading. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    hstsPreload: string | ros.IResolvable | undefined;
    /**
     * @Property httpsForce: Whether to enable forced HTTPS. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    httpsForce: string | ros.IResolvable | undefined;
    /**
     * @Property httpsForceCode: Forced HTTPS jump status code, value range:
     * 301
     * 302
     * 307
     * 308
     */
    httpsForceCode: string | ros.IResolvable | undefined;
    /**
     * @Property httpsNoSniDeny: Whether to enable to reject TLS handshake requests without SNI. This parameter is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    httpsNoSniDeny: string | ros.IResolvable | undefined;
    /**
     * @Property httpsSniVerify: Whether to enable SNI verification. It is disabled by default. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    httpsSniVerify: string | ros.IResolvable | undefined;
    /**
     * @Property httpsSniWhitelist: Specifies the list of allowed SNI whitelists, separated by spaces.
     */
    httpsSniWhitelist: string | ros.IResolvable | undefined;
    /**
     * @Property paymentType: Payment Type.
     */
    paymentType: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * Match all incoming requests: value set to true
     * Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpsApplicationConfigurationProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosHttpsBasicConfiguration`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpsbasicconfiguration
 */
export interface RosHttpsBasicConfigurationProps {
    /**
     * @Property siteId: Site ID, which can be obtained by calling the [ListSites](~~ListSites~~) interface.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property ciphersuite: Custom cipher suite, indicating the specific encryption algorithm selected when CiphersuiteGroup is set to custom.
     */
    readonly ciphersuite?: string | ros.IResolvable;
    /**
     * @Property ciphersuiteGroup: Cipher suite group. Default is all cipher suites. Possible values:
     * - all: All cipher suites.
     * - strict: Strong cipher suites.
     * - custom: Custom cipher suites.
     */
    readonly ciphersuiteGroup?: string | ros.IResolvable;
    /**
     * @Property http2: Indicates whether HTTP2 is enabled. Default is on. Possible values:
     * - on: Enabled.
     * - off: Disabled.
     */
    readonly http2?: string | ros.IResolvable;
    /**
     * @Property http3: Whether to enable HTTP3, which is enabled by default. The value can be:
     * - on: Enabled.
     * - off: Disabled.
     */
    readonly http3?: string | ros.IResolvable;
    /**
     * @Property https: Whether to enable HTTPS. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    readonly https?: string | ros.IResolvable;
    /**
     * @Property ocspStapling: Indicates whether OCSP is enabled. Default is off. Possible values:
     * - on: Enabled.
     * - off: Disabled.
     */
    readonly ocspStapling?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * -  Match all incoming requests: value set to true
     * -  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property tls10: Whether to enable TLS1.0. Default is disabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    readonly tls10?: string | ros.IResolvable;
    /**
     * @Property tls11: Whether to enable TLS1.1. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    readonly tls11?: string | ros.IResolvable;
    /**
     * @Property tls12: Whether to enable TLS1.2. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    readonly tls12?: string | ros.IResolvable;
    /**
     * @Property tls13: Whether to enable TLS1.3. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    readonly tls13?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::HttpsBasicConfiguration`.
 * @Note This class does not contain additional functions, so it is recommended to use the `HttpsBasicConfiguration` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-httpsbasicconfiguration
 */
export declare class RosHttpsBasicConfiguration extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::HttpsBasicConfiguration";
    /**
     * @Attribute Ciphersuite: Custom cipher suite, indicating the specific encryption algorithm selected when CiphersuiteGroup is set to custom.
     */
    readonly attrCiphersuite: ros.IResolvable;
    /**
     * @Attribute CiphersuiteGroup: Cipher suite group. Default is all cipher suites.
     */
    readonly attrCiphersuiteGroup: ros.IResolvable;
    /**
     * @Attribute ConfigId: ConfigId of the configuration.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: Configuration type, which can be used to query global or rule configurations.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Http2: Indicates whether HTTP2 is enabled. Default is on.
     */
    readonly attrHttp2: ros.IResolvable;
    /**
     * @Attribute Http3: Whether to enable HTTP3, which is enabled by default.
     */
    readonly attrHttp3: ros.IResolvable;
    /**
     * @Attribute Https: Whether to enable HTTPS. Default is enabled.
     */
    readonly attrHttps: ros.IResolvable;
    /**
     * @Attribute OcspStapling: Indicates whether OCSP is enabled. Default is off.
     */
    readonly attrOcspStapling: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute Tls10: Whether to enable TLS1.0. Default is disabled.
     */
    readonly attrTls10: ros.IResolvable;
    /**
     * @Attribute Tls11: Whether to enable TLS1.1. Default is enabled.
     */
    readonly attrTls11: ros.IResolvable;
    /**
     * @Attribute Tls12: Whether to enable TLS1.2. Default is enabled.
     */
    readonly attrTls12: ros.IResolvable;
    /**
     * @Attribute Tls13: Whether to enable TLS1.3. Default is enabled.
     */
    readonly attrTls13: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: Site ID, which can be obtained by calling the [ListSites](~~ListSites~~) interface.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property ciphersuite: Custom cipher suite, indicating the specific encryption algorithm selected when CiphersuiteGroup is set to custom.
     */
    ciphersuite: string | ros.IResolvable | undefined;
    /**
     * @Property ciphersuiteGroup: Cipher suite group. Default is all cipher suites. Possible values:
     * - all: All cipher suites.
     * - strict: Strong cipher suites.
     * - custom: Custom cipher suites.
     */
    ciphersuiteGroup: string | ros.IResolvable | undefined;
    /**
     * @Property http2: Indicates whether HTTP2 is enabled. Default is on. Possible values:
     * - on: Enabled.
     * - off: Disabled.
     */
    http2: string | ros.IResolvable | undefined;
    /**
     * @Property http3: Whether to enable HTTP3, which is enabled by default. The value can be:
     * - on: Enabled.
     * - off: Disabled.
     */
    http3: string | ros.IResolvable | undefined;
    /**
     * @Property https: Whether to enable HTTPS. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    https: string | ros.IResolvable | undefined;
    /**
     * @Property ocspStapling: Indicates whether OCSP is enabled. Default is off. Possible values:
     * - on: Enabled.
     * - off: Disabled.
     */
    ocspStapling: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * -  Match all incoming requests: value set to true
     * -  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property tls10: Whether to enable TLS1.0. Default is disabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    tls10: string | ros.IResolvable | undefined;
    /**
     * @Property tls11: Whether to enable TLS1.1. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    tls11: string | ros.IResolvable | undefined;
    /**
     * @Property tls12: Whether to enable TLS1.2. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    tls12: string | ros.IResolvable | undefined;
    /**
     * @Property tls13: Whether to enable TLS1.3. Default is enabled. Possible values:
     * - on: Enable.
     * - off: Disable.
     */
    tls13: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosHttpsBasicConfigurationProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosImageTransform`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-imagetransform
 */
export interface RosImageTransformProps {
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property enable: Indicates whether the image transformations feature is enabled. Valid values:
     * on: Enabled.
     * off: Disabled.
     */
    readonly enable?: string | ros.IResolvable;
    /**
     * @Property paymentType: Payment Type.
     */
    readonly paymentType?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * Match all incoming requests: value set to true
     * Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::ImageTransform`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ImageTransform` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-imagetransform
 */
export declare class RosImageTransform extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::ImageTransform";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Enable: Indicates whether the image transformations feature is enabled.
     */
    readonly attrEnable: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property enable: Indicates whether the image transformations feature is enabled. Valid values:
     * on: Enabled.
     * off: Disabled.
     */
    enable: string | ros.IResolvable | undefined;
    /**
     * @Property paymentType: Payment Type.
     */
    paymentType: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * Match all incoming requests: value set to true
     * Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on: Enabled.
     * off: Disabled.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosImageTransformProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosKv`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-kv
 */
export interface RosKvProps {
    /**
     * @Property key: The key name. The name can be up to 512 characters in length and cannot contain spaces or backslashes (\).
     */
    readonly key: string | ros.IResolvable;
    /**
     * @Property namespace: The name specified when calling [CreatevNamespace] https:\/\/help.aliyun.com\/document_detail\/2850317.html.
     */
    readonly namespace: string | ros.IResolvable;
    /**
     * @Property value: The content of the key. If the content has more than 256 characters in length, the system displays the first 100 and the last 100 characters, and omits the middle part.
     */
    readonly value: string | ros.IResolvable;
    /**
     * @Property expiration: The content of the key, which can be up to 2 MB (2 Ã 1000 Ã 1000). If the content is larger than 2 MB, call [PutKvWithHighCapacity] https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850486.html.
     */
    readonly expiration?: number | ros.IResolvable;
    /**
     * @Property expirationTtl: The time when the key-value pair expires, which cannot be earlier than the current time. The value is a timestamp in seconds. If you specify both Expiration and ExpirationTtl, only ExpirationTtl takes effect.
     */
    readonly expirationTtl?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::Kv`Use the , which resource type to set a single key-value pair in a KV bucket.
 * @Note This class does not contain additional functions, so it is recommended to use the `Kv` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-kv
 */
export declare class RosKv extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::Kv";
    /**
     * @Attribute Value: The content of the key. If the content has more than 256 characters in length, the system displays the first 100 and the last 100 characters, and omits the middle part.
     */
    readonly attrValue: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property key: The key name. The name can be up to 512 characters in length and cannot contain spaces or backslashes (\).
     */
    key: string | ros.IResolvable;
    /**
     * @Property namespace: The name specified when calling [CreatevNamespace] https:\/\/help.aliyun.com\/document_detail\/2850317.html.
     */
    namespace: string | ros.IResolvable;
    /**
     * @Property value: The content of the key. If the content has more than 256 characters in length, the system displays the first 100 and the last 100 characters, and omits the middle part.
     */
    value: string | ros.IResolvable;
    /**
     * @Property expiration: The content of the key, which can be up to 2 MB (2 Ã 1000 Ã 1000). If the content is larger than 2 MB, call [PutKvWithHighCapacity] https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850486.html.
     */
    expiration: number | ros.IResolvable | undefined;
    /**
     * @Property expirationTtl: The time when the key-value pair expires, which cannot be earlier than the current time. The value is a timestamp in seconds. If you specify both Expiration and ExpirationTtl, only ExpirationTtl takes effect.
     */
    expirationTtl: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosKvProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosKvNamespace`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-kvnamespace
 */
export interface RosKvNamespaceProps {
    /**
     * @Property kvNamespace: The name of the namespace.
     */
    readonly kvNamespace: string | ros.IResolvable;
    /**
     * @Property description: The description of the namespace.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::KvNamespace`The , which resource is used to create a key-value (KV) namespace.
 * @Note This class does not contain additional functions, so it is recommended to use the `KvNamespace` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-kvnamespace
 */
export declare class RosKvNamespace extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::KvNamespace";
    /**
     * @Attribute Description: The description of the namespace.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute KvCapacity: The available capacity of the namespace. Unit: bytes.
     */
    readonly attrKvCapacity: ros.IResolvable;
    /**
     * @Attribute KvCapacityString: The available capacity of the namespace.
     */
    readonly attrKvCapacityString: ros.IResolvable;
    /**
     * @Attribute KvCapacityUsed: The used capacity of the namespace. Unit: bytes.
     */
    readonly attrKvCapacityUsed: ros.IResolvable;
    /**
     * @Attribute KvCapacityUsedString: The used capacity of the namespace.
     */
    readonly attrKvCapacityUsedString: ros.IResolvable;
    /**
     * @Attribute KvNamespace: The name of the namespace.
     */
    readonly attrKvNamespace: ros.IResolvable;
    /**
     * @Attribute NamespaceId: The ID of the namespace.
     */
    readonly attrNamespaceId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property kvNamespace: The name of the namespace.
     */
    kvNamespace: string | ros.IResolvable;
    /**
     * @Property description: The description of the namespace.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosKvNamespaceProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosNetworkOptimization`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-networkoptimization
 */
export interface RosNetworkOptimizationProps {
    /**
     * @Property siteId: Site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property grpc: Whether to enable GRPC, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    readonly grpc?: string | ros.IResolvable;
    /**
     * @Property http2Origin: Whether to enable HTTP2 origin, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    readonly http2Origin?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
    /**
     * @Property smartRouting: Whether to enable smart routing service, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    readonly smartRouting?: string | ros.IResolvable;
    /**
     * @Property uploadMaxFilesize: Maximum upload file size, in MB, value range: 100ï½500.
     */
    readonly uploadMaxFilesize?: number | ros.IResolvable;
    /**
     * @Property websocket: Whether to enable Websocket, default is enabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    readonly websocket?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::NetworkOptimization`The , which type is used to add network optimization configurations for a website.
 * @Note This class does not contain additional functions, so it is recommended to use the `NetworkOptimization` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-networkoptimization
 */
export declare class RosNetworkOptimization extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::NetworkOptimization";
    /**
     * @Attribute ConfigId: ConfigId of the configuration, which can be obtained by calling the ListNetworkOptimizations.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: Configuration type, which can be used to query global or rule configurations.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Grpc: Whether to enable GRPC, default is disabled.
     */
    readonly attrGrpc: ros.IResolvable;
    /**
     * @Attribute Http2Origin: Whether to enable HTTP2 origin, default is disabled.
     */
    readonly attrHttp2Origin: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute SmartRouting: Whether to enable smart routing service, default is disabled.
     */
    readonly attrSmartRouting: ros.IResolvable;
    /**
     * @Attribute UploadMaxFilesize: Maximum upload file size, in MB, value range: 100ï½500.
     */
    readonly attrUploadMaxFilesize: ros.IResolvable;
    /**
     * @Attribute Websocket: Whether to enable Websocket, default is enabled.
     */
    readonly attrWebsocket: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: Site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property grpc: Whether to enable GRPC, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    grpc: string | ros.IResolvable | undefined;
    /**
     * @Property http2Origin: Whether to enable HTTP2 origin, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    http2Origin: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @Property smartRouting: Whether to enable smart routing service, default is disabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    smartRouting: string | ros.IResolvable | undefined;
    /**
     * @Property uploadMaxFilesize: Maximum upload file size, in MB, value range: 100ï½500.
     */
    uploadMaxFilesize: number | ros.IResolvable | undefined;
    /**
     * @Property websocket: Whether to enable Websocket, default is enabled. Value range:
     * - `on`: Enabled
     * - `off`: Disabled.
     */
    websocket: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosNetworkOptimizationProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosOriginCaCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-origincacertificate
 */
export interface RosOriginCaCertificateProps {
    /**
     * @Property certificate: Certificate content.
     */
    readonly certificate: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property name: The certificate name.
     */
    readonly name?: string | ros.IResolvable;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    readonly validityDays?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::OriginCaCertificate`.
 * @Note This class does not contain additional functions, so it is recommended to use the `OriginCaCertificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-origincacertificate
 */
export declare class RosOriginCaCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::OriginCaCertificate";
    /**
     * @Attribute Certificate: The certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute CommonName: The certificate common name.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the certificate was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute FingerprintSha256: The SHA-256 fingerprint of the certificate.
     */
    readonly attrFingerprintSha256: ros.IResolvable;
    /**
     * @Attribute Issuer: The certificate authority (CA) that issued the certificate.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute Name: The certificate name.
     */
    readonly attrName: ros.IResolvable;
    /**
     * @Attribute NotAfter: The expiration date of the certificate validity period.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: The start time of the certificate validity period.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute OriginCaCertificateId: The certificate ID.
     */
    readonly attrOriginCaCertificateId: ros.IResolvable;
    /**
     * @Attribute PubkeyAlgorithm: Certificate public key algorithm.
     */
    readonly attrPubkeyAlgorithm: ros.IResolvable;
    /**
     * @Attribute SAN: The Subject Alternative Name (SAN) of the certificate.
     */
    readonly attrSan: ros.IResolvable;
    /**
     * @Attribute SerialNumber: The serial number of the certificate.
     */
    readonly attrSerialNumber: ros.IResolvable;
    /**
     * @Attribute SignatureAlgorithm: The signature algorithm of the certificate.
     */
    readonly attrSignatureAlgorithm: ros.IResolvable;
    /**
     * @Attribute SiteId: The website ID
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute Type: The type of the certificate.
     */
    readonly attrType: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the certificate was updated.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property certificate: Certificate content.
     */
    certificate: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property name: The certificate name.
     */
    name: string | ros.IResolvable | undefined;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    validityDays: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosOriginCaCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosOriginClientCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originclientcertificate
 */
export interface RosOriginClientCertificateProps {
    /**
     * @Property certificate: The certificate content.
     */
    readonly certificate: string | ros.IResolvable;
    /**
     * @Property privateKey: The private key of the certificate.
     */
    readonly privateKey: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property hostnames: The domain names to associate.
     */
    readonly hostnames?: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property originClientCertificateName: The certificate name.
     */
    readonly originClientCertificateName?: string | ros.IResolvable;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    readonly validityDays?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::OriginClientCertificate`.
 * @Note This class does not contain additional functions, so it is recommended to use the `OriginClientCertificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originclientcertificate
 */
export declare class RosOriginClientCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::OriginClientCertificate";
    /**
     * @Attribute Certificate: The certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute CommonName: The Common Name of the certificate.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the certificate was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute FingerprintSha256: The SHA-256 fingerprint of the certificate.
     */
    readonly attrFingerprintSha256: ros.IResolvable;
    /**
     * @Attribute Hostnames: The domain names to associate.
     */
    readonly attrHostnames: ros.IResolvable;
    /**
     * @Attribute Issuer: The certificate authority (CA) that issued the certificate.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute NotAfter: The time when the certificate expires.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: The time when the certificate takes effect.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute OriginClientCertificateId: The certificate ID.
     */
    readonly attrOriginClientCertificateId: ros.IResolvable;
    /**
     * @Attribute OriginClientCertificateName: The certificate name.
     */
    readonly attrOriginClientCertificateName: ros.IResolvable;
    /**
     * @Attribute PubkeyAlgorithm: The public-key algorithm of the certificate.
     */
    readonly attrPubkeyAlgorithm: ros.IResolvable;
    /**
     * @Attribute SAN: The Subject Alternative Name (SAN) of the certificate.
     */
    readonly attrSan: ros.IResolvable;
    /**
     * @Attribute SerialNumber: The serial number of the certificate.
     */
    readonly attrSerialNumber: ros.IResolvable;
    /**
     * @Attribute SignatureAlgorithm: The signature algorithm of the certificate.
     */
    readonly attrSignatureAlgorithm: ros.IResolvable;
    /**
     * @Attribute SiteId: The website ID
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute Type: The certificate type.
     */
    readonly attrType: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the certificate was updated.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property certificate: The certificate content.
     */
    certificate: string | ros.IResolvable;
    /**
     * @Property privateKey: The private key of the certificate.
     */
    privateKey: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property hostnames: The domain names to associate.
     */
    hostnames: Array<string | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @Property originClientCertificateName: The certificate name.
     */
    originClientCertificateName: string | ros.IResolvable | undefined;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    validityDays: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosOriginClientCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosOriginPool`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originpool
 */
export interface RosOriginPoolProps {
    /**
     * @Property originPoolName: The source address pool name.
     */
    readonly originPoolName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property enabled: Whether the source address pool is enabled:
     * - `true`: Enabled;
     * - `false`: Not enabled.
     */
    readonly enabled?: boolean | ros.IResolvable;
    /**
     * @Property origins: The Source station information added to the source address pool. Multiple Source stations use arrays to transfer values.
     */
    readonly origins?: Array<RosOriginPool.OriginsProperty | ros.IResolvable> | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::OriginPool`The , which type creates an origin address pool.
 * @Note This class does not contain additional functions, so it is recommended to use the `OriginPool` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originpool
 */
export declare class RosOriginPool extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::OriginPool";
    /**
     * @Attribute Enabled: Whether the source address pool is enabled:.
     */
    readonly attrEnabled: ros.IResolvable;
    /**
     * @Attribute OriginPoolId: OriginPool Id.
     */
    readonly attrOriginPoolId: ros.IResolvable;
    /**
     * @Attribute OriginPoolName: The source address pool name.
     */
    readonly attrOriginPoolName: ros.IResolvable;
    /**
     * @Attribute Origins: The Source station information added to the source address pool. Multiple Source stations use arrays to transfer values.
     */
    readonly attrOrigins: ros.IResolvable;
    /**
     * @Attribute RecordName: The domain name assigned to the source address pool can be used as the source address recorded under the site.
     */
    readonly attrRecordName: ros.IResolvable;
    /**
     * @Attribute ReferenceLBCount: How many load balancers are referenced.
     */
    readonly attrReferenceLbCount: ros.IResolvable;
    /**
     * @Attribute References: The source address pool is referred to when the source address pool is configured by the load balancer or recorded as the source station.
     */
    readonly attrReferences: ros.IResolvable;
    /**
     * @Attribute SiteId: The site ID.
     */
    readonly attrSiteId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property originPoolName: The source address pool name.
     */
    originPoolName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property enabled: Whether the source address pool is enabled:
     * - `true`: Enabled;
     * - `false`: Not enabled.
     */
    enabled: boolean | ros.IResolvable | undefined;
    /**
     * @Property origins: The Source station information added to the source address pool. Multiple Source stations use arrays to transfer values.
     */
    origins: Array<RosOriginPool.OriginsProperty | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosOriginPoolProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosOriginPool {
    /**
     * @stability external
     */
    interface AuthConfProperty {
        /**
         * @Property secretKey: The SecretKey to be passed when AuthType is set to private_cross_account or private.
         */
        readonly secretKey?: string | ros.IResolvable;
        /**
         * @Property version: The signature version to be transmitted when the source station is AWS S3.
         */
        readonly version?: string | ros.IResolvable;
        /**
         * @Property region: The Region of the source station to be transmitted when the source station is AWS S3.
         */
        readonly region?: string | ros.IResolvable;
        /**
         * @Property accessKey: The AccessKey to be passed when AuthType is set to private_cross_account or private.
         */
        readonly accessKey?: string | ros.IResolvable;
        /**
         * @Property authType: Authentication type.
     * - `public`: public read\/write, which is used when the source station is OSS or S3 and is public read\/write;
     * - `private_same_account`: Used when the same account is private, the source station is OSS, and the authentication type is private authentication of the same account;
     * - `private_cross_account`: private cross-account, used when the origin station is OSS and the authentication type is cross-account private authentication;
     * - `private`: Used when the source station is S3 and the authentication type is private.
         */
        readonly authType?: string | ros.IResolvable;
    }
}
export declare namespace RosOriginPool {
    /**
     * @stability external
     */
    interface OriginsProperty {
        /**
         * @Property type: Source station type:
     * ip_domain: ip or domain name type origin station;
     * - `OSS`:OSS address source station;
     * - `S3`:AWS S3 Source station.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property header: The request header that is sent when returning to the source. Only Host is supported.
         */
        readonly header?: string | ros.IResolvable;
        /**
         * @Property address: Origin Address.
         */
        readonly address?: string | ros.IResolvable;
        /**
         * @Property enabled: Whether the source station is enabled:
     * - `true`: Enabled;
     * - `false`: Not enabled.
         */
        readonly enabled?: boolean | ros.IResolvable;
        /**
         * @Property authConf: The authentication information. When the source Station is an OSS or S3 and other source stations need to be authenticated, the authentication-related configuration information needs to be transmitted.
         */
        readonly authConf?: RosOriginPool.AuthConfProperty | ros.IResolvable;
        /**
         * @Property originId: Origin ID.
         */
        readonly originId?: number | ros.IResolvable;
        /**
         * @Property weight: The weight, an integer between 0 and 100.
         */
        readonly weight?: number | ros.IResolvable;
        /**
         * @Property name: The name of the origin, which must be unique within an origin address.
         */
        readonly name?: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosOriginProtection`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originprotection
 */
export interface RosOriginProtectionProps {
    /**
     * @Property siteId: Site Id.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property originConverge: The IP convergence status.
     * *   on
     * *   off.
     */
    readonly originConverge?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::OriginProtection`.
 * @Note This class does not contain additional functions, so it is recommended to use the `OriginProtection` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originprotection
 */
export declare class RosOriginProtection extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::OriginProtection";
    /**
     * @Attribute CurrentIpWhitelist: The IP whitelist for origin protection used by the website.
     */
    readonly attrCurrentIpWhitelist: ros.IResolvable;
    /**
     * @Attribute DiffIpWhitelist: The IP whitelist for origin protection that has been updated.
     */
    readonly attrDiffIpWhitelist: ros.IResolvable;
    /**
     * @Attribute LatestIpWhitelist: The latest IP whitelist for origin protection.
     */
    readonly attrLatestIpWhitelist: ros.IResolvable;
    /**
     * @Attribute OriginConverge: The IP convergence status.
     */
    readonly attrOriginConverge: ros.IResolvable;
    /**
     * @Attribute OriginProtection: Indicates whether origin protection is enabled.
     */
    readonly attrOriginProtection: ros.IResolvable;
    /**
     * @Attribute SiteId: The website ID
     */
    readonly attrSiteId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: Site Id.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property originConverge: The IP convergence status.
     * *   on
     * *   off.
     */
    originConverge: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosOriginProtectionProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosOriginRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originrule
 */
export interface RosOriginRuleProps {
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property dnsRecord: Overwrite the DNS resolution record of the origin request.
     */
    readonly dnsRecord?: string | ros.IResolvable;
    /**
     * @Property follow302Enable: Return Source 302 follow switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    readonly follow302Enable?: string | ros.IResolvable;
    /**
     * @Property follow302MaxTries: 302 follows the upper limit of the number of times, with a value range of [1-5].
     */
    readonly follow302MaxTries?: number | ros.IResolvable;
    /**
     * @Property follow302RetainArgs: Retain the original request parameter switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    readonly follow302RetainArgs?: string | ros.IResolvable;
    /**
     * @Property follow302RetainHeader: Retain the original request header switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    readonly follow302RetainHeader?: string | ros.IResolvable;
    /**
     * @Property follow302TargetHost: Modify the source host after 302.
     */
    readonly follow302TargetHost?: string | ros.IResolvable;
    /**
     * @Property originHost: The HOST carried in the back-to-origin request.
     */
    readonly originHost?: string | ros.IResolvable;
    /**
     * @Property originHttpPort: The port of the origin station accessed when the HTTP protocol is used to return to the origin.
     */
    readonly originHttpPort?: number | ros.IResolvable;
    /**
     * @Property originHttpsPort: Port of the origin server when using the HTTPS protocol for origin requests.
     */
    readonly originHttpsPort?: number | ros.IResolvable;
    /**
     * @Property originMtls: The mtls switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    readonly originMtls?: string | ros.IResolvable;
    /**
     * @Property originReadTimeout: Read timeout interval of the source station (s).
     */
    readonly originReadTimeout?: number | ros.IResolvable;
    /**
     * @Property originScheme: The protocol used by the back-to-origin request. Value range:
     * - `http`: uses the http protocol to return to the source.
     * - `https`: uses the https protocol to return to the source.
     * - `follow`: follows the Client Protocol back to the source.
     */
    readonly originScheme?: string | ros.IResolvable;
    /**
     * @Property originSni: SNI carried in the back-to-origin request.
     */
    readonly originSni?: string | ros.IResolvable;
    /**
     * @Property originVerify: Source station certificate verification switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    readonly originVerify?: string | ros.IResolvable;
    /**
     * @Property range: Use the range sharding method to download the file from the source. Value range:
     * - `on`: Open.
     * - `off`: off.
     * - `force`: force.
     */
    readonly range?: string | ros.IResolvable;
    /**
     * @Property rangeChunkSize: range shard size.
     */
    readonly rangeChunkSize?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::OriginRule`The , which type is used to add origin rules to a website.
 * @Note This class does not contain additional functions, so it is recommended to use the `OriginRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-originrule
 */
export declare class RosOriginRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::OriginRule";
    /**
     * @Attribute ConfigId: Back-to-source rule configuration ID.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type. You can use this parameter to check the global configuration or rule configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute DnsRecord: Overwrite the DNS resolution record of the origin request.
     */
    readonly attrDnsRecord: ros.IResolvable;
    /**
     * @Attribute Follow302Enable: Return Source 302 follow switch.
     */
    readonly attrFollow302Enable: ros.IResolvable;
    /**
     * @Attribute Follow302MaxTries: 302 follows the upper limit of the number of times, with a value range of [1-5].
     */
    readonly attrFollow302MaxTries: ros.IResolvable;
    /**
     * @Attribute Follow302RetainArgs: Retain the original request parameter switch.
     */
    readonly attrFollow302RetainArgs: ros.IResolvable;
    /**
     * @Attribute Follow302RetainHeader: Retain the original request header switch.
     */
    readonly attrFollow302RetainHeader: ros.IResolvable;
    /**
     * @Attribute Follow302TargetHost: Modify the source host after 302.
     */
    readonly attrFollow302TargetHost: ros.IResolvable;
    /**
     * @Attribute OriginHost: The HOST carried in the back-to-origin request.
     */
    readonly attrOriginHost: ros.IResolvable;
    /**
     * @Attribute OriginHttpPort: The port of the origin station accessed when the HTTP protocol is used to return to the origin.
     */
    readonly attrOriginHttpPort: ros.IResolvable;
    /**
     * @Attribute OriginHttpsPort: The port of the origin station accessed when the HTTPS protocol is used to return to the origin.
     */
    readonly attrOriginHttpsPort: ros.IResolvable;
    /**
     * @Attribute OriginMtls: The mtls switch.
     */
    readonly attrOriginMtls: ros.IResolvable;
    /**
     * @Attribute OriginReadTimeout: Read timeout interval of the source station (s).
     */
    readonly attrOriginReadTimeout: ros.IResolvable;
    /**
     * @Attribute OriginScheme: The protocol used by the back-to-origin request.
     */
    readonly attrOriginScheme: ros.IResolvable;
    /**
     * @Attribute OriginSni: SNI carried in the back-to-origin request.
     */
    readonly attrOriginSni: ros.IResolvable;
    /**
     * @Attribute OriginVerify: Source station certificate verification switch.
     */
    readonly attrOriginVerify: ros.IResolvable;
    /**
     * @Attribute Range: Use the range sharding method to download the file from the source.
     */
    readonly attrRange: ros.IResolvable;
    /**
     * @Attribute RangeChunkSize: range shard size.
     */
    readonly attrRangeChunkSize: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property dnsRecord: Overwrite the DNS resolution record of the origin request.
     */
    dnsRecord: string | ros.IResolvable | undefined;
    /**
     * @Property follow302Enable: Return Source 302 follow switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    follow302Enable: string | ros.IResolvable | undefined;
    /**
     * @Property follow302MaxTries: 302 follows the upper limit of the number of times, with a value range of [1-5].
     */
    follow302MaxTries: number | ros.IResolvable | undefined;
    /**
     * @Property follow302RetainArgs: Retain the original request parameter switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    follow302RetainArgs: string | ros.IResolvable | undefined;
    /**
     * @Property follow302RetainHeader: Retain the original request header switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    follow302RetainHeader: string | ros.IResolvable | undefined;
    /**
     * @Property follow302TargetHost: Modify the source host after 302.
     */
    follow302TargetHost: string | ros.IResolvable | undefined;
    /**
     * @Property originHost: The HOST carried in the back-to-origin request.
     */
    originHost: string | ros.IResolvable | undefined;
    /**
     * @Property originHttpPort: The port of the origin station accessed when the HTTP protocol is used to return to the origin.
     */
    originHttpPort: number | ros.IResolvable | undefined;
    /**
     * @Property originHttpsPort: Port of the origin server when using the HTTPS protocol for origin requests.
     */
    originHttpsPort: number | ros.IResolvable | undefined;
    /**
     * @Property originMtls: The mtls switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    originMtls: string | ros.IResolvable | undefined;
    /**
     * @Property originReadTimeout: Read timeout interval of the source station (s).
     */
    originReadTimeout: number | ros.IResolvable | undefined;
    /**
     * @Property originScheme: The protocol used by the back-to-origin request. Value range:
     * - `http`: uses the http protocol to return to the source.
     * - `https`: uses the https protocol to return to the source.
     * - `follow`: follows the Client Protocol back to the source.
     */
    originScheme: string | ros.IResolvable | undefined;
    /**
     * @Property originSni: SNI carried in the back-to-origin request.
     */
    originSni: string | ros.IResolvable | undefined;
    /**
     * @Property originVerify: Source station certificate verification switch. Value range:
     * - `on`: ON.
     * - `off`: closed.
     */
    originVerify: string | ros.IResolvable | undefined;
    /**
     * @Property range: Use the range sharding method to download the file from the source. Value range:
     * - `on`: Open.
     * - `off`: off.
     * - `force`: force.
     */
    range: string | ros.IResolvable | undefined;
    /**
     * @Property rangeChunkSize: range shard size.
     */
    rangeChunkSize: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosOriginRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosPage`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-page
 */
export interface RosPageProps {
    /**
     * @Property contentType: The Content-Type field in the HTTP header. Valid values:
     * text\/html
     * application\/json
     */
    readonly contentType: string | ros.IResolvable;
    /**
     * @Property pageName: The name of the custom response page.
     */
    readonly pageName: string | ros.IResolvable;
    /**
     * @Property content: The Base64-encoded page content. Example: "PGh0bWw+aGVsbG8gcGFnZTwvaHRtbD4=", which indicates "hello page".
     */
    readonly content?: string | ros.IResolvable;
    /**
     * @Property description: The description of the page.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::Page`The , which type is used to create a custom response page.
 * @Note This class does not contain additional functions, so it is recommended to use the `Page` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-page
 */
export declare class RosPage extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::Page";
    /**
     * @Attribute Content: The Base64-encoded content of the error page. The content type is specified by the Content-Type field.
     */
    readonly attrContent: ros.IResolvable;
    /**
     * @Attribute ContentType: The Content-Type field in the HTTP header.
     */
    readonly attrContentType: ros.IResolvable;
    /**
     * @Attribute Description: The description of the custom error page.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute Kind: The type of the custom response page.
     */
    readonly attrKind: ros.IResolvable;
    /**
     * @Attribute PageId: The ID of the custom error page.
     */
    readonly attrPageId: ros.IResolvable;
    /**
     * @Attribute PageName: The name of the custom response page.
     */
    readonly attrPageName: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the custom error page was last modified.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property contentType: The Content-Type field in the HTTP header. Valid values:
     * text\/html
     * application\/json
     */
    contentType: string | ros.IResolvable;
    /**
     * @Property pageName: The name of the custom response page.
     */
    pageName: string | ros.IResolvable;
    /**
     * @Property content: The Base64-encoded page content. Example: "PGh0bWw+aGVsbG8gcGFnZTwvaHRtbD4=", which indicates "hello page".
     */
    content: string | ros.IResolvable | undefined;
    /**
     * @Property description: The description of the page.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosPageProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosRecord`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-record
 */
export interface RosRecordProps {
    /**
     * @Property data: The DNS record information. The format of this field varies based on the record type. For more information, see [References] https:\/\/www.alibabacloud.com\/help\/doc-detail\/2708761.html?spm=openapi-amp.newDocPublishment.0.0.6a0f281feoeVWr.
     */
    readonly data: RosRecord.DataProperty | ros.IResolvable;
    /**
     * @Property recordName: The record name. This parameter specifies a filter condition for the query.
     */
    readonly recordName: string | ros.IResolvable;
    /**
     * @Property recordType: The type of the DNS record, such as A\/AAAA, CNAME, and TXT.
     */
    readonly recordType: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property authConf: The origin authentication information of the CNAME record.
     */
    readonly authConf?: RosRecord.AuthConfProperty | ros.IResolvable;
    /**
     * @Property bizName: The business scenario of the record for acceleration. Leave the parameter empty if your record is not proxied. Valid values:
     * image_video: video and image.
     * api: API.
     * web: web page.
     */
    readonly bizName?: string | ros.IResolvable;
    /**
     * @Property comment: The comment of the record. The maximum length is 100 characters.
     */
    readonly comment?: string | ros.IResolvable;
    /**
     * @Property hostPolicy: The origin host policy. This policy takes effect when the record type is CNAME. You can set the policy in two modes:
     * follow_hostname: Follow the host record.
     * follow_origin_domain: match the origin's domain name.
     */
    readonly hostPolicy?: string | ros.IResolvable;
    /**
     * @Property proxied: Specifies whether to proxy the record. Only CNAME and A\/AAAA records can be proxied. Valid values:
     * true
     * false.
     */
    readonly proxied?: boolean | ros.IResolvable;
    /**
     * @Property sourceType: The origin type for the CNAME record. This parameter is required when you add a CNAME record. Valid values:
     * OSS: OSS bucket.
     * S3: S3 bucket.
     * LB: load balancer.
     * OP: origin pool.
     * Domain: domain name.
     * If you do not pass this parameter or if you leave its value empty, Domain is used by default.
     */
    readonly sourceType?: string | ros.IResolvable;
    /**
     * @Property ttl: The TTL of the record. Unit: seconds. If the value is 1, the TTL of the record is determined by the system.
     */
    readonly ttl?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::Record`The , which type is used to create a DNS record.
 * @Note This class does not contain additional functions, so it is recommended to use the `Record` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-record
 */
export declare class RosRecord extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::Record";
    /**
     * @Attribute AuthConf: The origin authentication information of the CNAME record.
     */
    readonly attrAuthConf: ros.IResolvable;
    /**
     * @Attribute BizName: The business scenario of the record for acceleration. Leave the parameter empty if your record is not proxied.
     */
    readonly attrBizName: ros.IResolvable;
    /**
     * @Attribute Comment: The comment of the record. The maximum length is 100 characters.
     */
    readonly attrComment: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the record was created. The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute Data: The DNS record information. The format of this field varies based on the record type. For more information, see [References]https://www.alibabacloud.com/help/doc-detail/2708761.html?spm=openapi-amp.newDocPublishment.0.0.6a0f281feoeVWr.
     */
    readonly attrData: ros.IResolvable;
    /**
     * @Attribute HostPolicy: The origin host policy. This policy takes effect when the record type is CNAME.
     */
    readonly attrHostPolicy: ros.IResolvable;
    /**
     * @Attribute ModifyTime: The time when the record was updated. The time follows the ISO 8601 standard in the yyyy-MM-ddTHH:mm:ssZ format. The time is displayed in UTC.
     */
    readonly attrModifyTime: ros.IResolvable;
    /**
     * @Attribute Proxied: Specifies whether to proxy the record. Only CNAME and A/AAAA records can be proxied.
     */
    readonly attrProxied: ros.IResolvable;
    /**
     * @Attribute RecordCname: The CNAME. If you use CNAME setup when you add your website to ESA, the value is the CNAME that you configured then.
     */
    readonly attrRecordCname: ros.IResolvable;
    /**
     * @Attribute RecordId: Record Id.
     */
    readonly attrRecordId: ros.IResolvable;
    /**
     * @Attribute RecordName: The record name. This parameter specifies a filter condition for the query.
     */
    readonly attrRecordName: ros.IResolvable;
    /**
     * @Attribute RecordType: The type of the DNS record, such as A/AAAA, CNAME, and TXT.
     */
    readonly attrRecordType: ros.IResolvable;
    /**
     * @Attribute SiteId: The website ID.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute SourceType: The origin type for the CNAME record. This parameter is required when you add a CNAME record.
     */
    readonly attrSourceType: ros.IResolvable;
    /**
     * @Attribute Ttl: The TTL of the record. Unit: seconds. If the value is 1, the TTL of the record is determined by the system.
     */
    readonly attrTtl: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property data: The DNS record information. The format of this field varies based on the record type. For more information, see [References] https:\/\/www.alibabacloud.com\/help\/doc-detail\/2708761.html?spm=openapi-amp.newDocPublishment.0.0.6a0f281feoeVWr.
     */
    data: RosRecord.DataProperty | ros.IResolvable;
    /**
     * @Property recordName: The record name. This parameter specifies a filter condition for the query.
     */
    recordName: string | ros.IResolvable;
    /**
     * @Property recordType: The type of the DNS record, such as A\/AAAA, CNAME, and TXT.
     */
    recordType: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property authConf: The origin authentication information of the CNAME record.
     */
    authConf: RosRecord.AuthConfProperty | ros.IResolvable | undefined;
    /**
     * @Property bizName: The business scenario of the record for acceleration. Leave the parameter empty if your record is not proxied. Valid values:
     * image_video: video and image.
     * api: API.
     * web: web page.
     */
    bizName: string | ros.IResolvable | undefined;
    /**
     * @Property comment: The comment of the record. The maximum length is 100 characters.
     */
    comment: string | ros.IResolvable | undefined;
    /**
     * @Property hostPolicy: The origin host policy. This policy takes effect when the record type is CNAME. You can set the policy in two modes:
     * follow_hostname: Follow the host record.
     * follow_origin_domain: match the origin's domain name.
     */
    hostPolicy: string | ros.IResolvable | undefined;
    /**
     * @Property proxied: Specifies whether to proxy the record. Only CNAME and A\/AAAA records can be proxied. Valid values:
     * true
     * false.
     */
    proxied: boolean | ros.IResolvable | undefined;
    /**
     * @Property sourceType: The origin type for the CNAME record. This parameter is required when you add a CNAME record. Valid values:
     * OSS: OSS bucket.
     * S3: S3 bucket.
     * LB: load balancer.
     * OP: origin pool.
     * Domain: domain name.
     * If you do not pass this parameter or if you leave its value empty, Domain is used by default.
     */
    sourceType: string | ros.IResolvable | undefined;
    /**
     * @Property ttl: The TTL of the record. Unit: seconds. If the value is 1, the TTL of the record is determined by the system.
     */
    ttl: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosRecordProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosRecord {
    /**
     * @stability external
     */
    interface AuthConfProperty {
        /**
         * @Property secretKey: The secret access key of the account to which the origin server belongs. This parameter is required when the SourceType is OSS, and AuthType is private_same_account, or when the SourceType is S3 and AuthType is private.
         */
        readonly secretKey?: string | ros.IResolvable;
        /**
         * @Property version: The version of the signature algorithm. This parameter is required when the origin type is S3 and AuthType is private. The following two types are supported:
     * v2
     * v4
     * - If you leave this parameter empty, the default value v4 is used.
         */
        readonly version?: string | ros.IResolvable;
        /**
         * @Property region: The region of the origin. If the origin type is S3, you must specify this value. You can get the region information from the official website of S3.
         */
        readonly region?: string | ros.IResolvable;
        /**
         * @Property accessKey: The access key of the account to which the origin server belongs. This parameter is required when the SourceType is OSS, and AuthType is private_cross_account, or when the SourceType is S3 and AuthType is private.
         */
        readonly accessKey?: string | ros.IResolvable;
        /**
         * @Property authType: The authentication type of the origin server. Different origins support different authentication types. The type of origin refers to the SourceType parameter in this operation. If the type of origin is OSS or S3, you must specify the authentication type of the origin. Valid values:
     * public: public read. Select this value when the origin type is OSS or S3 and the origin access is public read.
     * private: private read. Select this value when the origin type is S3 and the origin access is private read.
     * private_same_account: private read under the same account. Select this value when the origin type is OSS, the origins belong to the same Alibaba Cloud account, and the origins have private read access.
     * private_cross_account: private read cross accounts. Select this value when the origin type is OSS, the origins belong to different Alibaba Cloud accounts, and the origins have private read access.
         */
        readonly authType?: string | ros.IResolvable;
    }
}
export declare namespace RosRecord {
    /**
     * @stability external
     */
    interface DataProperty {
        /**
         * @Property fingerprint: The public key fingerprint of the record. This parameter is required when you add a SSHFP record.
         */
        readonly fingerprint?: string | ros.IResolvable;
        /**
         * @Property usage: The usage identifier of the record, specified within the range of 0 to 255. This parameter is required when you add SMIMEA or TLSA records.
         */
        readonly usage?: number | ros.IResolvable;
        /**
         * @Property priority: The priority of the record, specified within the range of 0 to 65,535. A smaller value indicates a higher priority. This parameter is required when you add MX, SRV, and URI records.
         */
        readonly priority?: number | ros.IResolvable;
        /**
         * @Property port: The port of the record, specified within the range of 0 to 65,535. This parameter is required when you add an SRV record.
         */
        readonly port?: number | ros.IResolvable;
        /**
         * @Property algorithm: The encryption algorithm used for the record, specified within the range from 0 to 255. This parameter is required when you add CERT or SSHFP records.
         */
        readonly algorithm?: number | ros.IResolvable;
        /**
         * @Property flag: The flag bit of the record. The Flag for a CAA record indicates its priority and how it is processed, specified within the range of 0 to 255. This parameter is required when you add a CAA record.
         */
        readonly flag?: number | ros.IResolvable;
        /**
         * @Property weight: The weight of the record, specified within the range of 0 to 65,535. This parameter is required when you add SRV or URI records.
         */
        readonly weight?: number | ros.IResolvable;
        /**
         * @Property matchingType: The algorithm policy used to match or validate the certificate, specified within the range 0 to 255. This parameter is required when you add SMIMEA or TLSA records.
         */
        readonly matchingType?: number | ros.IResolvable;
        /**
         * @Property type: The certificate type of the record (in CERT records), or the public key type (in SSHFP records). This parameter is required when you add CERT or SSHFP records.
         */
        readonly type?: number | ros.IResolvable;
        /**
         * @Property keyTag: The public key identification for the record, specified within the range of 0 to 65,535. This parameter is required when you add a CAA record.
         */
        readonly keyTag?: number | ros.IResolvable;
        /**
         * @Property value: Record value or part of the record content. This parameter is required when you add A\/AAAA, CNAME, NS, MX, TXT, CAA, SRV, and URI records. It has different meanings based on types of records:
     * A\/AAAA: the IP address(es). Separate IP addresses with commas (,). You must have at least one IPv4 address.
     * CNAME: the target domain name.
     * NS: the name servers for the domain name.
     * MX: a valid domain name of the target mail server.
     * TXT: a valid text string.
     * CAA: a valid domain name of the certificate authority.
     * SRV: a valid domain name of the target host.
     * URI: a valid URI string.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property tag: The label of the record. The Tag of a CAA record indicate its specific type and usage. This parameter is required when you add a CAA record. Valid values:
     * issue: indicates that a CA is authorized to issue a certificate for the domain name. This is usually followed by the domain name of the CA.
     * issuewild: indicates that a CA is authorized to issue a wildcard certificate (such as *.example.com) for the domain name.
     * iodef: specifies a URI to receive reports about CAA record violations.
         */
        readonly tag?: string | ros.IResolvable;
        /**
         * @Property certificate: The public key of the certificate. This parameter is required when you add CERT, SMIMEA, or TLSA records.
         */
        readonly certificate?: string | ros.IResolvable;
        /**
         * @Property selector: The type of certificate or public key, specified within the range of 0 to 255. This parameter is required when you add SMIMEA or TLSA records.
         */
        readonly selector?: number | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosRedirectRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-redirectrule
 */
export interface RosRedirectRuleProps {
    /**
     * @Property reserveQueryString: Indicates whether the feature of retaining the query string is enabled. Valid values:
     * on
     * off.
     */
    readonly reserveQueryString: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property statusCode: The response code that you want to use to indicate URL redirection. Valid values:
     * *   301
     * *   302
     * *   303
     * *   307
     * *   308.
     */
    readonly statusCode: number | ros.IResolvable;
    /**
     * @Property targetUrl: The destination URL to which requests are redirected.
     */
    readonly targetUrl: string | ros.IResolvable;
    /**
     * @Property type: The redirect type. Valid value:
     * *   static.
     */
    readonly type: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     *  Match all incoming requests: value set to true
     *  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on
     * off.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::RedirectRule`The , which type is used to create a redirection configuration.
 * @Note This class does not contain additional functions, so it is recommended to use the `RedirectRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-redirectrule
 */
export declare class RosRedirectRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::RedirectRule";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The type of the configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute ReserveQueryString: Indicates whether the feature of retaining the query string is enabled.
     */
    readonly attrReserveQueryString: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Order of rule execution. The smaller the value, the higher the priority for execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute StatusCode: The response code that you want to use to indicate URL redirection.
     */
    readonly attrStatusCode: ros.IResolvable;
    /**
     * @Attribute TargetUrl: The destination URL to which requests are redirected.
     */
    readonly attrTargetUrl: ros.IResolvable;
    /**
     * @Attribute Type: The redirect type.
     */
    readonly attrType: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property reserveQueryString: Indicates whether the feature of retaining the query string is enabled. Valid values:
     * on
     * off.
     */
    reserveQueryString: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property statusCode: The response code that you want to use to indicate URL redirection. Valid values:
     * *   301
     * *   302
     * *   303
     * *   307
     * *   308.
     */
    statusCode: number | ros.IResolvable;
    /**
     * @Property targetUrl: The destination URL to which requests are redirected.
     */
    targetUrl: string | ros.IResolvable;
    /**
     * @Property type: The redirect type. Valid value:
     * *   static.
     */
    type: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     *  Match all incoming requests: value set to true
     *  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * on
     * off.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosRedirectRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosRewriteUrlRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-rewriteurlrule
 */
export interface RosRewriteUrlRuleProps {
    /**
     * @Property siteId: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property queryString: The desired query string to which you want to rewrite the query string in the original request.
     */
    readonly queryString?: string | ros.IResolvable;
    /**
     * @Property rewriteQueryStringType: Query string rewrite type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
     */
    readonly rewriteQueryStringType?: string | ros.IResolvable;
    /**
     * @Property rewriteUriType: URI rewrite type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
     */
    readonly rewriteUriType?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     *  Match all incoming requests: value set to true
     *  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     *  on: open.
     *  off: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property siteVersion: Version number of the site configuration. For a site with configuration version management enabled, you can use this parameter to specify the site version in which the configuration takes effect. The default version is 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
    /**
     * @Property uri: The desired URI to which you want to rewrite the path in the original request.
     */
    readonly uri?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::RewriteUrlRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `RewriteUrlRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-rewriteurlrule
 */
export declare class RosRewriteUrlRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::RewriteUrlRule";
    /**
     * @Attribute ConfigId: The configuration ID.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: Configuration type. This parameter determines whether to query global configurations or feature-specific configurations. Note: This logic only takes effect if the functionName parameter is also provided.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute QueryString: The desired query string to which you want to rewrite the query string in the original request.
     */
    readonly attrQueryString: ros.IResolvable;
    /**
     * @Attribute RewriteQueryStringType: Query string rewrite type.
     */
    readonly attrRewriteQueryStringType: ros.IResolvable;
    /**
     * @Attribute RewriteUriType: URI rewrite type.
     */
    readonly attrRewriteUriType: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: Rule execution order. The smaller the value, the higher the priority of execution.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: Version number of the site configuration. For a site with configuration version management enabled, you can use this parameter to specify the site version in which the configuration takes effect. The default version is 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute Uri: The desired URI to which you want to rewrite the path in the original request.
     */
    readonly attrUri: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property queryString: The desired query string to which you want to rewrite the query string in the original request.
     */
    queryString: string | ros.IResolvable | undefined;
    /**
     * @Property rewriteQueryStringType: Query string rewrite type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
     */
    rewriteQueryStringType: string | ros.IResolvable | undefined;
    /**
     * @Property rewriteUriType: URI rewrite type. Value range:
     * - `static`: Static mode.
     * - `dynamic`: Dynamic mode.
     */
    rewriteUriType: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     *  Match all incoming requests: value set to true
     *  Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     *  on: open.
     *  off: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: Version number of the site configuration. For a site with configuration version management enabled, you can use this parameter to specify the site version in which the configuration takes effect. The default version is 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @Property uri: The desired URI to which you want to rewrite the path in the original request.
     */
    uri: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosRewriteUrlRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosRoutineRoute`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-routineroute
 */
export interface RosRoutineRouteProps {
    /**
     * @Property routineName: The edge function Routine name.
     */
    readonly routineName: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property bypass: Bypass mode. Value range:
     * - on: Open
     * - off: off.
     */
    readonly bypass?: string | ros.IResolvable;
    /**
     * @Property fallback: The exception origin fetch switch. After you turn on this switch, if a function exception occurs, such as CPU usage exceeding the upper limit, requests are sent back to the origin. Valid values:
     * on
     * off
     *
     */
    readonly fallback?: string | ros.IResolvable;
    /**
     * @Property routeEnable: Routing switch. Value range:
     * - on: Open
     * - off: off.
     */
    readonly routeEnable?: string | ros.IResolvable;
    /**
     * @Property routeName: The name of the route.
     */
    readonly routeName?: string | ros.IResolvable;
    /**
     * @Property rule: The content of the rule.
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property sequence: Rule execution order.
     */
    readonly sequence?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::RoutineRoute`.
 * @Note This class does not contain additional functions, so it is recommended to use the `RoutineRoute` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-routineroute
 */
export declare class RosRoutineRoute extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::RoutineRoute";
    /**
     * @Attribute Bypass: Bypass mode.
     */
    readonly attrBypass: ros.IResolvable;
    /**
     * @Attribute ConfigId: The configuration ID.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type. You can use this parameter to check the global configuration or rule configuration.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute Fallback: An exception to the origin server switch will be enabled. If an exception occurs in the function, such as CPU usage exceeding limits, a request will be made to return to the origin server.
     */
    readonly attrFallback: ros.IResolvable;
    /**
     * @Attribute Mode: Configuration mode.
     */
    readonly attrMode: ros.IResolvable;
    /**
     * @Attribute RouteEnable: Routing switch.
     */
    readonly attrRouteEnable: ros.IResolvable;
    /**
     * @Attribute RouteName: The route name.
     */
    readonly attrRouteName: ros.IResolvable;
    /**
     * @Attribute RoutineName: The edge function Routine name.
     */
    readonly attrRoutineName: ros.IResolvable;
    /**
     * @Attribute Rule: The content of the rule.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute Sequence: Rule execution order.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: Version number of the site.
     */
    readonly attrSiteVersion: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property routineName: The edge function Routine name.
     */
    routineName: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property bypass: Bypass mode. Value range:
     * - on: Open
     * - off: off.
     */
    bypass: string | ros.IResolvable | undefined;
    /**
     * @Property fallback: The exception origin fetch switch. After you turn on this switch, if a function exception occurs, such as CPU usage exceeding the upper limit, requests are sent back to the origin. Valid values:
     * on
     * off
     *
     */
    fallback: string | ros.IResolvable | undefined;
    /**
     * @Property routeEnable: Routing switch. Value range:
     * - on: Open
     * - off: off.
     */
    routeEnable: string | ros.IResolvable | undefined;
    /**
     * @Property routeName: The name of the route.
     */
    routeName: string | ros.IResolvable | undefined;
    /**
     * @Property rule: The content of the rule.
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: Rule execution order.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosRoutineRouteProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosScheduledPreloadExecution`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-scheduledpreloadexecution
 */
export interface RosScheduledPreloadExecutionProps {
    /**
     * @Property interval: The time interval between each batch execution. Unit: seconds.
     */
    readonly interval: number | ros.IResolvable;
    /**
     * @Property scheduledPreloadJobId: The ID of the prefetch task.
     */
    readonly scheduledPreloadJobId: string | ros.IResolvable;
    /**
     * @Property sliceLen: The number of URLs prefetched in each batch.
     */
    readonly sliceLen: number | ros.IResolvable;
    /**
     * @Property endTime: The end time of the prefetch plan.
     */
    readonly endTime?: string | ros.IResolvable;
    /**
     * @Property startTime: The start time of the prefetch plan.
     */
    readonly startTime?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::ScheduledPreloadExecution`.
 * @Note This class does not contain additional functions, so it is recommended to use the `ScheduledPreloadExecution` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-scheduledpreloadexecution
 */
export declare class RosScheduledPreloadExecution extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::ScheduledPreloadExecution";
    /**
     * @Attribute EndTime: The end time of the prefetch plan.
     */
    readonly attrEndTime: ros.IResolvable;
    /**
     * @Attribute Interval: The time interval between each batch execution. Unit: seconds.
     */
    readonly attrInterval: ros.IResolvable;
    /**
     * @Attribute ScheduledPreloadExecutionId: The ID of the prefetch plan.
     */
    readonly attrScheduledPreloadExecutionId: ros.IResolvable;
    /**
     * @Attribute ScheduledPreloadJobId: The ID of the prefetch task.
     */
    readonly attrScheduledPreloadJobId: ros.IResolvable;
    /**
     * @Attribute SliceLen: The number of URLs prefetched in each batch.
     */
    readonly attrSliceLen: ros.IResolvable;
    /**
     * @Attribute StartTime: The start time of the prefetch plan.
     */
    readonly attrStartTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property interval: The time interval between each batch execution. Unit: seconds.
     */
    interval: number | ros.IResolvable;
    /**
     * @Property scheduledPreloadJobId: The ID of the prefetch task.
     */
    scheduledPreloadJobId: string | ros.IResolvable;
    /**
     * @Property sliceLen: The number of URLs prefetched in each batch.
     */
    sliceLen: number | ros.IResolvable;
    /**
     * @Property endTime: The end time of the prefetch plan.
     */
    endTime: string | ros.IResolvable | undefined;
    /**
     * @Property startTime: The start time of the prefetch plan.
     */
    startTime: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosScheduledPreloadExecutionProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosScheduledPreloadJob`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-scheduledpreloadjob
 */
export interface RosScheduledPreloadJobProps {
    /**
     * @Property insertWay: The method to submit the URLs to be prefetched.
     */
    readonly insertWay: string | ros.IResolvable;
    /**
     * @Property scheduledPreloadJobName: The name of the scheduled prefetch task.
     */
    readonly scheduledPreloadJobName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property ossUrl: Preheat OSS files regularly and fill in the OSS file address. Note: The OSS file contains the URL that you need to warm up.
     */
    readonly ossUrl?: string | ros.IResolvable;
    /**
     * @Property urlList: A list of URLs to be preheated, which is used when uploading a preheated file in the text box mode.
     */
    readonly urlList?: Array<string | ros.IResolvable> | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::ScheduledPreloadJob`The , which type is used to create a scheduled preload job.
 * @Note This class does not contain additional functions, so it is recommended to use the `ScheduledPreloadJob` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-scheduledpreloadjob
 */
export declare class RosScheduledPreloadJob extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::ScheduledPreloadJob";
    /**
     * @Attribute CreateTime: The time when the task was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute Domains: The domain names to be prefetched.
     */
    readonly attrDomains: ros.IResolvable;
    /**
     * @Attribute ErrorInfo: The error message.
     */
    readonly attrErrorInfo: ros.IResolvable;
    /**
     * @Attribute FailedFileOss: OSS address of failed file.
     */
    readonly attrFailedFileOss: ros.IResolvable;
    /**
     * @Attribute FileId: The ID of the URL list file, which can be used during downloads.
     */
    readonly attrFileId: ros.IResolvable;
    /**
     * @Attribute InsertWay: The method to submit the URLs to be prefetched.
     */
    readonly attrInsertWay: ros.IResolvable;
    /**
     * @Attribute ScheduledPreloadJobId: The ID of the prefetch task.
     */
    readonly attrScheduledPreloadJobId: ros.IResolvable;
    /**
     * @Attribute ScheduledPreloadJobName: The task name.
     */
    readonly attrScheduledPreloadJobName: ros.IResolvable;
    /**
     * @Attribute SiteId: The site ID.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute TaskSubmitted: The number of submitted prefetch tasks.
     */
    readonly attrTaskSubmitted: ros.IResolvable;
    /**
     * @Attribute TaskType: The task type. Valid values: refresh and preload.
     */
    readonly attrTaskType: ros.IResolvable;
    /**
     * @Attribute UrlCount: The total number of URLs.
     */
    readonly attrUrlCount: ros.IResolvable;
    /**
     * @Attribute UrlSubmitted: The number of submitted URLs.
     */
    readonly attrUrlSubmitted: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property insertWay: The method to submit the URLs to be prefetched.
     */
    insertWay: string | ros.IResolvable;
    /**
     * @Property scheduledPreloadJobName: The name of the scheduled prefetch task.
     */
    scheduledPreloadJobName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property ossUrl: Preheat OSS files regularly and fill in the OSS file address. Note: The OSS file contains the URL that you need to warm up.
     */
    ossUrl: string | ros.IResolvable | undefined;
    /**
     * @Property urlList: A list of URLs to be preheated, which is used when uploading a preheated file in the text box mode.
     */
    urlList: Array<string | ros.IResolvable> | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosScheduledPreloadJobProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosSite`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-site
 */
export interface RosSiteProps {
    /**
     * @Property instanceId: The ID of the associated package instance.
     */
    readonly instanceId: string | ros.IResolvable;
    /**
     * @Property siteName: The name of the Site.
     */
    readonly siteName: string | ros.IResolvable;
    /**
     * @Property accessType: The Access Type of the Site.
     */
    readonly accessType?: string | ros.IResolvable;
    /**
     * @Property coverage: Acceleration area.
     */
    readonly coverage?: string | ros.IResolvable;
    /**
     * @Property paymentType: Payment type.
     */
    readonly paymentType?: string | ros.IResolvable;
    /**
     * @Property resourceGroupId: The ID of the resource group.
     */
    readonly resourceGroupId?: string | ros.IResolvable;
    /**
     * @Property tags: Tags of the site.
     */
    readonly tags?: RosSite.TagsProperty[];
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::Site`You can use the , which resource type to create a site.
 * @Note This class does not contain additional functions, so it is recommended to use the `Site` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-site
 */
export declare class RosSite extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::Site";
    /**
     * @Attribute AccessType: Site Access Type.
     */
    readonly attrAccessType: ros.IResolvable;
    /**
     * @Attribute Coverage: Acceleration area.
     */
    readonly attrCoverage: ros.IResolvable;
    /**
     * @Attribute CreateTime: Creation time.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute InstanceId: The ID of the associated package instance.
     */
    readonly attrInstanceId: ros.IResolvable;
    /**
     * @Attribute ModifyTime: Modification time.
     */
    readonly attrModifyTime: ros.IResolvable;
    /**
     * @Attribute NameServerList: Site Resolution Name Server List.
     */
    readonly attrNameServerList: ros.IResolvable;
    /**
     * @Attribute ResourceGroupId: The ID of the resource group.
     */
    readonly attrResourceGroupId: ros.IResolvable;
    /**
     * @Attribute SiteId: The ID of the Site.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The name of the Site.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute Tags: The tags of the Site.
     */
    readonly attrTags: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property instanceId: The ID of the associated package instance.
     */
    instanceId: string | ros.IResolvable;
    /**
     * @Property siteName: The name of the Site.
     */
    siteName: string | ros.IResolvable;
    /**
     * @Property accessType: The Access Type of the Site.
     */
    accessType: string | ros.IResolvable | undefined;
    /**
     * @Property coverage: Acceleration area.
     */
    coverage: string | ros.IResolvable | undefined;
    /**
     * @Property paymentType: Payment type.
     */
    paymentType: string | ros.IResolvable | undefined;
    /**
     * @Property resourceGroupId: The ID of the resource group.
     */
    resourceGroupId: string | ros.IResolvable | undefined;
    /**
     * @Property tags: Tags of the site.
     */
    tags: RosSite.TagsProperty[] | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosSiteProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosSite {
    /**
     * @stability external
     */
    interface TagsProperty {
        /**
         * @Property value: undefined
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: undefined
         */
        readonly key: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosSiteDeliveryTask`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-sitedeliverytask
 */
export interface RosSiteDeliveryTaskProps {
    /**
     * @Property businessType: Real-time log type. Valid values:
     * - `dcdn_log_access_l1 (default)`: access log.
     * - `dcdn_log_er`: Edge Routine logs.
     * - `dcdn_log_waf`: firewall logs.
     * - `dcdn_log_ipa`: TCP\/UDP proxy logs.
     */
    readonly businessType: string | ros.IResolvable;
    /**
     * @Property dataCenter: Data Center. Values:
     * - `cn`: Mainland China.
     * - `sg`: Global (excluding Mainland China).
     */
    readonly dataCenter: string | ros.IResolvable;
    /**
     * @Property deliveryType: Delivery Type:
     * - `sls`: Alibaba Cloud Simple Log Service (SLS).
     * - `http`: Http service.
     * - `aws3`: Amazon s3 service.
     * - `oss`: Alibaba Cloud Object Storage Service.
     * - `kafka`: Kafka service.
     * - `aws3cmpt`: Amazon s3 Compatible Service.
     */
    readonly deliveryType: string | ros.IResolvable;
    /**
     * @Property fieldName: The list of delivery fields to be modified, separated by commas.
     */
    readonly fieldName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property taskName: The name of the delivery task.
     */
    readonly taskName: string | ros.IResolvable;
    /**
     * @Property discardRate: If the discard rate is not filled, the default value is 0.
     */
    readonly discardRate?: number | ros.IResolvable;
    /**
     * @Property httpDelivery: HTTP delivery configuration parameters.
     */
    readonly httpDelivery?: RosSiteDeliveryTask.HttpDeliveryProperty | ros.IResolvable;
    /**
     * @Property kafkaDelivery: Kafka delivery configuration parameters.
     */
    readonly kafkaDelivery?: RosSiteDeliveryTask.KafkaDeliveryProperty | ros.IResolvable;
    /**
     * @Property ossDelivery: OSS delivery configuration.
     */
    readonly ossDelivery?: RosSiteDeliveryTask.OssDeliveryProperty | ros.IResolvable;
    /**
     * @Property s3Delivery: S3\/S3 compatible delivery configuration parameters.
     */
    readonly s3Delivery?: RosSiteDeliveryTask.S3DeliveryProperty | ros.IResolvable;
    /**
     * @Property slsDelivery: SLS delivery configuration.
     */
    readonly slsDelivery?: RosSiteDeliveryTask.SlsDeliveryProperty | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::SiteDeliveryTask`.
 * @Note This class does not contain additional functions, so it is recommended to use the `SiteDeliveryTask` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-sitedeliverytask
 */
export declare class RosSiteDeliveryTask extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::SiteDeliveryTask";
    /**
     * @Attribute BusinessType: Real-time log type.
     */
    readonly attrBusinessType: ros.IResolvable;
    /**
     * @Attribute DataCenter: Data Center.
     */
    readonly attrDataCenter: ros.IResolvable;
    /**
     * @Attribute DeliveryType: Delivery Type:.
     */
    readonly attrDeliveryType: ros.IResolvable;
    /**
     * @Attribute DiscardRate: If the discard rate is not filled, the default value is 0.
     */
    readonly attrDiscardRate: ros.IResolvable;
    /**
     * @Attribute FieldName: The list of delivery fields to be modified, separated by commas.
     */
    readonly attrFieldName: ros.IResolvable;
    /**
     * @Attribute FilterRules: The filtering rules.
     */
    readonly attrFilterRules: ros.IResolvable;
    /**
     * @Attribute SinkConfig: The delivery configuration.
     */
    readonly attrSinkConfig: ros.IResolvable;
    /**
     * @Attribute SiteId: The site ID.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute TaskName: The task name.
     */
    readonly attrTaskName: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property businessType: Real-time log type. Valid values:
     * - `dcdn_log_access_l1 (default)`: access log.
     * - `dcdn_log_er`: Edge Routine logs.
     * - `dcdn_log_waf`: firewall logs.
     * - `dcdn_log_ipa`: TCP\/UDP proxy logs.
     */
    businessType: string | ros.IResolvable;
    /**
     * @Property dataCenter: Data Center. Values:
     * - `cn`: Mainland China.
     * - `sg`: Global (excluding Mainland China).
     */
    dataCenter: string | ros.IResolvable;
    /**
     * @Property deliveryType: Delivery Type:
     * - `sls`: Alibaba Cloud Simple Log Service (SLS).
     * - `http`: Http service.
     * - `aws3`: Amazon s3 service.
     * - `oss`: Alibaba Cloud Object Storage Service.
     * - `kafka`: Kafka service.
     * - `aws3cmpt`: Amazon s3 Compatible Service.
     */
    deliveryType: string | ros.IResolvable;
    /**
     * @Property fieldName: The list of delivery fields to be modified, separated by commas.
     */
    fieldName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property taskName: The name of the delivery task.
     */
    taskName: string | ros.IResolvable;
    /**
     * @Property discardRate: If the discard rate is not filled, the default value is 0.
     */
    discardRate: number | ros.IResolvable | undefined;
    /**
     * @Property httpDelivery: HTTP delivery configuration parameters.
     */
    httpDelivery: RosSiteDeliveryTask.HttpDeliveryProperty | ros.IResolvable | undefined;
    /**
     * @Property kafkaDelivery: Kafka delivery configuration parameters.
     */
    kafkaDelivery: RosSiteDeliveryTask.KafkaDeliveryProperty | ros.IResolvable | undefined;
    /**
     * @Property ossDelivery: OSS delivery configuration.
     */
    ossDelivery: RosSiteDeliveryTask.OssDeliveryProperty | ros.IResolvable | undefined;
    /**
     * @Property s3Delivery: S3\/S3 compatible delivery configuration parameters.
     */
    s3Delivery: RosSiteDeliveryTask.S3DeliveryProperty | ros.IResolvable | undefined;
    /**
     * @Property slsDelivery: SLS delivery configuration.
     */
    slsDelivery: RosSiteDeliveryTask.SlsDeliveryProperty | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosSiteDeliveryTaskProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface HeaderParamProperty {
        /**
         * @Property staticValue: The static variable.
         */
        readonly staticValue?: string | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface HttpDeliveryProperty {
        /**
         * @Property compress: The compression method. By default, data is not compressed.
         */
        readonly compress?: string | ros.IResolvable;
        /**
         * @Property logBodySuffix: The suffix of the log delivery package.
         */
        readonly logBodySuffix?: string | ros.IResolvable;
        /**
         * @Property headerParam: The custom headers.
         */
        readonly headerParam?: RosSiteDeliveryTask.HeaderParamProperty | ros.IResolvable;
        /**
         * @Property standardAuthParam: The authentication configurations.
         */
        readonly standardAuthParam?: RosSiteDeliveryTask.StandardAuthParamProperty | ros.IResolvable;
        /**
         * @Property standardAuthOn: Specifies whether to use server authentication.
         */
        readonly standardAuthOn?: boolean | ros.IResolvable;
        /**
         * @Property logBodyPrefix: The prefix of the log delivery package.
         */
        readonly logBodyPrefix?: string | ros.IResolvable;
        /**
         * @Property queryParam: The custom query parameters.
         */
        readonly queryParam?: RosSiteDeliveryTask.QueryParamProperty | ros.IResolvable;
        /**
         * @Property destUrl: The address of the HTTP server.
         */
        readonly destUrl: string | ros.IResolvable;
        /**
         * @Property maxBatchSize: The maximum number of entries for each delivery.Notice The field type is Long, and the precision may be lost during serialization\/deserialization. Please note that the value must not be greater than 9007199254740991.
         */
        readonly maxBatchSize?: number | ros.IResolvable;
        /**
         * @Property transformTimeout: The timeout period. Unit: seconds.Notice The field type is Long, and the precision may be lost during serialization\/deserialization. Please note that the value must not be greater than 9007199254740991.
         */
        readonly transformTimeout?: number | ros.IResolvable;
        /**
         * @Property maxRetry: The maximum number of retries.Notice The field type is Long, and the precision may be lost during serialization\/deserialization. Please note that the value must not be greater than 9007199254740991.
         */
        readonly maxRetry?: number | ros.IResolvable;
        /**
         * @Property maxBatchMb: The maximum size of data for each delivery. Unit: MB.Notice The field type is Long, and the precision may be lost during serialization\/deserialization. Please note that the value must not be greater than 9007199254740991.
         */
        readonly maxBatchMb?: number | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface KafkaDeliveryProperty {
        /**
         * @Property compress: The compression method. By default, data is not compressed.
         */
        readonly compress?: string | ros.IResolvable;
        /**
         * @Property userName: The username.
         */
        readonly userName?: string | ros.IResolvable;
        /**
         * @Property machanismType: The encryption method.
         */
        readonly machanismType?: string | ros.IResolvable;
        /**
         * @Property brokers: The brokers.
         */
        readonly brokers?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property balancer: The load balancing method.
         */
        readonly balancer?: string | ros.IResolvable;
        /**
         * @Property topic: The topic.
         */
        readonly topic?: string | ros.IResolvable;
        /**
         * @Property userAuth: Specifies whether to enable authentication.
         */
        readonly userAuth?: boolean | ros.IResolvable;
        /**
         * @Property password: The password.
         */
        readonly password?: string | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface OssDeliveryProperty {
        /**
         * @Property bucketName: The name of the OSS bucket.
         */
        readonly bucketName?: string | ros.IResolvable;
        /**
         * @Property region: The region in which the bucket is located.
         */
        readonly region?: string | ros.IResolvable;
        /**
         * @Property prefixPath: The prefix of the path in which you want to store logs.
         */
        readonly prefixPath?: string | ros.IResolvable;
        /**
         * @Property aliuid: The account ID.
         */
        readonly aliuid?: string | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface QueryParamProperty {
        /**
         * @Property staticValue: The static variable.
         */
        readonly staticValue?: string | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface S3DeliveryProperty {
        /**
         * @Property secretKey: The secret access key of your Amazon S3 account.
         */
        readonly secretKey?: string | ros.IResolvable;
        /**
         * @Property endpoint: The endpoint. This parameter is required when the S3Cmpt parameter is set to true.
         */
        readonly endpoint?: string | ros.IResolvable;
        /**
         * @Property vertifyType: Authentication Type.
         */
        readonly vertifyType?: string | ros.IResolvable;
        /**
         * @Property region: The region ID of the service.
         */
        readonly region?: string | ros.IResolvable;
        /**
         * @Property serverSideEncryption: Server-side encryption.
         */
        readonly serverSideEncryption?: boolean | ros.IResolvable;
        /**
         * @Property bucketPath: The directory in the bucket.
         */
        readonly bucketPath?: string | ros.IResolvable;
        /**
         * @Property prefixPath: The prefix of the path in which you want to store logs.
         */
        readonly prefixPath?: string | ros.IResolvable;
        /**
         * @Property accessKey: The access key ID of your Amazon S3 account.
         */
        readonly accessKey?: string | ros.IResolvable;
        /**
         * @Property s3Cmpt: Specifies whether the service is compatible with Amazon S3.
         */
        readonly s3Cmpt?: boolean | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface SlsDeliveryProperty {
        /**
         * @Property slsProject: The name of the SLS project.
         */
        readonly slsProject?: string | ros.IResolvable;
        /**
         * @Property slsRegion: The region in which the SLS project resides.
         */
        readonly slsRegion?: string | ros.IResolvable;
        /**
         * @Property slsLogStore: The name of the Logstore.
         */
        readonly slsLogStore?: string | ros.IResolvable;
    }
}
export declare namespace RosSiteDeliveryTask {
    /**
     * @stability external
     */
    interface StandardAuthParamProperty {
        /**
         * @Property privateKey: The private key.
         */
        readonly privateKey?: string | ros.IResolvable;
        /**
         * @Property urlPath: The URI path for server authentication.
         */
        readonly urlPath?: string | ros.IResolvable;
        /**
         * @Property expiredTime: The validity period of the signature.Note The value must be greater than 0. We recommend that you specify a value that is greater than 300.
         */
        readonly expiredTime?: number | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosSiteOriginClientCertificate`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-siteoriginclientcertificate
 */
export interface RosSiteOriginClientCertificateProps {
    /**
     * @Property certificate: The certificate content.
     */
    readonly certificate: string | ros.IResolvable;
    /**
     * @Property privateKey: The private key of the certificate.
     */
    readonly privateKey: string | ros.IResolvable;
    /**
     * @Property siteId: Site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property siteOriginClientCertificateName: The certificate name.
     */
    readonly siteOriginClientCertificateName?: string | ros.IResolvable;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    readonly validityDays?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::SiteOriginClientCertificate`.
 * @Note This class does not contain additional functions, so it is recommended to use the `SiteOriginClientCertificate` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-siteoriginclientcertificate
 */
export declare class RosSiteOriginClientCertificate extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::SiteOriginClientCertificate";
    /**
     * @Attribute Certificate: The certificate content.
     */
    readonly attrCertificate: ros.IResolvable;
    /**
     * @Attribute CommonName: The Common Name of the certificate.
     */
    readonly attrCommonName: ros.IResolvable;
    /**
     * @Attribute CreateTime: The time when the certificate was created.
     */
    readonly attrCreateTime: ros.IResolvable;
    /**
     * @Attribute FingerprintSha256: The SHA-256 fingerprint of the certificate.
     */
    readonly attrFingerprintSha256: ros.IResolvable;
    /**
     * @Attribute Issuer: The certificate authority (CA) that issued the certificate.
     */
    readonly attrIssuer: ros.IResolvable;
    /**
     * @Attribute NotAfter: The time when the certificate expires.
     */
    readonly attrNotAfter: ros.IResolvable;
    /**
     * @Attribute NotBefore: The time when the certificate takes effect.
     */
    readonly attrNotBefore: ros.IResolvable;
    /**
     * @Attribute PubkeyAlgorithm: The public key algorithm of the certificate.
     */
    readonly attrPubkeyAlgorithm: ros.IResolvable;
    /**
     * @Attribute SAN: The Subject Alternative Name (SAN) of the certificate.
     */
    readonly attrSan: ros.IResolvable;
    /**
     * @Attribute SerialNumber: The serial number of the certificate.
     */
    readonly attrSerialNumber: ros.IResolvable;
    /**
     * @Attribute SignatureAlgorithm: The signature algorithm of the certificate.
     */
    readonly attrSignatureAlgorithm: ros.IResolvable;
    /**
     * @Attribute SiteId: Site ID.
     */
    readonly attrSiteId: ros.IResolvable;
    /**
     * @Attribute SiteName: The website name.
     */
    readonly attrSiteName: ros.IResolvable;
    /**
     * @Attribute SiteOriginClientCertificateId: The certificate ID on ESA.
     */
    readonly attrSiteOriginClientCertificateId: ros.IResolvable;
    /**
     * @Attribute SiteOriginClientCertificateName: The certificate name.
     */
    readonly attrSiteOriginClientCertificateName: ros.IResolvable;
    /**
     * @Attribute Type: The certificate type.
     */
    readonly attrType: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the certificate was updated.
     */
    readonly attrUpdateTime: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property certificate: The certificate content.
     */
    certificate: string | ros.IResolvable;
    /**
     * @Property privateKey: The private key of the certificate.
     */
    privateKey: string | ros.IResolvable;
    /**
     * @Property siteId: Site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property siteOriginClientCertificateName: The certificate name.
     */
    siteOriginClientCertificateName: string | ros.IResolvable | undefined;
    /**
     * @Property validityDays: The validity period of the certificate. Unit: day.
     */
    validityDays: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosSiteOriginClientCertificateProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosUrlObservation`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-urlobservation
 */
export interface RosUrlObservationProps {
    /**
     * @Property sdkType: SDK integration mode. Value:
     * - **automatic**: automatic integration.
     * - **manual**: manual integration.
     */
    readonly sdkType: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property url: The URL of the page to monitor.
     */
    readonly url: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::UrlObservation`.
 * @Note This class does not contain additional functions, so it is recommended to use the `UrlObservation` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-urlobservation
 */
export declare class RosUrlObservation extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::UrlObservation";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute SdkType: SDK integration mode.
     */
    readonly attrSdkType: ros.IResolvable;
    /**
     * @Attribute Url: The URL of the page to monitor.
     */
    readonly attrUrl: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property sdkType: SDK integration mode. Value:
     * - **automatic**: automatic integration.
     * - **manual**: manual integration.
     */
    sdkType: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property url: The URL of the page to monitor.
     */
    url: string | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosUrlObservationProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosVideoProcessing`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-videoprocessing
 */
export interface RosVideoProcessingProps {
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property flvSeekEnd: Custom FLV end parameters.
     */
    readonly flvSeekEnd?: string | ros.IResolvable;
    /**
     * @Property flvSeekStart: Custom FLV start parameters.
     */
    readonly flvSeekStart?: string | ros.IResolvable;
    /**
     * @Property flvVideoSeekMode: FLV drag mode. Value range:
     * - `by_byte`: Drag by byte.
     * - `by_time`: Drag by time.
     */
    readonly flvVideoSeekMode?: string | ros.IResolvable;
    /**
     * @Property mp4SeekEnd: Custom mp4 end parameters.
     */
    readonly mp4SeekEnd?: string | ros.IResolvable;
    /**
     * @Property mp4SeekStart: Custom mp4 start parameters.
     */
    readonly mp4SeekStart?: string | ros.IResolvable;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    readonly rule?: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly ruleEnable?: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly ruleName?: string | ros.IResolvable;
    /**
     * @Property sequence: The rule execution order prioritizes lower numerical values. It is only applicable when setting or modifying the order of individual rule configurations.
     */
    readonly sequence?: number | ros.IResolvable;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly siteVersion?: number | ros.IResolvable;
    /**
     * @Property videoSeekEnable: Drag and drop the play function switch. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    readonly videoSeekEnable?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::VideoProcessing`.
 * @Note This class does not contain additional functions, so it is recommended to use the `VideoProcessing` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-videoprocessing
 */
export declare class RosVideoProcessing extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::VideoProcessing";
    /**
     * @Attribute ConfigId: Config Id.
     */
    readonly attrConfigId: ros.IResolvable;
    /**
     * @Attribute ConfigType: The configuration type.
     */
    readonly attrConfigType: ros.IResolvable;
    /**
     * @Attribute FlvSeekEnd: Custom FLV end parameters.
     */
    readonly attrFlvSeekEnd: ros.IResolvable;
    /**
     * @Attribute FlvSeekStart: Custom FLV start parameters.
     */
    readonly attrFlvSeekStart: ros.IResolvable;
    /**
     * @Attribute FlvVideoSeekMode: FLV drag mode.
     */
    readonly attrFlvVideoSeekMode: ros.IResolvable;
    /**
     * @Attribute Mp4SeekEnd: Custom mp4 end parameters.
     */
    readonly attrMp4SeekEnd: ros.IResolvable;
    /**
     * @Attribute Mp4SeekStart: Custom mp4 start parameters.
     */
    readonly attrMp4SeekStart: ros.IResolvable;
    /**
     * @Attribute Rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute Sequence: The rule execution order prioritizes lower numerical values. It is only applicable when setting or modifying the order of individual rule configurations.
     */
    readonly attrSequence: ros.IResolvable;
    /**
     * @Attribute SiteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    readonly attrSiteVersion: ros.IResolvable;
    /**
     * @Attribute VideoSeekEnable: Drag and drop the play function switch.
     */
    readonly attrVideoSeekEnable: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property flvSeekEnd: Custom FLV end parameters.
     */
    flvSeekEnd: string | ros.IResolvable | undefined;
    /**
     * @Property flvSeekStart: Custom FLV start parameters.
     */
    flvSeekStart: string | ros.IResolvable | undefined;
    /**
     * @Property flvVideoSeekMode: FLV drag mode. Value range:
     * - `by_byte`: Drag by byte.
     * - `by_time`: Drag by time.
     */
    flvVideoSeekMode: string | ros.IResolvable | undefined;
    /**
     * @Property mp4SeekEnd: Custom mp4 end parameters.
     */
    mp4SeekEnd: string | ros.IResolvable | undefined;
    /**
     * @Property mp4SeekStart: Custom mp4 start parameters.
     */
    mp4SeekStart: string | ros.IResolvable | undefined;
    /**
     * @Property rule: Rule content, using conditional expressions to match user requests. When adding global configuration, this parameter does not need to be set. There are two usage scenarios:
     * - Match all incoming requests: value set to true
     * - Match specified request: Set the value to a custom expression, for example: (http.host eq \"video.example.com\").
     */
    rule: string | ros.IResolvable | undefined;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    ruleEnable: string | ros.IResolvable | undefined;
    /**
     * @Property ruleName: Rule name. When adding global configuration, this parameter does not need to be set.
     */
    ruleName: string | ros.IResolvable | undefined;
    /**
     * @Property sequence: The rule execution order prioritizes lower numerical values. It is only applicable when setting or modifying the order of individual rule configurations.
     */
    sequence: number | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The version number of the site configuration. For sites that have enabled configuration version management, this parameter can be used to specify the effective version of the configuration site, which defaults to version 0.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @Property videoSeekEnable: Drag and drop the play function switch. Value range:
     * - `on`: open.
     * - `off`: close.
     */
    videoSeekEnable: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosVideoProcessingProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosWafRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-wafrule
 */
export interface RosWafRuleProps {
    /**
     * @Property phase: The version of the website.
     */
    readonly phase: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property config: The configuration of the rule.
     */
    readonly config?: RosWafRule.ConfigProperty | ros.IResolvable;
    /**
     * @Property rulesetId: The ID of the WAF ruleset, which can be obtained by calling the [ListWafRulesets](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850233.html) operation.
     */
    readonly rulesetId?: number | ros.IResolvable;
    /**
     * @Property shared: The configurations shared by multiple rules.
     */
    readonly shared?: RosWafRule.SharedProperty | ros.IResolvable;
    /**
     * @Property siteVersion: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    readonly siteVersion?: number | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::WafRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WafRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-wafrule
 */
export declare class RosWafRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::WafRule";
    /**
     * @Attribute Config: The configuration of the rule.
     */
    readonly attrConfig: ros.IResolvable;
    /**
     * @Attribute Phase: The version of the website.
     */
    readonly attrPhase: ros.IResolvable;
    /**
     * @Attribute RulesetId: The ID of the WAF ruleset, which can be obtained by calling the [ListWafRulesets](https://www.alibabacloud.com/help/en/doc-detail/2850233.html) operation.
     */
    readonly attrRulesetId: ros.IResolvable;
    /**
     * @Attribute UpdateTime: The time when the rule was last modified.
     */
    readonly attrUpdateTime: ros.IResolvable;
    /**
     * @Attribute WafRuleId: WafRule Id.
     */
    readonly attrWafRuleId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property phase: The version of the website.
     */
    phase: string | ros.IResolvable;
    /**
     * @Property siteId: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property config: The configuration of the rule.
     */
    config: RosWafRule.ConfigProperty | ros.IResolvable | undefined;
    /**
     * @Property rulesetId: The ID of the WAF ruleset, which can be obtained by calling the [ListWafRulesets](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850233.html) operation.
     */
    rulesetId: number | ros.IResolvable | undefined;
    /**
     * @Property shared: The configurations shared by multiple rules.
     */
    shared: RosWafRule.SharedProperty | ros.IResolvable | undefined;
    /**
     * @Property siteVersion: The website ID, which can be obtained by calling the [ListSites](https:\/\/www.alibabacloud.com\/help\/en\/doc-detail\/2850189.html) operation.
     */
    siteVersion: number | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWafRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ActionsProperty {
        /**
         * @Property response: Customize Response Page.
         */
        readonly response?: RosWafRule.ResponseProperty | ros.IResolvable;
        /**
         * @Property bypass: Skip Module.
         */
        readonly bypass?: RosWafRule.BypassProperty | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ActionsResponseProperty {
        /**
         * @Property code: Custom Response Codes.
         */
        readonly code?: number | ros.IResolvable;
        /**
         * @Property identity: Custom response page id.
         */
        readonly identity?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface AppPackageProperty {
        /**
         * @Property packageSigns: Secondary packaging inspection.
         */
        readonly packageSigns?: Array<RosWafRule.PackageSignsProperty | ros.IResolvable> | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface AppSdkProperty {
        /**
         * @Property customSign: Custom Tab Fields.
         */
        readonly customSign?: RosWafRule.CustomSignProperty | ros.IResolvable;
        /**
         * @Property customSignStatus: Custom Tab Field Switch.
         */
        readonly customSignStatus?: string | ros.IResolvable;
        /**
         * @Property featureAbnormal: Characteristic anomaly.
         */
        readonly featureAbnormal?: Array<string | ros.IResolvable> | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface BypassProperty {
        /**
         * @Property skip: Skip module type.
         */
        readonly skip?: string | ros.IResolvable;
        /**
         * @Property regularRules: Managed rule id list.
         */
        readonly regularRules?: Array<number | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property customRules: Custom rule id list.
         */
        readonly customRules?: Array<number | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property regularTypes: Managed rule type list.
         */
        readonly regularTypes?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property tags: Skip Module List.
         */
        readonly tags?: string[];
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CharacteristicsProperty {
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CharacteristicsCriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CharacteristicsCriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CharacteristicsCriteriaCriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CharacteristicsCriteriaCriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CharacteristicsCriteriaCriteriaCriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CharacteristicsCriteriaCriteriaCriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ConfigProperty {
        /**
         * @Property status: Rule Status.
         */
        readonly status?: string | ros.IResolvable;
        /**
         * @Property action: Execute Action.
         */
        readonly action?: string | ros.IResolvable;
        /**
         * @Property actions: Extended Action.
         */
        readonly actions?: RosWafRule.ActionsProperty | ros.IResolvable;
        /**
         * @Property managedList: List of names.
         */
        readonly managedList?: string | ros.IResolvable;
        /**
         * @Property managedRulesets: Managed Rule Set List.
         */
        readonly managedRulesets?: Array<RosWafRule.ManagedRulesetsProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property sigchl: Token check.
         */
        readonly sigchl?: Array<string | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property name: Rule Name.
         */
        readonly name?: string | ros.IResolvable;
        /**
         * @Property appSdk: App sdk.
         */
        readonly appSdk?: RosWafRule.AppSdkProperty | ros.IResolvable;
        /**
         * @Property rateLimit: Frequency Control.
         */
        readonly rateLimit?: RosWafRule.RateLimitProperty | ros.IResolvable;
        /**
         * @Property type: Rule Type.
         */
        readonly type?: string | ros.IResolvable;
        /**
         * @Property appPackage: Secondary packaging inspection.
         */
        readonly appPackage?: RosWafRule.AppPackageProperty | ros.IResolvable;
        /**
         * @Property managedGroupId: Managed rule Group id.
         */
        readonly managedGroupId?: number | ros.IResolvable;
        /**
         * @Property timer: Timer.
         */
        readonly timer?: RosWafRule.TimerProperty | ros.IResolvable;
        /**
         * @Property expression: Expression.
         */
        readonly expression?: string | ros.IResolvable;
        /**
         * @Property securityLevel: Security Level.
         */
        readonly securityLevel?: RosWafRule.SecurityLevelProperty | ros.IResolvable;
        /**
         * @Property value: IP access control value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property notes: Remarks.
         */
        readonly notes?: string | ros.IResolvable;
        /**
         * @Property identity: Rule id.
         */
        readonly identity?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CriteriaCriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CriteriaCriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CriteriaCriteriaCriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CriteriaCriteriaCriteriaProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface CustomSignProperty {
        /**
         * @Property value: Field Value.
         */
        readonly value?: string | ros.IResolvable;
        /**
         * @Property key: Field Name.
         */
        readonly key?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface DailyPeriodsProperty {
        /**
         * @Property start: Start time in HH:mm:ss format.
         */
        readonly start?: string | ros.IResolvable;
        /**
         * @Property end: End time in HH:mm:ss format.
         */
        readonly end?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ManagedRulesProperty {
        /**
         * @Property status: Managed Rule Status.
         */
        readonly status?: string | ros.IResolvable;
        /**
         * @Property action: Managed Rule Action.
         */
        readonly action?: string | ros.IResolvable;
        /**
         * @Property identity: Managed rule ID.
         */
        readonly identity?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ManagedRulesetsProperty {
        /**
         * @Property protectionLevel: Protection level.
         */
        readonly protectionLevel?: number | ros.IResolvable;
        /**
         * @Property action: Execute Action.
         */
        readonly action?: string | ros.IResolvable;
        /**
         * @Property managedRules: Managed Rule List.
         */
        readonly managedRules?: Array<RosWafRule.ManagedRulesProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property attackType: Attack Type.
         */
        readonly attackType?: number | ros.IResolvable;
        /**
         * @Property numberTotal: Total number of rules.
         */
        readonly numberTotal?: number | ros.IResolvable;
        /**
         * @Property numberEnabled: Number of rules opened.
         */
        readonly numberEnabled?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface MatchProperty {
        /**
         * @Property matchType: Match Domain.
         */
        readonly matchType?: string | ros.IResolvable;
        /**
         * @Property criteria: Logical List.
         */
        readonly criteria?: Array<RosWafRule.CriteriaProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property logic: Logical relationship.
         */
        readonly logic?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface PackageSignsProperty {
        /**
         * @Property sign: Package Signing.
         */
        readonly sign?: string | ros.IResolvable;
        /**
         * @Property name: Specify a legal package name.
         */
        readonly name?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface PeriodsProperty {
        /**
         * @Property start: Start time, value is UTC time in RFC3339 format.
         */
        readonly start?: string | ros.IResolvable;
        /**
         * @Property end: The end time, which is a UTC time in RFC3339 format.
         */
        readonly end?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface RateLimitProperty {
        /**
         * @Property characteristics: Statistical object.
         */
        readonly characteristics?: RosWafRule.CharacteristicsProperty | ros.IResolvable;
        /**
         * @Property onHit: Apply on requests that hit the cache.
         */
        readonly onHit?: boolean | ros.IResolvable;
        /**
         * @Property ttl: Timeout.
         */
        readonly ttl?: number | ros.IResolvable;
        /**
         * @Property threshold: Threshold.
         */
        readonly threshold?: RosWafRule.ThresholdProperty | ros.IResolvable;
        /**
         * @Property interval: Statistical Duration.
         */
        readonly interval?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ResponseProperty {
        /**
         * @Property code: Custom Response Codes.
         */
        readonly code?: number | ros.IResolvable;
        /**
         * @Property identity: Custom response page ID.
         */
        readonly identity?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ResponseStatusProperty {
        /**
         * @Property ratio: Percentage of response code.
         */
        readonly ratio?: number | ros.IResolvable;
        /**
         * @Property count: Response code times threshold.
         */
        readonly count?: number | ros.IResolvable;
        /**
         * @Property code: HTTP response code.
         */
        readonly code?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface SecurityLevelProperty {
        /**
         * @Property value: Value of security level.
         */
        readonly value?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface SharedProperty {
        /**
         * @Property target: Protection target type: web\/app.
         */
        readonly target?: string | ros.IResolvable;
        /**
         * @Property action: Action.
         */
        readonly action?: string | ros.IResolvable;
        /**
         * @Property actions: Action Extension.
         */
        readonly actions?: RosWafRule.SharedActionsProperty | ros.IResolvable;
        /**
         * @Property expression: Expression.
         */
        readonly expression?: string | ros.IResolvable;
        /**
         * @Property mode: Web sdk integration mode:
     * - `automatic`
     * - `manual`.
         */
        readonly mode?: string | ros.IResolvable;
        /**
         * @Property crossSiteId: Specify the cross-domain site id.
         */
        readonly crossSiteId?: number | ros.IResolvable;
        /**
         * @Property match: Matching Engine.
         */
        readonly match?: RosWafRule.MatchProperty | ros.IResolvable;
        /**
         * @Property name: Rule Set Name.
         */
        readonly name?: string | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface SharedActionsProperty {
        /**
         * @Property response: Custom Response.
         */
        readonly response?: RosWafRule.ActionsResponseProperty | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface ThresholdProperty {
        /**
         * @Property distinctManagedRules: Different Managed Rules Threshold.
         */
        readonly distinctManagedRules?: number | ros.IResolvable;
        /**
         * @Property managedRulesBlocked: Managed Rule Hit Threshold.
         */
        readonly managedRulesBlocked?: number | ros.IResolvable;
        /**
         * @Property responseStatus: Response Code Threshold.
         */
        readonly responseStatus?: RosWafRule.ResponseStatusProperty | ros.IResolvable;
        /**
         * @Property traffic: Flow Threshold.
         */
        readonly traffic?: string | ros.IResolvable;
        /**
         * @Property request: Request Threshold.
         */
        readonly request?: number | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface TimerProperty {
        /**
         * @Property periods: Effective time period.
         */
        readonly periods?: Array<RosWafRule.PeriodsProperty | ros.IResolvable> | ros.IResolvable;
        /**
         * @Property scopes: Timing type:
     * - `permanent`
     * - `periods`
     * - `weekly`.
         */
        readonly scopes?: string | ros.IResolvable;
        /**
         * @Property zone: The time zone. If it is not specified, the default value is UTC +00:00. <br> Example: 8 means East Zone 8,-8 means West Zone 8 <br> Range:-12 -+14.
         */
        readonly zone?: number | ros.IResolvable;
        /**
         * @Property weeklyPeriods: Weekly effective time period.
         */
        readonly weeklyPeriods?: Array<RosWafRule.WeeklyPeriodsProperty | ros.IResolvable> | ros.IResolvable;
    }
}
export declare namespace RosWafRule {
    /**
     * @stability external
     */
    interface WeeklyPeriodsProperty {
        /**
         * @Property days: Cycle, multiple use comma separated, 1-7 respectively represent Monday-Sunday. <br> Example: Monday, Wednesday value is "1,3".
         */
        readonly days?: string | ros.IResolvable;
        /**
         * @Property dailyPeriods: Effective time in the cycle.
         */
        readonly dailyPeriods?: Array<RosWafRule.DailyPeriodsProperty | ros.IResolvable> | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosWaitingRoom`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroom
 */
export interface RosWaitingRoomProps {
    /**
     * @Property cookieName: The name of the custom cookie.
     */
    readonly cookieName: string | ros.IResolvable;
    /**
     * @Property hostNameAndPath: The hostname and path.
     */
    readonly hostNameAndPath: Array<RosWaitingRoom.HostNameAndPathProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property newUsersPerMinute: The maximum number of new users per minute.
     */
    readonly newUsersPerMinute: number | ros.IResolvable;
    /**
     * @Property queuingMethod: The queuing method. Value:
     * - `random`: Users gain access to the origin randomly, regardless of the arrival time.
     * - `fifo`: Users gain access to the origin in order of arrival.
     * - `Passthrough`: Users pass through the waiting room and go straight to the origin.
     * - `Reject-all`: Users are blocked from reaching the origin.
     */
    readonly queuingMethod: string | ros.IResolvable;
    /**
     * @Property queuingStatusCode: Waiting room status code. Value:
     * - `200`
     * - `202`
     * - `429`.
     */
    readonly queuingStatusCode: number | ros.IResolvable;
    /**
     * @Property sessionDuration: The maximum duration for which a session remains valid after a user leaves the origin. Unit: minutes.
     */
    readonly sessionDuration: number | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property status: Waiting room enabled status. Value:
     * - 'on': Enable waiting room
     * - 'off': Disabled waiting room
     */
    readonly status: string | ros.IResolvable;
    /**
     * @Property totalActiveUsers: The maximum number of active users.
     */
    readonly totalActiveUsers: string | ros.IResolvable;
    /**
     * @Property waitingRoomName: The name of the waiting room.
     */
    readonly waitingRoomName: string | ros.IResolvable;
    /**
     * @Property waitingRoomType: The type of the waiting room, support:
     * - `default`: Indicates the default type.
     * - `custom`: indicates a custom type.
     */
    readonly waitingRoomType: string | ros.IResolvable;
    /**
     * @Property customPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    readonly customPageHtml?: string | ros.IResolvable;
    /**
     * @Property description: Waiting room description.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property disableSessionRenewalEnable: Specifies whether to disable session renewal. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    readonly disableSessionRenewalEnable?: string | ros.IResolvable;
    /**
     * @Property jsonResponseEnable: The JSON response. If the accept request header contains "application\/json", JSON data is returned. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    readonly jsonResponseEnable?: string | ros.IResolvable;
    /**
     * @Property language: The language of the waiting room page. When the waiting room type is the default type, it needs to be passed in. The following types are supported:
     * - `enus`: English.
     * - `zhcn`: Simplified Chinese.
     * - `zhhk`: Traditional Chinese.
     */
    readonly language?: string | ros.IResolvable;
    /**
     * @Property queueAllEnable: Specifies whether to queue all requests. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    readonly queueAllEnable?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::WaitingRoom`The , which type is used to create a waiting room.
 * @Note This class does not contain additional functions, so it is recommended to use the `WaitingRoom` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroom
 */
export declare class RosWaitingRoom extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::WaitingRoom";
    /**
     * @Attribute CookieName: Custom Cookie name.
     */
    readonly attrCookieName: ros.IResolvable;
    /**
     * @Attribute CustomPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    readonly attrCustomPageHtml: ros.IResolvable;
    /**
     * @Attribute Description: Waiting room description.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute DisableSessionRenewalEnable: Disable session renewal.
     */
    readonly attrDisableSessionRenewalEnable: ros.IResolvable;
    /**
     * @Attribute HostNameAndPath: Host name and path.
     */
    readonly attrHostNameAndPath: ros.IResolvable;
    /**
     * @Attribute JsonResponseEnable: The JSON response. If the accept request header contains "application/json", JSON data is returned.
     */
    readonly attrJsonResponseEnable: ros.IResolvable;
    /**
     * @Attribute Language: The language of the waiting room page. When the waiting room type is the default type, it needs to be passed in.
     */
    readonly attrLanguage: ros.IResolvable;
    /**
     * @Attribute NewUsersPerMinute: Number of new users per minute.
     */
    readonly attrNewUsersPerMinute: ros.IResolvable;
    /**
     * @Attribute QueueAllEnable: All in line.
     */
    readonly attrQueueAllEnable: ros.IResolvable;
    /**
     * @Attribute QueuingMethod: Way of queuing.
     */
    readonly attrQueuingMethod: ros.IResolvable;
    /**
     * @Attribute QueuingStatusCode: Waiting room status code.
     */
    readonly attrQueuingStatusCode: ros.IResolvable;
    /**
     * @Attribute SessionDuration: Session duration in minutes.
     */
    readonly attrSessionDuration: ros.IResolvable;
    /**
     * @Attribute TotalActiveUsers: Total number of active users.
     */
    readonly attrTotalActiveUsers: ros.IResolvable;
    /**
     * @Attribute WaitingRoomId: The waiting room ID.
     */
    readonly attrWaitingRoomId: ros.IResolvable;
    /**
     * @Attribute WaitingRoomName: The name of the waiting room.
     */
    readonly attrWaitingRoomName: ros.IResolvable;
    /**
     * @Attribute WaitingRoomType: Waiting room type, support:.
     */
    readonly attrWaitingRoomType: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property cookieName: The name of the custom cookie.
     */
    cookieName: string | ros.IResolvable;
    /**
     * @Property hostNameAndPath: The hostname and path.
     */
    hostNameAndPath: Array<RosWaitingRoom.HostNameAndPathProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * @Property newUsersPerMinute: The maximum number of new users per minute.
     */
    newUsersPerMinute: number | ros.IResolvable;
    /**
     * @Property queuingMethod: The queuing method. Value:
     * - `random`: Users gain access to the origin randomly, regardless of the arrival time.
     * - `fifo`: Users gain access to the origin in order of arrival.
     * - `Passthrough`: Users pass through the waiting room and go straight to the origin.
     * - `Reject-all`: Users are blocked from reaching the origin.
     */
    queuingMethod: string | ros.IResolvable;
    /**
     * @Property queuingStatusCode: Waiting room status code. Value:
     * - `200`
     * - `202`
     * - `429`.
     */
    queuingStatusCode: number | ros.IResolvable;
    /**
     * @Property sessionDuration: The maximum duration for which a session remains valid after a user leaves the origin. Unit: minutes.
     */
    sessionDuration: number | ros.IResolvable;
    /**
     * @Property siteId: The site ID.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property status: Waiting room enabled status. Value:
     * - 'on': Enable waiting room
     * - 'off': Disabled waiting room
     */
    status: string | ros.IResolvable;
    /**
     * @Property totalActiveUsers: The maximum number of active users.
     */
    totalActiveUsers: string | ros.IResolvable;
    /**
     * @Property waitingRoomName: The name of the waiting room.
     */
    waitingRoomName: string | ros.IResolvable;
    /**
     * @Property waitingRoomType: The type of the waiting room, support:
     * - `default`: Indicates the default type.
     * - `custom`: indicates a custom type.
     */
    waitingRoomType: string | ros.IResolvable;
    /**
     * @Property customPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    customPageHtml: string | ros.IResolvable | undefined;
    /**
     * @Property description: Waiting room description.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property disableSessionRenewalEnable: Specifies whether to disable session renewal. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    disableSessionRenewalEnable: string | ros.IResolvable | undefined;
    /**
     * @Property jsonResponseEnable: The JSON response. If the accept request header contains "application\/json", JSON data is returned. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    jsonResponseEnable: string | ros.IResolvable | undefined;
    /**
     * @Property language: The language of the waiting room page. When the waiting room type is the default type, it needs to be passed in. The following types are supported:
     * - `enus`: English.
     * - `zhcn`: Simplified Chinese.
     * - `zhhk`: Traditional Chinese.
     */
    language: string | ros.IResolvable | undefined;
    /**
     * @Property queueAllEnable: Specifies whether to queue all requests. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    queueAllEnable: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWaitingRoomProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
export declare namespace RosWaitingRoom {
    /**
     * @stability external
     */
    interface HostNameAndPathProperty {
        /**
         * @Property path: The path.
         */
        readonly path: string | ros.IResolvable;
        /**
         * @Property subdomain: The subdomain.
         */
        readonly subdomain: string | ros.IResolvable;
        /**
         * @Property domain: The domain name.
         */
        readonly domain: string | ros.IResolvable;
    }
}
/**
 * Properties for defining a `RosWaitingRoomEvent`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroomevent
 */
export interface RosWaitingRoomEventProps {
    /**
     * @Property endTime: The timestamp of the end time of the event.
     */
    readonly endTime: string | ros.IResolvable;
    /**
     * @Property newUsersPerMinute: Number of new users per minute.
     */
    readonly newUsersPerMinute: number | ros.IResolvable;
    /**
     * @Property queuingMethod: Way of queuing. Value:
     * - `random`: random.
     * - `fifo`: first in, first out.
     * - `passthrough`: through.
     * - `reject-all`: reject all.
     */
    readonly queuingMethod: string | ros.IResolvable;
    /**
     * @Property queuingStatusCode: Waiting room status code. Value:
     * - `200`
     * - `202`
     * - `429`.
     */
    readonly queuingStatusCode: string | ros.IResolvable;
    /**
     * @Property sessionDuration: User session duration in minutes.
     */
    readonly sessionDuration: number | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property startTime: The timestamp of the event start time.
     */
    readonly startTime: string | ros.IResolvable;
    /**
     * @Property totalActiveUsers: Total number of active users.
     */
    readonly totalActiveUsers: number | ros.IResolvable;
    /**
     * @Property waitingRoomEventName: Event name, custom event description.
     */
    readonly waitingRoomEventName: string | ros.IResolvable;
    /**
     * @Property waitingRoomType: Waiting room type. The following types are supported:
     * - `default`: the default type.
     * - `custom`: custom type.
     */
    readonly waitingRoomType: string | ros.IResolvable;
    /**
     * @Property customPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    readonly customPageHtml?: string | ros.IResolvable;
    /**
     * @Property description: Waiting room description.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * @Property disableSessionRenewalEnable: Disable session renewal. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    readonly disableSessionRenewalEnable?: string | ros.IResolvable;
    /**
     * @Property jsonResponseEnable: JSON response switch. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    readonly jsonResponseEnable?: string | ros.IResolvable;
    /**
     * @Property language: Default language setting. Values include:
     * - `enus`: English.
     * - `zhcn`: Simplified Chinese.
     * - `zhhk`: Traditional Chinese.
     */
    readonly language?: string | ros.IResolvable;
    /**
     * @Property preQueueEnable: Pre-queue switch.
     * - `on`: open.
     * - `off`: closed.
     */
    readonly preQueueEnable?: string | ros.IResolvable;
    /**
     * @Property preQueueStartTime: Pre-queue start time.
     */
    readonly preQueueStartTime?: string | ros.IResolvable;
    /**
     * @Property randomPreQueueEnable: Random queue switch.
     * - `on`: open.
     * - `off`: closed.
     */
    readonly randomPreQueueEnable?: string | ros.IResolvable;
    /**
     * @Property waitingRoomId: Waiting room ID, used to identify a specific waiting room. It can be obtained by calling the [listwaitingroom](https:\/\/help.aliyun.com\/document_detail\/2850279.html) interface.
     */
    readonly waitingRoomId?: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::WaitingRoomEvent`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WaitingRoomEvent` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroomevent
 */
export declare class RosWaitingRoomEvent extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::WaitingRoomEvent";
    /**
     * @Attribute CustomPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    readonly attrCustomPageHtml: ros.IResolvable;
    /**
     * @Attribute Description: Waiting room description.
     */
    readonly attrDescription: ros.IResolvable;
    /**
     * @Attribute DisableSessionRenewalEnable: Disable session renewal.
     */
    readonly attrDisableSessionRenewalEnable: ros.IResolvable;
    /**
     * @Attribute EndTime: The timestamp of the end time of the event.
     */
    readonly attrEndTime: ros.IResolvable;
    /**
     * @Attribute JsonResponseEnable: JSON response switch.
     */
    readonly attrJsonResponseEnable: ros.IResolvable;
    /**
     * @Attribute Language: Default language setting.
     */
    readonly attrLanguage: ros.IResolvable;
    /**
     * @Attribute NewUsersPerMinute: Number of new users per minute.
     */
    readonly attrNewUsersPerMinute: ros.IResolvable;
    /**
     * @Attribute PreQueueEnable: Pre-queue switch.
     */
    readonly attrPreQueueEnable: ros.IResolvable;
    /**
     * @Attribute PreQueueStartTime: Pre-queue start time.
     */
    readonly attrPreQueueStartTime: ros.IResolvable;
    /**
     * @Attribute QueuingMethod: Way of queuing.
     */
    readonly attrQueuingMethod: ros.IResolvable;
    /**
     * @Attribute QueuingStatusCode: Waiting room status code.
     */
    readonly attrQueuingStatusCode: ros.IResolvable;
    /**
     * @Attribute RandomPreQueueEnable: Random queue switch.
     */
    readonly attrRandomPreQueueEnable: ros.IResolvable;
    /**
     * @Attribute SessionDuration: User session duration in minutes.
     */
    readonly attrSessionDuration: ros.IResolvable;
    /**
     * @Attribute StartTime: The timestamp of the event start time.
     */
    readonly attrStartTime: ros.IResolvable;
    /**
     * @Attribute TotalActiveUsers: Total number of active users.
     */
    readonly attrTotalActiveUsers: ros.IResolvable;
    /**
     * @Attribute WaitingRoomEventId: The waiting room event ID, which can be obtained by calling the [ListWaitingRoomEvents](https://help.aliyun.com/document_detail/2850279.html) operation.
     */
    readonly attrWaitingRoomEventId: ros.IResolvable;
    /**
     * @Attribute WaitingRoomEventName: Event name, custom event description.
     */
    readonly attrWaitingRoomEventName: ros.IResolvable;
    /**
     * @Attribute WaitingRoomId: Waiting room ID, used to identify a specific waiting room. It can be obtained by calling the [listwaitingroom](https://help.aliyun.com/document_detail/2850279.html) interface.
     */
    readonly attrWaitingRoomId: ros.IResolvable;
    /**
     * @Attribute WaitingRoomType: Waiting room type.
     */
    readonly attrWaitingRoomType: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property endTime: The timestamp of the end time of the event.
     */
    endTime: string | ros.IResolvable;
    /**
     * @Property newUsersPerMinute: Number of new users per minute.
     */
    newUsersPerMinute: number | ros.IResolvable;
    /**
     * @Property queuingMethod: Way of queuing. Value:
     * - `random`: random.
     * - `fifo`: first in, first out.
     * - `passthrough`: through.
     * - `reject-all`: reject all.
     */
    queuingMethod: string | ros.IResolvable;
    /**
     * @Property queuingStatusCode: Waiting room status code. Value:
     * - `200`
     * - `202`
     * - `429`.
     */
    queuingStatusCode: string | ros.IResolvable;
    /**
     * @Property sessionDuration: User session duration in minutes.
     */
    sessionDuration: number | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property startTime: The timestamp of the event start time.
     */
    startTime: string | ros.IResolvable;
    /**
     * @Property totalActiveUsers: Total number of active users.
     */
    totalActiveUsers: number | ros.IResolvable;
    /**
     * @Property waitingRoomEventName: Event name, custom event description.
     */
    waitingRoomEventName: string | ros.IResolvable;
    /**
     * @Property waitingRoomType: Waiting room type. The following types are supported:
     * - `default`: the default type.
     * - `custom`: custom type.
     */
    waitingRoomType: string | ros.IResolvable;
    /**
     * @Property customPageHtml: User-defined waiting room page content, when the waiting room type is custom type, you need to enter. The incoming content needs to be base64 encoded.
     */
    customPageHtml: string | ros.IResolvable | undefined;
    /**
     * @Property description: Waiting room description.
     */
    description: string | ros.IResolvable | undefined;
    /**
     * @Property disableSessionRenewalEnable: Disable session renewal. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    disableSessionRenewalEnable: string | ros.IResolvable | undefined;
    /**
     * @Property jsonResponseEnable: JSON response switch. Value:
     * - `on`: open.
     * - `off`: closed.
     */
    jsonResponseEnable: string | ros.IResolvable | undefined;
    /**
     * @Property language: Default language setting. Values include:
     * - `enus`: English.
     * - `zhcn`: Simplified Chinese.
     * - `zhhk`: Traditional Chinese.
     */
    language: string | ros.IResolvable | undefined;
    /**
     * @Property preQueueEnable: Pre-queue switch.
     * - `on`: open.
     * - `off`: closed.
     */
    preQueueEnable: string | ros.IResolvable | undefined;
    /**
     * @Property preQueueStartTime: Pre-queue start time.
     */
    preQueueStartTime: string | ros.IResolvable | undefined;
    /**
     * @Property randomPreQueueEnable: Random queue switch.
     * - `on`: open.
     * - `off`: closed.
     */
    randomPreQueueEnable: string | ros.IResolvable | undefined;
    /**
     * @Property waitingRoomId: Waiting room ID, used to identify a specific waiting room. It can be obtained by calling the [listwaitingroom](https:\/\/help.aliyun.com\/document_detail\/2850279.html) interface.
     */
    waitingRoomId: string | ros.IResolvable | undefined;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWaitingRoomEventProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * Properties for defining a `RosWaitingRoomRule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroomrule
 */
export interface RosWaitingRoomRuleProps {
    /**
     * @Property rule: The content of the rule, the implemented policy or conditional expression.
     */
    readonly rule: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    readonly ruleEnable: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name, optional, used to query by waiting room bypass rule name.
     */
    readonly ruleName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    readonly siteId: number | ros.IResolvable;
    /**
     * @Property waitingRoomId: Waiting room ID, used to identify a specific waiting room. It can be obtained by calling the [listwaitingroom](https:\/\/help.aliyun.com\/document_detail\/2850279.html) interface.
     */
    readonly waitingRoomId: string | ros.IResolvable;
}
/**
 * This class is a base encapsulation around the ROS resource type `ALIYUN::ESA::WaitingRoomRule`.
 * @Note This class does not contain additional functions, so it is recommended to use the `WaitingRoomRule` class instead of this class for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-esa-waitingroomrule
 */
export declare class RosWaitingRoomRule extends ros.RosResource {
    /**
     * The resource type name for this resource class.
     */
    static readonly ROS_RESOURCE_TYPE_NAME = "ALIYUN::ESA::WaitingRoomRule";
    /**
     * @Attribute Rule: The content of the rule, the implemented policy or conditional expression.
     */
    readonly attrRule: ros.IResolvable;
    /**
     * @Attribute RuleEnable: Rule switch. When adding global configuration, this parameter does not need to be set.
     */
    readonly attrRuleEnable: ros.IResolvable;
    /**
     * @Attribute RuleName: Rule name, optional, used to query by waiting room bypass rule name.
     */
    readonly attrRuleName: ros.IResolvable;
    /**
     * @Attribute WaitingRoomRuleId: The rule ID, which can be used to query a specific rule.
     */
    readonly attrWaitingRoomRuleId: ros.IResolvable;
    enableResourcePropertyConstraint: boolean;
    /**
     * @Property rule: The content of the rule, the implemented policy or conditional expression.
     */
    rule: string | ros.IResolvable;
    /**
     * @Property ruleEnable: Rule switch. When adding global configuration, this parameter does not need to be set. Value range:
     * - on: open.
     * - off: close.
     */
    ruleEnable: string | ros.IResolvable;
    /**
     * @Property ruleName: Rule name, optional, used to query by waiting room bypass rule name.
     */
    ruleName: string | ros.IResolvable;
    /**
     * @Property siteId: The site ID, which can be obtained by calling the ListSites API.
     */
    siteId: number | ros.IResolvable;
    /**
     * @Property waitingRoomId: Waiting room ID, used to identify a specific waiting room. It can be obtained by calling the [listwaitingroom](https:\/\/help.aliyun.com\/document_detail\/2850279.html) interface.
     */
    waitingRoomId: string | ros.IResolvable;
    /**
     * @param scope - scope in which this resource is defined
     * @param id    - scoped id of the resource
     * @param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RosWaitingRoomRuleProps, enableResourcePropertyConstraint: boolean);
    protected get rosProperties(): {
        [key: string]: any;
    };
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
