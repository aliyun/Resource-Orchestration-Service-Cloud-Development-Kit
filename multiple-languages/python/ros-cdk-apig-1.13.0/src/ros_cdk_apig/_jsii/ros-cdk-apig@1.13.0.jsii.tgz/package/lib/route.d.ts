import * as ros from '@alicloud/ros-cdk-core';
import { RosRoute } from './apig.generated';
export { RosRoute as RouteProperty };
/**
 * Properties for defining a `Route`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-apig-route
 */
export interface RouteProps {
    /**
     * Property backend: Backend service configuration for routing.
     */
    readonly backend: RosRoute.BackendProperty | ros.IResolvable;
    /**
     * Property environmentInfo: The information if the environment.
     */
    readonly environmentInfo: RosRoute.EnvironmentInfoProperty | ros.IResolvable;
    /**
     * Property httpApiId: The ID of the API.
     */
    readonly httpApiId: string | ros.IResolvable;
    /**
     * Property match: The match rule of route resource.
     */
    readonly match: RosRoute.MatchProperty | ros.IResolvable;
    /**
     * Property routeName: The name of the route.
     */
    readonly routeName: string | ros.IResolvable;
    /**
     * Property description: The description of route.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * Property domainIds: The list of domain name IDs.
     */
    readonly domainIds?: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * Property domainInfos: Domain items.
     */
    readonly domainInfos?: Array<RosRoute.DomainInfosProperty | ros.IResolvable> | ros.IResolvable;
}
/**
 * Represents a `Route`.
 */
export interface IRoute extends ros.IResource {
    readonly props: RouteProps;
    /**
     * Attribute Backend: Backend services.
     */
    readonly attrBackend: ros.IResolvable | string;
    /**
     * Attribute Description: The description of route resource.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute DomainInfos: Domain items.
     */
    readonly attrDomainInfos: ros.IResolvable | string;
    /**
     * Attribute EnvironmentInfo: Environment information.
     */
    readonly attrEnvironmentInfo: ros.IResolvable | string;
    /**
     * Attribute Match: The match rule of route resource.
     */
    readonly attrMatch: ros.IResolvable | string;
    /**
     * Attribute RouteId: The ID of route resource.
     */
    readonly attrRouteId: ros.IResolvable | string;
    /**
     * Attribute RouteName: The name of the route.
     */
    readonly attrRouteName: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::APIG::Route`, which is used to create a route for an HTTP API.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosRoute`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-apig-route
 */
export declare class Route extends ros.Resource implements IRoute {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: RouteProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute Backend: Backend services.
     */
    readonly attrBackend: ros.IResolvable | string;
    /**
     * Attribute Description: The description of route resource.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute DomainInfos: Domain items.
     */
    readonly attrDomainInfos: ros.IResolvable | string;
    /**
     * Attribute EnvironmentInfo: Environment information.
     */
    readonly attrEnvironmentInfo: ros.IResolvable | string;
    /**
     * Attribute Match: The match rule of route resource.
     */
    readonly attrMatch: ros.IResolvable | string;
    /**
     * Attribute RouteId: The ID of route resource.
     */
    readonly attrRouteId: ros.IResolvable | string;
    /**
     * Attribute RouteName: The name of the route.
     */
    readonly attrRouteName: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RouteProps, enableResourcePropertyConstraint?: boolean);
}
