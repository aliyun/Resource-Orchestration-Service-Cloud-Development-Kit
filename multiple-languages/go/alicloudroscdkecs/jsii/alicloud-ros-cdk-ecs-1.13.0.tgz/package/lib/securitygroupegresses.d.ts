import * as ros from '@alicloud/ros-cdk-core';
import { RosSecurityGroupEgresses } from './ecs.generated';
export { RosSecurityGroupEgresses as SecurityGroupEgressesProperty };
/**
 * Properties for defining a `SecurityGroupEgresses`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-ecs-securitygroupegresses
 */
export interface SecurityGroupEgressesProps {
    /**
     * Property permissions: A list of security group rules. A hundred at most.
     */
    readonly permissions: Array<RosSecurityGroupEgresses.PermissionsProperty | ros.IResolvable> | ros.IResolvable;
    /**
     * Property securityGroupId: Id of the security group.
     */
    readonly securityGroupId: string | ros.IResolvable;
}
/**
 * Represents a `SecurityGroupEgresses`.
 */
export interface ISecurityGroupEgresses extends ros.IResource {
    readonly props: SecurityGroupEgressesProps;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::ECS::SecurityGroupEgresses`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosSecurityGroupEgresses`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-ecs-securitygroupegresses
 */
export declare class SecurityGroupEgresses extends ros.Resource implements ISecurityGroupEgresses {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: SecurityGroupEgressesProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: SecurityGroupEgressesProps, enableResourcePropertyConstraint?: boolean);
}
